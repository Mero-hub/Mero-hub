const mongoose = require('mongoose');
const claim = new mongoose.Schema(
  {
    userId: {
      type: String,
      required: true,
    },
    channelId: {
      type: String,
      required: true,
    }
  }
);
module.exports = mongoose.model('claim', claim);