const client = require("../../index.js");
const config = require("../../config.json")
const { EmbedBuilder, ApplicationCommandOptionType , Events , ActionRowBuilder , ButtonBuilder ,MessageAttachment, ButtonStyle , Message, TextInputStyle,TextInputBuilder,ModalBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, PermissionsBitField } = require("discord.js");
const roles = ["1145673259602415718","1145673261217235024" ,"1145673266602704946","1145673267902939168","1145673262181920799","1145673248873390172","1145673254548291634","1145673256632852501","1145673257090031657","1145673258335744112","1145673253596188793","1145673247120175234","1145673247967432785"];
               
const users = require('../../Datebase/model/buy.js');
client.on('interactionCreate', async interaction => {
  if (!interaction.isButton()) return;
  if (interaction.customId === 'transfer-role') {
    const user = interaction.user.id
    const non = new EmbedBuilder()
    .setColor('#000100')
    .setDescription("**لا تمتلك أي رتب بيع**")
    .setTimestamp()
    .setFooter({
      text: interaction.guild.name,
        iconURL: interaction.guild.iconURL()
    })
    .setThumbnail(interaction.guild.iconURL())
    .setAuthor({
      name: interaction.user.tag,
        iconURL: interaction.user.displayAvatarURL()
    });
    if (!roles.some(role => interaction.member.roles.cache.has(role))) {
     interaction.reply({
      embeds: [non],
     
    });
      const user = await users.deleteOne({ userId: interaction.user.id });
      }
    
    const rolehave = `${interaction.member.roles.cache.filter(r => r.id !== interaction.guild.id).map(r => `<@&${r.id}>`).join('\n')}`
  const have = new EmbedBuilder()
    .setColor("000100")
    .setDescription(`**الرتب التي لديك :**` + `\n\n${rolehave}`)
    .setTimestamp()
    .setFooter({
      text: interaction.guild.name,
        iconURL: interaction.guild.iconURL()
    })
    .setThumbnail(interaction.guild.iconURL())
    .setAuthor({
      name: interaction.user.tag,
        iconURL: interaction.user.displayAvatarURL()
    });
    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('confirm-transfer-role')
          .setLabel('اكمال العمليه')
          .setStyle(ButtonStyle.Secondary),
      );
    interaction.reply({
      embeds: [have],
      components: [row]
    });
  }
});
client.on('interactionCreate', async interaction => {
  if (!interaction.isButton()) return;
  if (interaction.customId === 'confirm-transfer-role') {
    const model = new ModalBuilder()
      .setCustomId("modal-transfer-role")
      .setTitle("نقل رتب البيع");
    const user = new TextInputBuilder()
      .setCustomId("user-transfer-role")
      .setLabel("ايدي الشخص الذي تريد نقل رتب له")
      .setStyle(TextInputStyle.Short)
      .setRequired(true)
      .setPlaceholder("قم بوضع ايدي الشخص الذي تريد نقل الرتب له");
    const row1 = new ActionRowBuilder().addComponents(user);
    model.addComponents(row1);
    await interaction.showModal(model);
  }
});
client.on('interactionCreate', async interaction => {
  if (!interaction.isModalSubmit()) return;
  if (interaction.customId === 'modal-transfer-role') {
    const user = interaction.fields.getTextInputValue('user-transfer-role');
    const member = interaction.guild.members.cache.get(user);
    const roleIds = interaction.member.roles.cache.filter(r => r.id !== interaction.guild.id).map(r => r.id);

    let price = 50000;
    let result = price;
    let tax = Math.floor(price * 0.20 + price);
    let owner = config.owner;
    const embed = new EmbedBuilder()
      .setColor('#000100')
      .setDescription(`**قم بتحويل مبلغ \`${tax}\` لـ <@${owner}>**\n\n**C ${owner} ${tax}**`)
      .setTimestamp();
    await interaction.update({
      embeds: [embed],
      components: [],
    });
    await interaction.channel.send({
      content: `#credit ${owner} ${tax}`
    });

    const filter = ({ content, author: { id } }) => {
      return (
        content.startsWith(`**:moneybag: | ${interaction.user.username}, has transferred `) &&
        content.includes(`${owner}`) &&
        id === "282859044593598464" &&
        (Number(content.slice(content.lastIndexOf("`") - String(tax).length, content.lastIndexOf("`"))) >= result)
      );
    };

    const collector = interaction.channel.createMessageCollector({
      filter,
      max: 1,
      time: 60000,
    });

    let iscollected = false;
    collector.on('collect', async (collected) => {
      iscollected = true;
      const embed = new EmbedBuilder()
        .setColor('#000100')
        .setTitle("**تم نقل رتب البيع بنجاح**")
        .setDescription("**تم نقل رتب البيع بنجاح**"+ `\n\n**تم النقل ل : ${member}**`)
        .setTimestamp()
    .setFooter({
      text: interaction.guild.name,
        iconURL: interaction.guild.iconURL()
    })
    .setThumbnail(interaction.guild.iconURL())
    .setAuthor({
      name: interaction.user.tag,
        iconURL: interaction.user.displayAvatarURL()
    });
      await interaction.editReply({
        embeds: [embed]
      });

      for (const roleId of roleIds) {
        try {
          await member.roles.add(roleId);
        } catch (error) {
          console.error(`حدث خطأ أثناء إضافة الدور: ${roleId}`, error);
        }
      }

      for (const roleId of roleIds) {
        try {
          await interaction.member.roles.remove(roleId);
        } catch (error) {
          console.error(`حدث خطأ أثناء إزالة الدور: ${roleId}`, error);
        }
      }
    });

    collector.on('end', async (collected) => {
      if (!iscollected) {
        const embed = new EmbedBuilder()
          .setColor('#000100')
          .setDescription(`**انتهى الوقت للتحويل**`);
        await interaction.editReply({
          embeds: [embed]
        });
      }
    });
  }
});