const { EmbedBuilder, ApplicationCommandOptionType , Events , ActionRowBuilder , ButtonBuilder ,MessageAttachment, ButtonStyle , Message, TextInputStyle,TextInputBuilder,ModalBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, PermissionsBitField } = require("discord.js");
module.exports = {
    name: "auction_panel",
    aliases: [],
    owners: true,
    async execute(client, message, args) {
        try {
            const auction = new StringSelectMenuBuilder()
            .setCustomId('auction')
            .setPlaceholder('طلب مزاد')
            .addOptions(
            new StringSelectMenuOptionBuilder()
            .setLabel('طلب مزاد')
            .setValue('auction_1'),
            );
            const row = new ActionRowBuilder()
            .addComponents(auction);
            const embed = new EmbedBuilder()
            .setColor("#000100")
            .setDescription(`**شـروط الـمـزاد | KING S  Rules
> #1 - لعرض مزادك افتح تيكت
> #2 - ممنوع السوالف او اي شي ثاني غير سىعرك
> #3 - ممنوع تقول غالي او مايستاهل
> #4 - ممنوع المزايده اقل من 10K
> #5 - البنك ممنوع إلا لو موجود بالسيرفر
> #6 - تحط سىعر و ما تشتري تاخذ بلاك ليست
> #7 - انعرض مزادك وجاك سىعر اقل من 30K تتعوض بمزاد مجاني
> #8 - التعويض مره واحده فقط
> #9 - اذا كنت ناسخ منشور السلعة من شخص اخر و جاء عليك بلاغ انه منسوخ سوف يتم مخالفتك و ممكن توصل الى بلاك ليست دائم
هنالك ثلاث انواع من المزاد 
1-مزاد عادي مدتة دقيقتين ققط سع3 10k
2-مزاد نادر مدته 4 دقائق  سع3  20k
3-مزاد ملكي مدته 6 دقائق سع3 30k



  
اذا قمت بالتحويل لشخص اخر فنحن لا نتحمل المسؤولية حتى لو اداري قال لك حول للشخص ده
اذا قمت بالتحويل خارج التذكرة فنحن لا نتحمل المسؤولية و لن يتم تعويضك**`)
            .setImage("https://media.discordapp.net/attachments/1249856158458708100/1266813766570344470/Picsart_24-07-27_18-39-38-873.png?ex=66ab2102&is=66a9cf82&hm=943be00d79e951ffb8e6da5924a6d8feb884727ac3c2f7931af6a533d1cb6021&")
              .setAuthor({
                name: message.guild.name,
                iconURL: message.guild.iconURL()
                })
                .setFooter({
                text: message.guild.name,
                iconURL: message.guild.iconURL()
                })
                .setThumbnail(message.guild.iconURL())
                .setTimestamp();
            message.channel.send({ embeds: [embed], components: [row] });
        } catch (error) {
            console.error(error);
            message.reply('There was an error while executing this command!');
        }
    },
};