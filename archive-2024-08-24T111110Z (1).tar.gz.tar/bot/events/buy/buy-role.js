const client = require("../../index.js");
const config = require("../../config.json")
const { EmbedBuilder, ApplicationCommandOptionType , Events , ActionRowBuilder , ButtonBuilder ,MessageAttachment, ButtonStyle , Message, TextInputStyle,TextInputBuilder,ModalBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, PermissionsBitField } = require("discord.js");

const users = require('../../Datebase/model/buy.js');

client.on('interactionCreate', async interaction => {
 if (!interaction.isStringSelectMenu()) return;
 if (interaction.customId === 'buy') {
 const selectedValue = interaction.values[0];
 if (selectedValue === 'role') {
 const role = new StringSelectMenuBuilder()
 .setCustomId('role')
 .setPlaceholder('اختر رتبه')
 .addOptions(
 new StringSelectMenuOptionBuilder()
 .setLabel('Angel S')
.setDescription('سعرها : 75k')
 .setValue('Angel S'),
 new StringSelectMenuOptionBuilder()
 .setLabel('Great S')
 .setDescription('سعرها : 70k')
 .setValue('Great S'),
 new StringSelectMenuOptionBuilder()
 .setLabel('Perfect S')
 .setDescription('سعرها : 65k')
 .setValue('Perfect S'),
 new StringSelectMenuOptionBuilder()
 .setLabel('Excellent S')
 .setDescription('سعرها : 60k')
 .setValue('Excellent S'),
 new StringSelectMenuOptionBuilder()
 .setLabel('Good S')
 .setDescription('سعرها : 55k')
 .setValue('Good S'),
 new StringSelectMenuOptionBuilder()
 .setLabel('Designer S')
 .setDescription('سعرها : 50k')
 .setValue('Designer S'),
 new StringSelectMenuOptionBuilder()
 .setLabel('Developer S')
 .setDescription('سعرها : 45k')
 .setValue('Developer S'),
 );
 new StringSelectMenuOptionBuilder()
 .setLabel('Viking S ')
 .setDescription('سعرها: 50k')
 .setValue('Viking S')

 const row = new ActionRowBuilder()
 .addComponents(role);
   
 const embed = new EmbedBuilder()
 .setColor('#000100')
 .setDescription(
 `**
 <@&1145673256632852501> 
<:emoji_49:1270025870308016169> السعر 75k <:emoji_49:1270025870308016169>
المميزات:
<:emoji_37:1261219316804882514>  تقدر تكتب بجميع الرومات
<:emoji_37:1261219316804882514> تقدر تمنشن 
<:emoji_37:1261219316804882514> تقدر ترسل صور بجميع الرومات 

<@&1145673257090031657> 
<:emoji_49:1270025870308016169> السعر : 70k <:emoji_49:1270025870308016169>
المميزات: 
<:emoji_37:1261219316804882514> تقدر تكتب بكل الرومات عدا  { التصاميم_البرمجيات} 
<:emoji_37:1261219316804882514> تقدر تمنشن 
<:emoji_37:1261219316804882514> تقدر ترسل صور 

<@&1145673258335744112> 
<:emoji_49:1270025870308016169> السعر:65k <:emoji_49:1270025870308016169> 
المميزات:
<:emoji_37:1261219316804882514> تقدر تكتب بكل الرومات عدا {تصاميم_برمجيات} 
<:emoji_37:1261219316804882514> تقدر تمنشن 
<:emoji_37:1261219316804882514>  تقدر ترسل صور في حاسبات فقط

<@&1145673259602415718> 
<:emoji_49:1270025870308016169> السعر:60k <:emoji_49:1270025870308016169>
المميزات:
<:emoji_37:1261219316804882514> تقدر تكتب بكل الرومات عدا {تصاميم_برمجيات}
<:emoji_37:1261219316804882514> تقدر تمنشن
<:emoji_37:1261219316804882514>  ما تقدر ترسل صور

<@&1145673261217235024> 
<:emoji_49:1270025870308016169>  السعر:55k <:emoji_49:1270025870308016169>
المميزات:
<:emoji_37:1261219316804882514> تقدر ترسل في كل الرومات عدا {تصاميم_برمجيات}
<:emoji_37:1261219316804882514> ما تقدر تمشن
<:emoji_37:1261219316804882514>ما تقدر ترسل صور

<@&1145673262181920799> 
<:emoji_49:1270025870308016169> السعر:50k <:emoji_49:1270025870308016169>
المميزات: 
<:emoji_37:1261219316804882514>تقدر ترسل في روم التصاميم فقط 
<:emoji_37:1261219316804882514>تقدر تمنشن في روم تصاميم فقط 
<:emoji_37:1261219316804882514>تقدر ترسل صور في روم تصاميم فقط 

<@&1145673266602704946> 

<:emoji_49:1270025870308016169>السعر:45k <:emoji_49:1270025870308016169>
المميزات:
<:emoji_37:1261219316804882514>تقدر ترسل في روم برمجيات فقط
<:emoji_37:1261219316804882514>تقدر تمنشن في روم برمجيات فقط 
<:emoji_37:1261219316804882514>تقدر ترسل في روم برمجيات فقط



 **`)
   .setTimestamp()
   .setFooter({
     text: interaction.guild.name,
       iconURL: interaction.guild.iconURL()
   })
   .setAuthor({
     name: interaction.guild.name,
       iconURL: interaction.guild.iconURL()
   });
 await interaction.update({
 embeds: [embed],
 components: [row],
  });
      } 
  } else if (interaction.customId === 'role') {
 const selectedValue = interaction.values[0];
if (selectedValue === 'Angel S') {
  let price = config.priceAngelS;
  const result = price; 
  let finalprice = Math.floor(price *(20) / (19) + (1))
  let roleid = config.roleidAngelS;

  let owner = config.owner;
  if(interaction.member.roles.cache.some((role) => role.id === roleid)) return interaction.reply({content:`**انت بالفعل لديك هذه الرتبة  .. **`,ephemeral:true})

  const embed = new EmbedBuilder()
  .setColor('#000100')
  .setDescription(
  `**قم بتحويل ${finalprice} لـ <@${owner}>**\n\`\`\`#credit <@${owner}> ${finalprice}\`\`\``)
  .setTimestamp();
  await interaction.update({
  embeds: [embed],
  components: [],
  })
  await interaction.channel.send({
  content: `#credit ${owner} ${finalprice}`
  })
  const filter = ({ content, author: { id } }) => {
        return (
            content.startsWith(`**:moneybag: | ${interaction.user.username}, has transferred `) &&
            content.includes(`${owner}`) &&
            id === "282859044593598464" &&
                (Number(content.slice(content.lastIndexOf("`") - String(finalprice).length, content.lastIndexOf("`"))) >= result)
        );
    };

    const collector = interaction.channel.createMessageCollector({ 
      filter,               
      max: 1,
      time: 60000,
    });
let iscollected = false;
collector.on('collect', async (collected) => {
  iscollected = true;
  const embed = new EmbedBuilder()
  .setColor('#000100')
  .setDescription(`**تم اعطائك الرتبه بنجاح**`)
  .setTimestamp();
  await interaction.editReply({
  embeds: [embed],
  components: [],
  })
  await interaction.member.roles.add(roleid);
  
const user = await users.deleteOne({ userId: interaction.user.id });
  
const log = client.channels.cache.get(config.role)
const logembed = new EmbedBuilder()
.setColor('#000100')
.setTitle("شراء رتبة")
  
  .addFields(
        {
          name: "تم شراء بواسطة",
          value: `<@${interaction.member.id}>`,
          inline: true
        },
        {
          name: "تم شراء رتبة",
          value: `<@&${roleid}>`,
          inline: true
        },
        {
          name: "المبلغ",
          value: `${finalprice}`,
          inline: true
        }
  ) 
.setColor(`#000100`)
.setThumbnail(interaction.guild.iconURL({dynamic:true}))
    .setTimestamp();
await log.send({embeds:[logembed]})
 })
collector.on('end', async (collected) => {
  if (!iscollected) {
    const embed = new EmbedBuilder()
    .setColor('#000100')
    .setDescription(`**انتهى وقت العمليه**`)
    .setTimestamp();
    await interaction.editReply({
    embeds: [embed],
    components: [],
    })
    const user = await users.deleteOne({ userId: interaction.user.id });
  }
});

   } else if (selectedValue === 'Great S') {
  let price = config.priceGreatS;
  const result = price; 
  let finalprice = Math.floor(price *(20) / (19) + (1))
  let roleid = config.roleidGreatS;

  let owner = config.owner;
  if(interaction.member.roles.cache.some((role) => role.id === roleid)) return interaction.reply({content:`**انت بالفعل لديك هذه الرتبة  .. **`,ephemeral:true})

  const embed = new EmbedBuilder()
  .setColor('#000100')
  .setDescription(
  `**قم بتحويل ${finalprice} لـ <@${owner}>**\n\`\`\`#credit <@${owner}> ${finalprice}\`\`\``)
  .setTimestamp();
  await interaction.update({
  embeds: [embed],
  components: [],
  })
  await interaction.channel.send({
  content: `#credit ${owner} ${finalprice}`
  })
  const filter = ({ content, author: { id } }) => {
        return (
            content.startsWith(`**:moneybag: | ${interaction.user.username}, has transferred `) &&
            content.includes(`${owner}`) &&
            id === "282859044593598464" &&
            (Number(content.slice(content.lastIndexOf("`") - String(finalprice).length, content.lastIndexOf("`"))) >= result)
        );
  };
  const collector = interaction.channel.createMessageCollector({
    filter,               
    max: 1,
    time: 60000,
  })
let iscollected = false;
collector.on('collect', async (collected) => {
  iscollected = true;
  const embed = new EmbedBuilder()
  .setColor('#000100')
  .setDescription(`**تم اعطائك الرتبه بنجاح**`)
  .setTimestamp();
  await interaction.editReply({
  embeds: [embed],
  components: [],
  })
  await interaction.member.roles.add(roleid);
  const user = await users.deleteOne({ userId: interaction.user.id });


  
const log = client.channels.cache.get(config.role)
const logembed = new EmbedBuilder()
.setColor('#000100')
.setTitle("شراء رتبة")
.addFields(
        {
          name: "تم شراء بواسطة",
          value: `<@${interaction.member.id}>`,
          inline: true
        },
        {
          name: "تم شراء رتبة",
          value: `<@&${roleid}>`,
          inline: true
        },
        {
          name: "المبلغ",
          value: `${finalprice}`,
          inline: true
        }
  ) 
.setThumbnail(interaction.guild.iconURL({dynamic:true}))
    .setTimestamp();
await log.send({embeds:[logembed]})
})
collector.on('end', async (collected) => {
  if (!iscollected) {
    const embed = new EmbedBuilder()
    .setColor('#000100')
    .setDescription(`**انتهى وقت العمليه**`)
    .setTimestamp();
    await interaction.editReply({
    embeds: [embed],
    components: [],
    })
    const user = await users.deleteOne({ userId: interaction.user.id });
  }
});
   } else if (selectedValue === 'Perfect S') {
    let price = config.pricePerfectS;
  const result = price; 
  let finalprice = Math.floor(price *(20) / (19) + (1))
  let roleid = config.roleidPerfectS;

  let owner = config.owner;
  if(interaction.member.roles.cache.some((role) => role.id === roleid)) return interaction.reply({content:`**انت بالفعل لديك هذه الرتبة  .. **`,ephemeral:true})

  const embed = new EmbedBuilder()
  .setColor('#000100')
  .setDescription(
  `**قم بتحويل ${finalprice} لـ <@${owner}>**\n\`\`\`#credit <@${owner}> ${finalprice}\`\`\``)
  .setTimestamp();
  await interaction.update({
  embeds: [embed],
  components: [],
  })
  await interaction.channel.send({
  content: `#credit ${owner} ${finalprice}`
  })
  const filter = ({ content, author: { id } }) => {
        return (
            content.startsWith(`**:moneybag: | ${interaction.user.username}, has transferred `) &&
            content.includes(`${owner}`) &&
            id === "282859044593598464" &&
            (Number(content.slice(content.lastIndexOf("`") - String(finalprice).length, content.lastIndexOf("`"))) >= result)
        );
  };
  const collector = interaction.channel.createMessageCollector({
    filter,               
    max: 1,
    time: 60000,
  })
let iscollected = false;
collector.on('collect', async (collected) => {
  iscollected = true;
  const embed = new EmbedBuilder()
  .setColor('#000100')
  .setDescription(`**تم اعطائك الرتبه بنجاح**`)
  .setTimestamp();
  await interaction.editReply({
  embeds: [embed],
  components: [],
  })
  await interaction.member.roles.add(roleid);

  const user = await users.deleteOne({ userId: interaction.user.id });


const log = client.channels.cache.get(config.role)
const logembed = new EmbedBuilder()
.setColor('#000100')
.setTitle("شراء رتبة")
.addFields(
        {
          name: "تم شراء بواسطة",
          value: `<@${interaction.member.id}>`,
          inline: true
        },
        {
          name: "تم شراء رتبة",
          value: `<@&${roleid}>`,
          inline: true
        },
        {
          name: "المبلغ",
          value: `${finalprice}`,
          inline: true
        }
  ) 
.setThumbnail(interaction.guild.iconURL({dynamic:true}))
    .setTimestamp();
await log.send({embeds:[logembed]})
})
collector.on('end', async (collected) => {
  if (!iscollected) {
    const embed = new EmbedBuilder()
    .setColor('#000100')
    .setDescription(`**انتهى وقت العمليه**`)
    .setTimestamp();
    await interaction.editReply({
    embeds: [embed],
    components: [],
    })
    const user = await users.deleteOne({ userId: interaction.user.id });
  }
});

   } else if (selectedValue === 'Excellent S') {
  let price = config.priceExcellentS;
  const result = price; 
  let finalprice = Math.floor(price *(20) / (19) + (1))
  let roleid = config.roleidExcellentS;

  let owner = config.owner;
  if(interaction.member.roles.cache.some((role) => role.id === roleid)) return interaction.reply({content:`**انت بالفعل لديك هذه الرتبة  .. **`,ephemeral:true})

  const embed = new EmbedBuilder()
  .setColor('#000100')
  .setDescription(
  `**قم بتحويل ${finalprice} لـ <@${owner}>**\n\`\`\`#credit <@${owner}> ${finalprice}\`\`\``)
  .setTimestamp();
  await interaction.update({
  embeds: [embed],
  components: [],
  })
  await interaction.channel.send({
  content: `#credit ${owner} ${finalprice}`
  })
  const filter = ({ content, author: { id } }) => {
        return (
            content.startsWith(`**:moneybag: | ${interaction.user.username}, has transferred `) &&
            content.includes(`${owner}`) &&
            id === "282859044593598464" &&
            (Number(content.slice(content.lastIndexOf("`") - String(finalprice).length, content.lastIndexOf("`"))) >= result)
        );
  };
  const collector = interaction.channel.createMessageCollector({
    filter,               
    max: 1,
    time: 60000,
  })
let iscollected = false;
collector.on('collect', async (collected) => {
  iscollected = true;
  const embed = new EmbedBuilder()
  .setColor('#000100')
  .setDescription(`**تم اعطائك الرتبه بنجاح**`)
  .setTimestamp();
  await interaction.editReply({
  embeds: [embed],
  components: [],
  })
  await interaction.member.roles.add(roleid);

const user = await users.deleteOne({ userId: interaction.user.id });
  
const log = client.channels.cache.get(config.role)
const logembed = new EmbedBuilder()
.setColor('#000100')
.setTitle("شراء رتبة")
.addFields(
        {
          name: "تم شراء بواسطة",
          value: `<@${interaction.member.id}>`,
          inline: true
        },
        {
          name: "تم شراء رتبة",
          value: `<@&${roleid}>`,
          inline: true
        },
        {
          name: "المبلغ",
          value: `${finalprice}`,
          inline: true
        }
  ) 
.setThumbnail(interaction.guild.iconURL({dynamic:true}))
    .setTimestamp();
await log.send({embeds:[logembed]})
})
collector.on('end', async (collected) => {
  if (!iscollected) {
    const embed = new EmbedBuilder()
    .setColor('#000100')
    .setDescription(`**انتهى وقت العمليه**`)
    .setTimestamp();
    await interaction.editReply({
    embeds: [embed],
    components: [],
    })
    const user = await users.deleteOne({ userId: interaction.user.id });
  }
});

   } else if (selectedValue === 'Good S') {
    let price = config.priceGoodS;
  
  const result = price; 
  let finalprice = Math.floor(price *(20) / (19) + (1))
  let roleid = config.roleidGoodS;

  let owner = config.owner;
  if(interaction.member.roles.cache.some((role) => role.id === roleid)) return interaction.reply({content:`**انت بالفعل لديك هذه الرتبة  .. **`,ephemeral:true})

  const embed = new EmbedBuilder()
  .setColor('#000100')
  .setDescription(
  `**قم بتحويل ${finalprice} لـ <@${owner}>**\n\`\`\`#credit <@${owner}> ${finalprice}\`\`\``)
  .setTimestamp();
  await interaction.update({
  embeds: [embed],
  components: [],
  })
  await interaction.channel.send({
  content: `#credit ${owner} ${finalprice}`
  })
  const filter = ({ content, author: { id } }) => {
        return (
            content.startsWith(`**:moneybag: | ${interaction.user.username}, has transferred `) &&
            content.includes(`${owner}`) &&
            id === "282859044593598464" &&
            (Number(content.slice(content.lastIndexOf("`") - String(finalprice).length, content.lastIndexOf("`"))) >= result)
        );
  };
  const collector = interaction.channel.createMessageCollector({
    filter,               
    max: 1,
    time: 60000,
  })
let iscollected = false;
collector.on('collect', async (collected) => {
  iscollected = true;
  const embed = new EmbedBuilder()
  .setColor('#000100')
  .setDescription(`**تم اعطائك الرتبه بنجاح**`)
  .setTimestamp();
  await interaction.editReply({
  embeds: [embed],
  components: [],
  })
  await interaction.member.roles.add(roleid);

const user = await users.deleteOne({ userId: interaction.user.id });
  
const log = client.channels.cache.get(config.role)
const logembed = new EmbedBuilder()
.setColor('#000100')
.setTitle("شراء رتبة")
.addFields(
        {
          name: "تم شراء بواسطة",
          value: `<@${interaction.member.id}>`,
          inline: true
        },
        {
          name: "تم شراء رتبة",
          value: `<@&${roleid}>`,
          inline: true
        },
        {
          name: "المبلغ",
          value: `${finalprice}`,
          inline: true
        }
  ) 
.setThumbnail(interaction.guild.iconURL({dynamic:true}))
    .setTimestamp();
await log.send({embeds:[logembed]})
})
collector.on('end', async (collected) => {
  if (!iscollected) {
    const embed = new EmbedBuilder()
    .setColor('#000100')
    .setDescription(`**انتهى وقت العمليه**`)
    .setTimestamp();
    await interaction.editReply({
    embeds: [embed],
    components: [],
    })
    const user = await users.deleteOne({ userId: interaction.user.id });
  }
});

   } else if (selectedValue === 'Designer S') {
      let price = config.priceDesignerS;
  const result = price; 
  let finalprice = Math.floor(price *(20) / (19) + (1))
  let roleid = config.roleidDesignerS;

  let owner = config.owner;
  if(interaction.member.roles.cache.some((role) => role.id === roleid)) return interaction.reply({content:`**انت بالفعل لديك هذه الرتبة  .. **`,ephemeral:true})

  const embed = new EmbedBuilder()
  .setColor('#000100')
  .setDescription(
  `**قم بتحويل ${finalprice} لـ <@${owner}>**\n\`\`\`#credit <@${owner}> ${finalprice}\`\`\``)
  .setTimestamp();
  await interaction.update({
  embeds: [embed],
  components: [],
  })
  await interaction.channel.send({
  content: `#credit ${owner} ${finalprice}`
  })
  const filter = ({ content, author: { id } }) => {
        return (
            content.startsWith(`**:moneybag: | ${interaction.user.username}, has transferred `) &&
            content.includes(`${owner}`) &&
            id === "282859044593598464" &&
            (Number(content.slice(content.lastIndexOf("`") - String(finalprice).length, content.lastIndexOf("`"))) >= result)
        );
  };
  const collector = interaction.channel.createMessageCollector({
    filter,               
    max: 1,
    time: 60000,
  })
let iscollected = false;
collector.on('collect', async (collected) => {
  iscollected = true;
  const embed = new EmbedBuilder()
  .setColor('#000100')
  .setDescription(`**تم اعطائك الرتبه بنجاح**`)
  .setTimestamp();
  await interaction.editReply({
  embeds: [embed],
  components: [],
  })
  await interaction.member.roles.add(roleid);

const user = await users.deleteOne({ userId: interaction.user.id });
  
const log = client.channels.cache.get(config.role)
const logembed = new EmbedBuilder()
.setColor('#000100')
.setTitle("شراء رتبة")
.addFields(
        {
          name: "تم شراء بواسطة",
          value: `<@${interaction.member.id}>`,
          inline: true
        },
        {
          name: "تم شراء رتبة",
          value: `<@&${roleid}>`,
          inline: true
        },
        {
          name: "المبلغ",
          value: `${finalprice}`,
          inline: true
        }
  ) 
.setThumbnail(interaction.guild.iconURL({dynamic:true}))
    .setTimestamp();
await log.send({embeds:[logembed]})
})
collector.on('end', async (collected) => {
  if (!iscollected) {
    const embed = new EmbedBuilder()
    .setColor('#000100')
    .setDescription(`**انتهى وقت العمليه**`)
    .setTimestamp();
    await interaction.editReply({
    embeds: [embed],
    components: [],
    })
    const user = await users.deleteOne({ userId: interaction.user.id });
  }
});

   } else if (selectedValue === 'Developer S') {
  let price = config.priceDeveloperS;
  const result = price; 
  let finalprice = Math.floor(price *(20) / (19) + (1))
  let roleid = config.roleidDeveloperS;

  let owner = config.owner;
  if(interaction.member.roles.cache.some((role) => role.id === roleid)) return interaction.reply({content:`**انت بالفعل لديك هذه الرتبة  .. **`,ephemeral:true})

  const embed = new EmbedBuilder()
  .setColor('#000100')
  .setDescription(
  `**قم بتحويل ${finalprice} لـ <@${owner}>**\n\`\`\`#credit <@${owner}> ${finalprice}\`\`\``)
  .setTimestamp();
  await interaction.update({
  embeds: [embed],
  components: [],
  })
  await interaction.channel.send({
  content: `#credit ${owner} ${finalprice}`
  })
  const filter = ({ content, author: { id } }) => {
        return (
            content.startsWith(`**:moneybag: | ${interaction.user.username}, has transferred `) &&
            content.includes(`${owner}`) &&
            id === "282859044593598464" &&
            (Number(content.slice(content.lastIndexOf("`") - String(finalprice).length, content.lastIndexOf("`"))) >= result)
        );
  };
  const collector = interaction.channel.createMessageCollector({
    filter,               
    max: 1,
    time: 60000,
  })
let iscollected = false;
collector.on('collect', async (collected) => {
  iscollected = true;
  const embed = new EmbedBuilder()
  .setColor('#000100')
  .setDescription(`**تم اعطائك الرتبه بنجاح**`)
  .setTimestamp();
  await interaction.editReply({
  embeds: [embed],
  components: [],
  })
  await interaction.member.roles.add(roleid);

const user = await users.deleteOne({ userId: interaction.user.id });
  
const log = client.channels.cache.get(config.role)
const logembed = new EmbedBuilder()
.setColor('#000100')
.setTitle("شراء رتبة")
.addFields(
        {
          name: "تم شراء بواسطة",
          value: `<@${interaction.member.id}>`,
          inline: true
        },
        {
          name: "تم شراء رتبة",
          value: `<@&${roleid}>`,
          inline: true
        },
        {
          name: "المبلغ",
          value: `${finalprice}`,
          inline: true
        }
  ) 
.setThumbnail(interaction.guild.iconURL({dynamic:true}))
    .setTimestamp();
await log.send({embeds:[logembed]})
})
collector.on('end', async (collected) => {
  if (!iscollected) {
    const embed = new EmbedBuilder()
    .setColor('#000100')
    .setDescription(`**انتهى وقت العمليه**`)
    .setTimestamp();
    await interaction.editReply({
    embeds: [embed],
    components: [],
    })
    const user = await users.deleteOne({ userId: interaction.user.id });
  }
    });
       
 } else if (selectedValue === 'Viking S') {
  let price = config.priceDeveloperS;
  const result = price; 
  let finalprice = Math.floor(price *(20) / (19) + (1))
  let roleid = config.roleidVikingS;

  let owner = config.owner;
  if(interaction.member.roles.cache.some((role) => role.id === roleid)) return interaction.reply({content:`**انت بالفعل لديك هذه الرتبة  .. **`,ephemeral:true})

  const embed = new EmbedBuilder()
  .setColor('#000100')
  .setDescription(
  `**قم بتحويل ${finalprice} لـ <@${owner}>**\n\`\`\`#credit <@${owner}> ${finalprice}\`\`\``)
  .setTimestamp();
  await interaction.update({
  embeds: [embed],
  components: [],
  })
  await interaction.channel.send({
  content: `#credit ${owner} ${finalprice}`
  })
  const filter = ({ content, author: { id } }) => {
        return (
            content.startsWith(`**:moneybag: | ${interaction.user.username}, has transferred `) &&
            content.includes(`${owner}`) &&
            id === "282859044593598464" &&
            (Number(content.slice(content.lastIndexOf("`") - String(finalprice).length, content.lastIndexOf("`"))) >= result)
        );
  };
  const collector = interaction.channel.createMessageCollector({
    filter,               
    max: 1,
    time: 60000,
  })
let iscollected = false;
collector.on('collect', async (collected) => {
  iscollected = true;
  const embed = new EmbedBuilder()
  .setColor('#000100')
  .setDescription(`**تم اعطائك الرتبه بنجاح**`)
  .setTimestamp();
  await interaction.editReply({
  embeds: [embed],
  components: [],
  })
  await interaction.member.roles.add(roleid);

const user = await users.deleteOne({ userId: interaction.user.id });
  
const log = client.channels.cache.get(config.role)
const logembed = new EmbedBuilder()
.setColor('#000100')
.setTitle("شراء رتبة")
.addFields(
        {
          name: "تم شراء بواسطة",
          value: `<@${interaction.member.id}>`,
          inline: true
        },
        {
          name: "تم شراء رتبة",
          value: `<@&${roleid}>`,
          inline: true
        },
        {
          name: "المبلغ",
          value: `${finalprice}`,
          inline: true
        }
  ) 
.setThumbnail(interaction.guild.iconURL({dynamic:true}))
    .setTimestamp();
await log.send({embeds:[logembed]})
})
collector.on('end', async (collected) => {
  if (!iscollected) {
    const embed = new EmbedBuilder()
    .setColor('#000100')
    .setDescription(`**انتهى وقت العمليه**`)
    .setTimestamp();
    await interaction.editReply({
    embeds: [embed],
    components: [],
    })
    const user = await users.deleteOne({ userId: interaction.user.id });
  }
});

   }
 }
});

