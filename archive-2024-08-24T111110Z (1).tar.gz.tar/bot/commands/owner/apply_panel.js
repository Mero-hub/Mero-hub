const { EmbedBuilder, ButtonStyle, ButtonBuilder, ActionRowBuilder } = require("discord.js");
module.exports = {
        name: "apply-panel",
        aliases: [],
         owners: true,
         async execute(client, message, args) {
          try{
          const row = new ActionRowBuilder()
          .addComponents(
            new ButtonBuilder()
            .setCustomId('support_apply')
            .setLabel('تقديم اداره')
            .setStyle(ButtonStyle.Secondary),
            new ButtonBuilder()
            .setCustomId("mediator_apply")
            .setLabel("تقديم وسطاء")
          .setStyle(ButtonStyle.Secondary)
            .setDisabled(true),
            new ButtonBuilder()
            .setCustomId("report_apply")
            .setLabel('تقديم قضاه')
           .setStyle(ButtonStyle.Secondary)
           .setDisabled(true)
          );
          const embed = new EmbedBuilder()
          .setColor('#000100')
          .setTitle('تقديم على ادارة سيرفر KING S')
          .setDescription(`
- يوجد للادارة رواتب ( 2500 كريدت على كل تكت - 1500 كريدت على كل تحذير )
- يوجد للقضاة رواتب ( 4000 كريدت على كل تكت )
- يوجد للوسطاء نسبة ( 5% ) من المبلغ التوسط ( تاخده من الي فتحوا التكت.. )
- الشعار للقضاة و الادارة اجباري و ليس اختياري 
- الضمان للتقديم على الوسيط اجباري و ليس اختياري ( الضمان ما يرجع في حالة الاستقالة - الفصال )
- مبالغ الضمانات للوسطاء :

وسيط 1 = 450k
وسيط 2 = 1.05m
وسيط 3 = 2.5m
وسيط 4 = 3m
وسيط 5 = 4m
- رتبة بيـع خاصة لطاقم الادارة طول فترة تواجدك 
- منشورات مميزة كل ما زاد تفاعلك 
- رتبه افضل اداري اسبوعيا..`)
          .setAuthor({
            name: message.guild.name,
            iconURL: message.guild.iconURL()
          })
          .setFooter({
            text: message.guild.name,
            iconURL: message.guild.iconURL()
          })
          .setThumbnail(message.guild.iconURL())
          .setImage('https://media.discordapp.net/attachments/1249856158458708100/1267070830492516362/82fbde3cdddd9b41.jpg?ex=66aabeeb&is=66a96d6b&hm=2d655cfe8d37ffa70db309053a6f5fcbd63582c6d41b3cb329e7e515ec4b4bf7&')
          .setTimestamp();
          message.channel.send({ embeds: [embed], components: [row] });
       } catch (error) {
            console.error(error);
            message.reply('There was an error while executing this command!');
   
       }
   },
};