const { EmbedBuilder, ApplicationCommandOptionType , Events , ActionRowBuilder , ButtonBuilder ,MessageAttachment, ButtonStyle , Message, TextInputStyle,TextInputBuilder,ModalBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, PermissionsBitField } = require("discord.js");
module.exports = {
    name: "mediator_panel",
    aliases: [],
    owners: true,
    async execute(client, message, args) {
        try{
        const mediator = new StringSelectMenuBuilder()
        .setCustomId('mediator')
        .setPlaceholder('طلب وسيط')
        .addOptions(
        new StringSelectMenuOptionBuilder()
        .setLabel('وسيط 1')
        .setValue('mediator_1'),
        new StringSelectMenuOptionBuilder()
        .setLabel('وسيط 2')
        .setValue('mediator_2'),
        new StringSelectMenuOptionBuilder()
        .setLabel('وسيط 3')
        .setValue('mediator_3'),
        new StringSelectMenuOptionBuilder()
        .setLabel('وسيط 4')
        .setValue('mediator_4'),
        new StringSelectMenuOptionBuilder()
        .setLabel('وسيط 5')
        .setValue('mediator_5'),
          new StringSelectMenuOptionBuilder()
          .setLabel('Reset')
          .setValue('reset'),
        );
        const row = new ActionRowBuilder()
        .addComponents(mediator);
        const embed = new EmbedBuilder()
        .setColor("#000100")
        .setDescription(`** اطلب وسيط من عندنا عشان تضمن حقك ولو نصب عليك الوسيط داخل التكت بيتم تعويضك لكن اذا خارج التذكرة ما نعوضك 
₰ 丨 الـوسـيـط 1 مـن [ 0 ] الي  [400,000]

₰ 丨 الـوسـيـط 2 مـن [400,000] الي  [600,000]

₰ 丨 الـوسـيـط 3 مـن [600,000] الي  [800,000]

₰ 丨 الـوسـيـط 4 مـن [800,000] الي  [1,600,000]

₰ 丨 الـوسـيـط 5  مـن [1,600,000] الي  [3,200,000]\n.  يرجى طلب وسيط على حسب المبلغ المراد والتأكد من رتبة الوسيط و حده الذي يستطيع التوسط عليه. **`)
          .setImage("https://media.discordapp.net/attachments/1249856158458708100/1266791369750351972/1000359736.png?ex=66ab0c26&is=66a9baa6&hm=000a65d6385633993b85e461f1da3ac720015725abd5937552fa0e50488cf81e&")
        .setAuthor({
        name: message.guild.name,
        iconURL: message.guild.iconURL()
        })
        .setFooter({
        text: message.guild.name,
        iconURL: message.guild.iconURL()
        })
        .setThumbnail(message.guild.iconURL())
        .setTimestamp();
        message.channel.send({ embeds: [embed], components: [row] });
        } catch (error) {
            console.error(error);
            message.reply('There was an error while executing this command!');
        }
    },
};