const client = require("../../index.js");
const { EmbedBuilder, ApplicationCommandOptionType , Events , ActionRowBuilder , ButtonBuilder ,MessageAttachment, ButtonStyle , Message, TextInputStyle,TextInputBuilder,ModalBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, PermissionsBitField } = require("discord.js");
client.on(Events.InteractionCreate, async interaction => {
  
if (!interaction.isStringSelectMenu()) return;
    const selectedValue = interaction.values[0];
    if (selectedValue === "reset") {
      try{
        
      interaction.update().catch(async() => {return;})
            } catch  {
              return;
      }
    }
  });