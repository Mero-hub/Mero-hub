const client = require("../../index.js");
const { EmbedBuilder, ActionRowBuilder , ButtonBuilder , ButtonStyle, TextInputStyle,TextInputBuilder,ModalBuilder } = require("discord.js");

const counters = require('../../Datebase/model/counters/support.js');
const config = require('../../config.json')

client.on('interactionCreate', async interaction => {
  if (!interaction.isStringSelectMenu()) return;

  if (interaction.customId === 'ticket') {
    const selectedValue = interaction.values[0];

    if (selectedValue === 'support') {
      const modal = new ModalBuilder()
        .setCustomId('supportModal')
        .setTitle('ما سبب فتح التذكرة؟');

      const supportNameInput = new TextInputBuilder()
        .setCustomId('reson')
        .setLabel('ما سبب فتح التذكرة؟')
        .setStyle(TextInputStyle.Short);

      const firstActionRow = new ActionRowBuilder().addComponents(supportNameInput);

      modal.addComponents(firstActionRow);

      await interaction.showModal(modal);
    }
  } 
});





client.on('interactionCreate', async interaction => {
  if (!interaction.isModalSubmit()) return;
  if (interaction.customId === 'supportModal') {
    const reson = interaction.fields.getTextInputValue('reson');
    

    const counter = await counters.updateOne(
      { guildId: interaction.guild.id },
      { $inc: { counter: 1 } },
      { upsert: true }
    );

    const findCount = await counters.findOne({ guildId: interaction.guild.id });

      const ctr = findCount.counter

      const ticket = await interaction.guild.channels.create({
        name: `support-${ctr}`,
        type: 0,
        parent: '1145673330825908224',
        permissionOverwrites: [
          {
            id: interaction.guild.id,
            deny: ['ViewChannel'],
          },
          {
            id: interaction.user.id,
            allow: ['ViewChannel'],
          },
          {
            id: "1145673291395239996",
            allow: ['ViewChannel'],
          },
        ],
      });

        await interaction.reply({
            content: `تم إنشاء تذكرتك في ${ticket}`,
            ephemeral: true,
          }); 

      const row = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId('buy')
            .setLabel('شراء')
.setStyle(ButtonStyle.Secondary),
          new ButtonBuilder()
          .setCustomId('transfer-role')
          .setLabel('نقل رتب البيع')
          .setStyle(ButtonStyle.Secondary),
          new ButtonBuilder()
            .setCustomId('help')
            .setLabel('مساعدة الإدارة')
          .setStyle(ButtonStyle.Secondary),
          new ButtonBuilder()
          .setCustomId('claim')
            .setLabel('استلام التذكره')
          .setStyle(ButtonStyle.Secondary),
          new ButtonBuilder()
          .setCustomId('delete_ticket')
            .setLabel('حذف التذكره')
          .setStyle(ButtonStyle.Secondary)
        );
      const embed = new EmbedBuilder()
        .setColor('#000100')
        .setDescription(`**- اهلا وسهلا في تكت الدعم الفني الجديدة
        
- يمكنك شراء شي معين اذا كنت عضو من خلال الازرار بالاسفل\n \`\`\`${reson}\`\`\`**`)
        .setImage('https://media.discordapp.net/attachments/1249856158458708100/1266791369360412705/Picsart_24-07-27_15-18-58-203.png?ex=66ab0c26&is=66a9baa6&hm=7856ab5b068174fad767f222689ab129d07c44887f6cf64259743610b26af8b1&')
        .setAuthor({
        name: interaction.guild.name,
        iconURL: interaction.guild.iconURL()})
        .setFooter({
        text: interaction.guild.name,
          iconURL: interaction.guild.iconURL()
        })

        .setThumbnail(interaction.guild.iconURL())

    .setTimestamp();
      await ticket.send({
        content: `${interaction.user}||<@&1145673291395239996>`,
        components: [row],
        embeds: [embed],
      });

 
    }
});