const client = require("../../index.js");
const { EmbedBuilder, ApplicationCommandOptionType , Events , ActionRowBuilder , ButtonBuilder ,MessageAttachment, ButtonStyle , Message, TextInputStyle,TextInputBuilder,ModalBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, PermissionsBitField } = require("discord.js");
const scammers = require('../../Datebase/model/scammers.js');
const config = require('../../config.json');

client.on('interactionCreate', async interaction => {
  if (!interaction.isButton()) return;
  if (interaction.customId === 'get_report') {

    if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) return interaction.reply({ content: `**هنهزر يسطا ولا ايه**`, ephemeral: true });
    
    const modal = new ModalBuilder()
      .setCustomId('get_modal')
      .setTitle('رفع بلاغ')
    const reporter_id = new TextInputBuilder()
      .setCustomId('report_id')
      .setLabel("ايدي صاحب البلاغ")
.setStyle(TextInputStyle.Short)
      .setRequired(true);
    const scamer_id = new TextInputBuilder()
   .setCustomId('scamer_id')
      .setLabel("ايدي النصاب")
.setStyle(TextInputStyle.Short)
      .setRequired(true);
    const the_story = new TextInputBuilder()
      .setCustomId('the_story')
      .setLabel("القصه")
.setStyle(TextInputStyle.Paragraph)
      .setRequired(true);
    const price = new TextInputBuilder()
      .setCustomId('price_get')
      .setLabel("المبلغ")
.setStyle(TextInputStyle.Short)
      .setRequired(true);
    const Evidence = new TextInputBuilder()
      .setCustomId('evidence')
      .setLabel("الدلائل (روابط الصور فقط)")
.setStyle(TextInputStyle.Paragraph)
      .setRequired(true);
    const firstActionRow = new ActionRowBuilder().addComponents(reporter_id);
    const secondActionRow = new ActionRowBuilder().addComponents(scamer_id);
    const thirdActionRow = new ActionRowBuilder().addComponents(the_story);
    const fourthActionRow = new ActionRowBuilder().addComponents(price);
    const fifthActionRow = new ActionRowBuilder().addComponents(Evidence);
    modal.addComponents(firstActionRow, secondActionRow, thirdActionRow, fourthActionRow, fifthActionRow)
    await interaction.showModal(modal);
  }
});
client.on('interactionCreate', async interaction => {
  if (!interaction.isModalSubmit()) return;
  if (interaction.customId === 'get_modal') {
    const reporter_id = interaction.fields.getTextInputValue('report_id');
    const scamer_id = interaction.fields.getTextInputValue('scamer_id');
    const the_story = interaction.fields.getTextInputValue('the_story');
    const price = interaction.fields.getTextInputValue('price_get');
    const Evidence = interaction.fields.getTextInputValue('evidence');
    const channel = client.channels.cache.get("1268172091266564206");
    const embed = new EmbedBuilder()
      .setTitle("تم رفع بلاغ جديد")
      .addFields(
        {
          name: "القاضي",
          value: `${interaction.user}`
        },
        {
          name: "العضو المنصوب عليه",
          value: `<@${reporter_id}>\n(${reporter_id})`
        },
        {
          name: "النصاب",
          value: `<@${scamer_id}>\n(${scamer_id})`
        },
        {
          name: "القصه",
          value: `${the_story}`
        },
        {
          name: "المبلغ",
          value: `${price}`
        },
        {
          name: "الدلائل",
          value: `⬇️⬇️`
        }
      )
      .setColor('#000100')
      .setTimestamp();
    channel.send({ embeds: [embed] });
    await channel.send({ files: [Evidence] });
    await interaction.reply({
      content: `تم رفع البلاغ بنجاح`,
      ephemeral: true,
    })
    const row = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId('Submit_report')
            .setLabel('تقديم بلاغ')
.setStyle(ButtonStyle.Secondary)
            .setDisabled(true),
          new ButtonBuilder()
            .setCustomId('get_report')
            .setLabel('رفع بلاغ')
          .setStyle(ButtonStyle.Secondary)
            .setDisabled(true),
          new ButtonBuilder()
          .setCustomId('report_claim')
            .setLabel('استلام التذكره')
          .setStyle(ButtonStyle.Secondary),
          new ButtonBuilder()
            .setCustomId('report_help')
            .setLabel('مساعده القضاه')
          .setStyle(ButtonStyle.Secondary),
          new ButtonBuilder()
          .setCustomId('report_delete_ticket')
            .setLabel('حذف التذكره')
          .setStyle(ButtonStyle.Secondary)
        );
    await interaction.message.edit({ components: [row] });
    


const newScammer = new scammers({
      guildID: interaction.guild.id,
      userID: scamer_id,
      reason: the_story,
      time: Date.now(),
    });

    await newScammer.save();
    await scamer_id.member.roles.add(config.scammer_role);
  
  }
});