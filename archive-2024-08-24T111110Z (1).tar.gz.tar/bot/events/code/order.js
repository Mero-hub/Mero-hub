const client = require("../../index.js");
const { EmbedBuilder, ApplicationCommandOptionType , Events , ActionRowBuilder , ButtonBuilder ,MessageAttachment, ButtonStyle , Message, TextInputStyle,TextInputBuilder,ModalBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, PermissionsBitField } = require("discord.js");





client.on('interactionCreate', async interaction => {
  if (!interaction.isButton()) return;

  if (interaction.customId === 'products') {
    const modal = new ModalBuilder()
      .setCustomId('productModal')
      .setTitle('أكمال عملية الطلب');

    const productNameInput = new TextInputBuilder()
      .setCustomId('productName')
      .setLabel('ما هو طلبك؟')
      .setStyle(TextInputStyle.Short);

    const firstActionRow = new ActionRowBuilder().addComponents(productNameInput);

    modal.addComponents(firstActionRow);

    await interaction.showModal(modal);
  } else if (interaction.customId === 'design') {
    const modal = new ModalBuilder()
      .setCustomId('designModal')
    .setTitle('أكمال عملية الطلب');

    const designNameInput = new TextInputBuilder()
      .setCustomId('designName')
      .setLabel('ما هو طلبك؟')
      .setStyle(TextInputStyle.Short);

    const firstActionRow = new ActionRowBuilder().addComponents(designNameInput);

    modal.addComponents(firstActionRow);

    await interaction.showModal(modal);
  } else if (interaction.customId === 'program') {
    const modal = new ModalBuilder()
      .setCustomId('programModal')
      .setTitle('أكمال عملية الطلب');

    const programNameInput = new TextInputBuilder()
      .setCustomId('programName')
      .setLabel('ما هو طلبك؟')
      .setStyle(TextInputStyle.Short);

    const firstActionRow = new ActionRowBuilder().addComponents(programNameInput);

    modal.addComponents(firstActionRow);

    await interaction.showModal(modal);
  }
});
client.on('interactionCreate', async interaction => {
  if (!interaction.isModalSubmit()) return;

  if (interaction.customId === 'productModal') {
    const productName = interaction.fields.getTextInputValue('productName');
    const channel = interaction.guild.channels.cache.get('1145673404083617792')

    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('delete')
          .setLabel('حذف الطلب')
          .setStyle(ButtonStyle.Secondary)
      );

    const embed = new EmbedBuilder()
      .setColor('#000100')
      .setTitle('**طلب جديد**')
      .setDescription(`\`\`\`${productName}\`\`\``)
    .setAuthor({
        name: interaction.guild.name,
        iconURL: interaction.guild.iconURL()})
        .setFooter({
        text: interaction.guild.name,
          iconURL: interaction.guild.iconURL()
        })

        .setThumbnail(interaction.guild.iconURL())

    .setTimestamp();
    
    await interaction.reply({ content: 'تم إرسال طلبك بنجاح!', ephemeral: true });

    await channel.send({ 
      content: `
  صاحب الطلب : <@${interaction.user.id}>
  For : <@&1145673280028688434>`,
      components: [row],
      embeds: [embed] });
  } else if (interaction.customId === 'designModal') {
    const designName = interaction.fields.getTextInputValue('designName');
    const channel1 = interaction.guild.channels.cache.get('1145673402665947177')
    
    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('delete')
          .setLabel('حذف الطلب')
          .setStyle(ButtonStyle.Secondary)
      );

    const embed = new EmbedBuilder()
      .setColor('#000100')
      .setTitle('**طلب جديد**')
      .setDescription(`\`\`\`${designName}\`\`\``)
    .setAuthor({
        name: interaction.guild.name,
        iconURL: interaction.guild.iconURL()})
        .setFooter({
        text: interaction.guild.name,
          iconURL: interaction.guild.iconURL()
        })

        .setThumbnail(interaction.guild.iconURL())

    .setTimestamp();
    
    await interaction.reply({ content: 'تم ارسال طلبك بنجاح!', ephemeral: true });

    await channel1.send({ 
      content: `
    صاحب الطلب : <@${interaction.user.id}>
    For : <@&1145673280028688434>`,
      components: [row],
      embeds: [embed] });
  } else if (interaction.customId === 'programModal') {
    const programName = interaction.fields.getTextInputValue('programName');
    const channel2 = interaction.guild.channels.cache.get('1145673405400621137')

    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('delete')
          .setLabel('حذف الطلب')
          .setStyle(ButtonStyle.Secondary)
      );

    const embed = new EmbedBuilder()
      .setColor('#000100')
      .setTitle('**طلب جديد**')
      .setDescription(`\`\`\`${programName}\`\`\``)
    .setAuthor({
        name: interaction.guild.name,
        iconURL: interaction.guild.iconURL()})
        .setFooter({
        text: interaction.guild.name,
          iconURL: interaction.guild.iconURL()
        })

        .setThumbnail(interaction.guild.iconURL())

    .setTimestamp();
    
    await interaction.reply({ content: 'تم ارسال طلبك بنجاح!', ephemeral: true });

    await channel2.send({ 
      content: `
    صاحب الطلب : <@${interaction.user.id}>
    For : <@&1145673280028688434>`,
      components: [row],
      embeds: [embed] });
  }
});
client.on('interactionCreate', async interaction => {
  if (!interaction.isButton()) return;
  if (interaction.customId === 'delete') {
  if (!interaction.member.permissions.has('MOVE_MEMBERS')) {
    return interaction.reply({ content: 'لا يمكنك استخدام هذا الزر!', ephemeral: true });
    }
  await interaction.reply({ content: 'تم حذف الطلب بنجاح!', ephemeral: true });
    await interaction.message.delete();
  }
});