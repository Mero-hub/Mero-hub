require("dotenv").config();

const { Client, Collection, Partials, GatewayIntentBits, EmbedBuilder, ApplicationCommandType, ContextMenuCommandBuilder, PermissionFlagsBits, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { REST } = require('@discordjs/rest');
const { Routes } = require('discord-api-types/v10');

//mongoose
const Mongoose = require('mongoose');

const client = new Client({
    intents: 3276799,
    partials: [
        Partials.Message,
        Partials.Channel,
        Partials.GuildMember,
        Partials.Reaction,
        Partials.GuildScheduledEvent,
        Partials.User,
        Partials.ThreadMember
    ],
    shards: "auto",
}); 







module.exports = client;
client.commands = new Collection();
client.events = new Collection();
client.slashCommands = new Collection();
['Commands', 'Events'].forEach(handler => {
    require(`./handlers/${handler}`)(client);
})

//nodejs-events
process.on("unhandledRejection", e => {
    console.log(e)
})
process.on("uncaughtException", e => {
    console.log(e)
})
process.on("uncaughtExceptionMonitor", e => {
    console.log(e)
})
//mongo connect
Mongoose.connect("mongodb+srv://20082008EEEE:20082008EEEE@cluster0.uvpf7.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0").then(() => console.log('Datebase is connected')).catch((err) => console.log('Datebase Field to connected', err))




const line = "https://media.discordapp.net/attachments/1266387530274705438/1271391398016319611/1000311801.png?ex=66b72b02&is=66b5d982&hm=06fdd2f297f01e169a3d6a6b2392f63d1ff5554df86bc27569ccdcf2d8456729&"
///////////////line////////////////////////////////////////////////
client.on('messageCreate', async message => {
    if (message.content.startsWith('خطط')) {
        message.delete()
        message.channel.send({
            content: `${line}`
        })
    }
});

let autotax = ['1145673417559912499'];

client.on("messageCreate", message => {
  if (message.channel.type === "dm" ||
    message.author.bot) return

  if (autotax.includes(message.channel.id)) {

    var args = message.content.split(' ').slice(0).join(' ')
    if (!args) return;

    if (args.endsWith("m")) args = args.replace(/m/gi, "") * 1000000;
    else if (args.endsWith("k")) args = args.replace(/k/gi, "") * 1000;
    else if (args.endsWith("K")) args = args.replace(/K/gi, "") * 1000;
    else if (args.endsWith("M")) args = args.replace(/M/gi, "") * 1000000;
    let args2 = parseInt(args)
    let tax = Math.floor(args2 * (20) / (19) + (1))
    let tax2 = Math.floor(args2 * (20) / (19) + (1) - (args2))
    let tax3 = Math.floor(tax2 * (20) / (19) + (1))
    let tax4 = Math.floor(tax2 + tax3 + args2);
    let tax5 = Math.floor((2.5 / 100) * args)
    let tax6 = Math.floor(tax4 + args2 * (20) / (19) + (1) - (args2));
    let tax7 = Math.floor(tax + tax5)
    let tax8 = Math.floor(tax4 + tax5)
    let tax9 = Math.floor((5 / 100) * args - args * -0)
    let tax10 = Math.floor(tax - args)
    let tax11 = Math.floor(tax9 + tax10)
    let tax12 = Math.floor(tax - tax11)


    let embed = new EmbedBuilder()



      .setThumbnail(message.guild.iconURL())
      .setFooter({
        text: message.guild.name,
          iconURL: message.guild.iconURL()
        })
      

      .addFields(
        {
          name: "> **السعر بدون ضرائب :**", value: `**\`${args}\`**`
        },
        {
          name: "> **السعر مع ضرائب :**", value: `**\`${tax}\`**`
        },
        {
          name: "> **ضرائب الوسيط بدون نسبة :**", value: `**\`${tax4}\`**`
        },
        {
          name: "> **ضرائب الوسيط مع نسبة :**", value: `**\`${tax6}\`**`
        },
        {
          name: "> **نسبة الوسيط :**", value: `**\`${tax9}\`**`
        },
        {
          name: "> **تحويل بدون ضرائب :**", value: `**\`${tax12}\`**`
        })

      .setTimestamp()
    
message.delete()
    message.channel.send({ embeds: [embed] }).catch((err) => {
      console.log(err.message)
    });
  }
});

/////////////autoline///////////
let rooms = ["1145673393249714227","1145673388543709204","1145673388543709204","1145673386828243034","1145673383405695037","1145673385012117594","1145673417559912499","1145673397456601198","1145673396210896896","1145673394679975969","1145673398828154973","","1145673422022643812","1255854322906959933","",""];
let lines = 'https://media.discordapp.net/attachments/1266387530274705438/1271391398016319611/1000311801.png?ex=66b72b02&is=66b5d982&hm=06fdd2f297f01e169a3d6a6b2392f63d1ff5554df86bc27569ccdcf2d8456729&'
client.on("messageCreate", message => {
  if (message.author.bot) return;
  if (rooms.includes(message.channel.id)) {
    message.channel.send({ content: `${lines}` });
  }
});
//suggtion
let sug = ["1145673422022643812"]; // حط اي دي روم الاقتراحات
client.on("messageCreate", function(message) {
        let args = message.content.split(",");
  if (message.author.bot) return;
if(sug.includes(message.channel.id)) {
    message.delete()
    const embed = new EmbedBuilder()
      .setThumbnail(message.guild.iconURL())
      .setFooter({
        text: message.guild.name,
          iconURL: message.guild.iconURL()
        })
      .setAuthor({
        name: message.guild.name,
          iconURL: message.guild.iconURL()
      })
.setColor("#000100")
.setDescription(`> **${args}**`)
.setTimestamp();
message.channel.send({ 
content: `- اقتراح جديد من قبل : <@${message.author.id}>`,
embeds: [embed] });
}
});
//feedback
let fed = ["1255854322906959933"];
client.on("messageCreate", function(message) {
        let args = message.content.split(",");
  if (message.author.bot) return;
if(fed.includes(message.channel.id)) {
    message.delete()
    const embed = new EmbedBuilder()
.setAuthor({
        name: message.guild.name,
          iconURL: message.guild.iconURL()
        })
.setColor("#000100")
.setThumbnail(message.guild.iconURL())
.setFooter({
        text: message.guild.name,
          iconURL: message.guild.iconURL()
        })

.setTitle("شكرا لرأيك يحبيبي")
.setDescription(`> feedback **${args}**`)
.setTimestamp();
message.channel.send({ 
content: `> **<@${message.author.id}>**`,
embeds: [embed] });
}
});






/////////
const roleStatus = {};


client.on('messageCreate', async (message) => {
    if (message.content === 'طلبات') {
        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('button1')
                    .setLabel('اشعار طلبات')
                    .setStyle(ButtonStyle.Primary)
            )           
      const emb = new EmbedBuilder()
      .setColor("#ffffff")
      .setTitle(`اشعارات الطلبات`)
      .setDescription(`اضغط على الزر لتستطيع تلقي اشعارات الطلبات`)
      .setTimestamp()

        await message.reply({embeds : [emb] , components: [row] });
    }
});

client.on('interactionCreate', async (interaction) => {
    if (!interaction.isButton()) return;

    const userId = interaction.user.id;

    if (interaction.customId === 'button1') {
        handleButtonInteraction(interaction, userId, '1145673280028688434');
   }
});

async function handleButtonInteraction(interaction, userId, roleId, buttonLabel) {
    if (!roleStatus[userId]) {
        await interaction.member.roles.add(roleId);
        roleStatus[userId] = { [roleId]: true };
        await interaction.reply({content : `done add role <@&${roleId}>`,ephemeral : true});
    } else {
        if (roleStatus[userId][roleId]) {
            await interaction.member.roles.remove(roleId);
            roleStatus[userId][roleId] = false;
            await interaction.reply({content : `done remove <@&${roleId}>`, ephemeral : true});
        } else {
            await interaction.member.roles.add(roleId);
            roleStatus[userId][roleId] = true;
            await interaction.reply({ content : `done add role <@&${roleId}>`, ephemeral : true});
        }
    }
}



client.on('messageCreate', async message => {
  if (message.content === '$c') {
    const row1 = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('7').setLabel('7').setStyle('Secondary'),
      new ButtonBuilder().setCustomId('8').setLabel('8').setStyle('Secondary'),
      new ButtonBuilder().setCustomId('9').setLabel('9').setStyle('Secondary'),
      new ButtonBuilder().setCustomId('÷').setLabel('÷').setStyle('Success')
        );

    const row2 = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('4').setLabel('4').setStyle('Secondary'),
      new ButtonBuilder().setCustomId('5').setLabel('5').setStyle('Secondary'),
      new ButtonBuilder().setCustomId('6').setLabel('6').setStyle('Secondary'),
      new ButtonBuilder().setCustomId('×').setLabel('×').setStyle('Success')
        );

    const row3 = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('1').setLabel('1').setStyle('Secondary'),
      new ButtonBuilder().setCustomId('2').setLabel('2').setStyle('Secondary'),
      new ButtonBuilder().setCustomId('3').setLabel('3').setStyle('Secondary'),
      new ButtonBuilder().setCustomId('-').setLabel('-').setStyle('Success')
        );

    const row4 = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('0').setLabel('0').setStyle('Secondary'),
      new ButtonBuilder().setCustomId('.').setLabel('.').setStyle('Success'),
      new ButtonBuilder().setCustomId('=').setLabel('=').setStyle('Primary'),
      new ButtonBuilder().setCustomId('+').setLabel('+').setStyle('Success')
        );

    const row5 = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('C').setLabel('C').setStyle('Danger')
        );

    let currentInput = '0';
    const embed = new EmbedBuilder().setColor('#0099ff').setTitle('Calculator').setDescription(currentInput);

    const calculatorMessage = await message.channel.send({
      embeds: [embed],
      components: [row1, row2, row3, row4, row5]
        });

    const filter = i => i.customId.match(/\d|\.|\+|\-|\×|\÷|=|C/) && i.user.id === message.author.id;
    const collector = calculatorMessage.createMessageComponentCollector({ filter, time: 60000 });

  collector.on('collect', async i => {
      if (i.customId === 'C') {
        currentInput = '0';
      } else if (i.customId === '=') {
        try {
          currentInput = eval(currentInput.replace(/×/g, '*').replace(/÷/g, '/')).toString();
        } catch {
          currentInput = 'Error';
        }
     } else if (/[+\-×÷]/.test(i.customId)) {
        const lastChar = currentInput.slice(-1);
      if ('+-×÷'.includes(lastChar)) currentInput = currentInput.slice(0, -1) + i.customId;
      else currentInput += i.customId;
     } else {
      if (currentInput === '0' && i.customId !== '.') currentInput = '';
        currentInput += i.customId;
     }
     embed.setDescription(currentInput);
     await i.update({ embeds: [embed], components: [row1, row2, row3, row4, row5] });
    });

  collector.on('end', async () => {
      embed.setDescription('Calculator session ended.');
    [row1, row2, row3, row4, row5].forEach(row => row.components.forEach(button => button.setDisabled(true)));
    await calculatorMessage.edit({ embeds: [embed], components: [row1, row2, row3, row4, row5] });
    });
  }
});

////////////////////////



/////////////////////////
client.login("MTI1MTc5NzI2NTA4MTk1ODQzMQ.G9fdNv.6InlilTOY79y07djOIGnATRrlW4Jn48CVZafWo").catch((err) => {
    console.log(err.message)
})


