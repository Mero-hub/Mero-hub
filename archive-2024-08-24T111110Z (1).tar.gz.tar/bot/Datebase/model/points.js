const mongoose = require('mongoose');
const points = new mongoose.Schema(
  {
    guildId: {
        type: String,
        required: true,
      },
    userId: {
      type: String,
      required: true,
    },
    points: {
      type: Number,
      default: 0,
    }
  },
);
module.exports = mongoose.model('points', points);