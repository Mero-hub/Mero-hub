const { EmbedBuilder, ButtonStyle, ButtonBuilder, ActionRowBuilder } = require("discord.js");
module.exports = {
        name: "تشفير",
        aliases: [],
         owners: true,
         async execute(client, message, args) {
          try{
        const row = new ActionRowBuilder()
        .addComponents(
        new ButtonBuilder()
        .setCustomId('tashfer')
        .setLabel('شفر منشورك الان')
        .setStyle(ButtonStyle.Secondary)
        );
        const embed = new EmbedBuilder()
        .setColor('#000100')
        .setTitle('تشفير منشورك')
        .setDescription(`**لتشفير منشورك يرجى ضغط علي الزر وضع منشورك**`)
          .setImage("https://media.discordapp.net/attachments/1249856158458708100/1266791367363792916/1000359094.png?ex=66ab0c25&is=66a9baa5&hm=49af94091f6fce7ab6fe8eb567270fffb34a75fcb465dc4e24cb7ff455f4f84c&")
        .setAuthor({
        name: message.guild.name,
        iconURL: message.guild.iconURL()})
        .setFooter({
        text: message.guild.name,
          iconURL: message.guild.iconURL()
        })
         
        .setThumbnail(message.guild.iconURL())
       .setTimestamp();
       message.channel.send({ embeds: [embed], components: [row] });
        } catch (error) {
            console.error(error);
            message.reply('There was an error while executing this command!');
     }
 },
};