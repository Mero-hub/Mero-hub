const client = require("../../index.js");
const { EmbedBuilder, ApplicationCommandOptionType , Events , ActionRowBuilder , ButtonBuilder ,MessageAttachment, ButtonStyle , Message, TextInputStyle,TextInputBuilder,ModalBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, PermissionsBitField } = require("discord.js");
const config = require("../../config.json");
const roles = ["1145673291395239996","1145673207463018496","1145673192040566924","1145673160230969394"];
const warn25 = "1248246575298252820";
const warn50 = "1248247670536015912";

client.on('interactionCreate', async interaction => {
  if (!interaction.isButton()) return;
  if (interaction.customId === "warn_member") {
    const modal = new ModalBuilder()
      .setCustomId('warn_member')
      .setTitle('تحذير عضو');
      const user = new TextInputBuilder()
      .setCustomId('user_warn')
      .setLabel("ايدي البائع")
      .setStyle(TextInputStyle.Short)
      .setRequired(true)
      .setPlaceholder("ايدي البائع");
    const reason = new TextInputBuilder()
      .setCustomId('reason')
      .setLabel("قم بوضع السبب")
      .setRequired(true)
      .setStyle(TextInputStyle.Short)
      .setPlaceholder("قم بوضع السبب");
    const Evidence = new TextInputBuilder()
      .setCustomId("Evidence_warn")
      .setLabel("قم بوضع صورة السبب")
      .setRequired(true)
      .setStyle(TextInputStyle.Short)
      .setPlaceholder("قم بوضع صورة السبب");
    const firstActionRow = new ActionRowBuilder().addComponents(user);
    const secondActionRow = new ActionRowBuilder().addComponents(reason);
    const thirdActionRow = new ActionRowBuilder().addComponents(Evidence);
    modal.addComponents(firstActionRow, secondActionRow, thirdActionRow);
    await interaction.showModal(modal);
  }
});
client.on('interactionCreate', async interaction => {
  if (!interaction.isModalSubmit()) return;
  if (interaction.customId === 'warn_member') {
    const user = interaction.fields.getTextInputValue('user_warn');
    const reason = interaction.fields.getTextInputValue('reason');
    const Evidence = interaction.fields.getTextInputValue('Evidence_warn');
    const member = interaction.guild.members.cache.get(user);
    const channel = interaction.guild.channels.cache.get("1145673375344230480");
    if (!member) return interaction.reply({ content: "**لا يمكنني العثور على هذا العضو**", ephemeral: true });
    if (!channel) return interaction.reply({ content: "**لا يمكنني العثور على هذا الروم**", ephemeral: true });
    if (!roles.some(role => member.roles.cache.has(role))) return interaction.reply({ content: "**لا يمكنني تحذير هذا العضو**", ephemeral: true });
    const embed = new EmbedBuilder()
      .setAuthor({
        name: interaction.guild.name,
        iconURL: interaction.guild.iconURL()
      })
      .setFooter({
        text: interaction.guild.name,
        iconURL: interaction.guild.iconURL()
      })
      .setThumbnail(interaction.guild.iconURL())
      .addFields(
        {
          name: "> **تم تحذير العضو :**", value: `**\`${member.user.tag}\`**`
        },
        {
          name: "> **بواسطة :**", value: `**\`${interaction.user.tag}\`**`
        },
        {
          name: "> **السبب :**", value: `**\`${reason}\`**`
        })
      .setImage(Evidence)
      .setTimestamp();
    channel.send({
      content: `> <@${member.user.id}>`,
      embeds: [embed]
    });
interaction.reply({ content: `**تم تحذير ${member.user.tag} بنجاح**`, ephemeral: true 
  })                 
if (member.roles.cache.has(warn25)) {
  member.roles.remove(warn25);
  member.roles.add(warn50);
interaction.channel.send({ content: `**2**` });
} else if (member.roles.cache.has(warn50)) {
member.roles.remove(warn50);
};
if (member.roles.cache.has(warn25)) {
member.roles.remove(warn25);
};
if (roles.some(role => member.roles.cache.has(role))) {
member.roles.remove(roles);
} interaction.channel.send({ content: `**3**` });
      
} else {
    const user = interaction.fields.getTextInputValue('user_warn');

    const reason = interaction.fields.getTextInputValue('reason');

    const Evidence = interaction.fields.getTextInputValue('Evidence_warn');

    const member = interaction.guild.members.cache.get(user);
const warn25 = "1248246575298252820";
  member.roles.add(warn25);
}
});  