const { EmbedBuilder, ButtonStyle, ButtonBuilder, ActionRowBuilder } = require("discord.js");
module.exports = {
        name: "order-panel",
        aliases: [],
         owners: true,
         async execute(client, message, args) {
          try {
const row = new ActionRowBuilder()
.addComponents(
new ButtonBuilder()
.setCustomId('products')
.setLabel('منتجات')
.setStyle(ButtonStyle.Secondary),
new ButtonBuilder()
.setCustomId('design')
.setLabel('تصاميم')
.setStyle(ButtonStyle.Secondary),
new ButtonBuilder()
.setCustomId('program')
.setLabel('برمجيات')
.setStyle(ButtonStyle.Secondary)
);
const embed = new EmbedBuilder()
.setColor('#000100')
.setTitle('يمكنك طلب ما تريد من هنا')
.setDescription(`**
قوانين الطلبات

1-ممنوع طلب منتجات 18+
2-ممنوع طلب اعضاء او بارتنر
3-ممنوع طلب طرق نيترو و كريديت
4-ممنوع طلب اشياء في اماكن خطأ مثل : (تطلب نيترو في روم برمجيات او تصاميم)
5-ممنوع بيع اي شي           
**`)
  .setImage('https://media.discordapp.net/attachments/1249856158458708100/1266799433543323709/1000359088.png?ex=66aa6ae8&is=66a91968&hm=6c82fbe69224cb5e97825e0afc73a0af6ce5b9fd0328b6bb1188998a729ee929&')
  .setAuthor({
    name: message.guild.name,
    iconURL: message.guild.iconURL()})
    .setFooter({
    text: message.guild.name,
      iconURL: message.guild.iconURL()
    })

    .setThumbnail(message.guild.iconURL())
  
.setTimestamp();
message.channel.send({ embeds: [embed], components: [row] });
          } catch (error) {
            console.error(error);
            message.reply('There was an error while executing this command!');
          }
        },
};