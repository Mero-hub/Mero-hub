const { EmbedBuilder, ApplicationCommandOptionType , Events , ActionRowBuilder , ButtonBuilder ,MessageAttachment, ButtonStyle , Message, TextInputStyle,TextInputBuilder,ModalBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, PermissionsBitField } = require("discord.js");


  module.exports = {
    name: "info",
    aliases: [],
    owners: true,
    async execute(client, message, args) {
        try{
          
          const embed = new EmbedBuilder()
          .setColor('#000100')
          .setTitle('المعلومات')
          .setDescription(`**لرؤية معلومات الرتب العامة اختار الرتب العامة
  لرؤية معلومات الرتب النادرة اختار الرتب النادرة 
  لرؤية معلومات الاعلانات اختار الاعلانات
  لرؤية معلومات المنشورات المميزة اختار المنشورات المميزة
  لرؤية معلومات الاضافات اختار الاضافات
  لرؤية  الاسئلة الشائعة اختار الاسئلة الشائعة**`)
            .setImage("https://media.discordapp.net/attachments/1249856158458708100/1266799122074042451/1000359082.png?ex=66aa6a9e&is=66a9191e&hm=7455deaa846fb5ffa1b5442a388672b79587816b49a75af1f870f33b57356741&")
          .setAuthor({
            name: message.guild.name 
          })
            .setTimestamp();
          const info = new StringSelectMenuBuilder()
          .setCustomId('info')
          .setPlaceholder('اختار هنا')
          .addOptions(
          new StringSelectMenuOptionBuilder()
          .setLabel('الرتب العامة')
          .setValue('info_roles'),
          new StringSelectMenuOptionBuilder()
          .setLabel('الرومات الخاصة')
          .setValue('info_room'),
          new StringSelectMenuOptionBuilder()
          .setLabel('الاعلانات')
          .setValue('info_ads'),
          new StringSelectMenuOptionBuilder()
          .setLabel('المنشورات المميزة')
          .setValue('info_manshort'),
          new StringSelectMenuOptionBuilder()
          .setLabel('الاضافات')
          .setValue('info_add'),
          new StringSelectMenuOptionBuilder()
          .setLabel('الاسئلة الشائعة')
          .setValue('info_q')
          );
          const row = new ActionRowBuilder()
            .addComponents(info);
          message.channel.send({ embeds: [embed], components: [row] });
        
        } catch (error) {
            console.error(error);
            message.reply('There was an error while executing this command!');
        }
    },
};