const client = require("../../index.js");
const { EmbedBuilder, ApplicationCommandOptionType , Events , ActionRowBuilder , ButtonBuilder ,MessageAttachment, ButtonStyle , Message, TextInputStyle,TextInputBuilder,ModalBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, PermissionsBitField } = require("discord.js");

client.on('interactionCreate', async interaction => {
  if (!interaction.isButton()) return;
    if (interaction.customId.startsWith('post_item')) {
      if (!interaction.member.permissions.has("1145673209870561281")) return interaction.reply({content: `**ليس لديك صلاحيات كافيه**`, ephemeral: true });
const a1 = interaction.message.embeds[0].fields[0].value
const a2 = interaction.message.embeds[0].fields[1].value


    const Auction_items = interaction.guild.channels.cache.get("1266354280546435164");
    const auction_done = new EmbedBuilder()
    .setColor('#000100')
    .setTitle("سـلـعــة الـيــوم")
    .addFields(
      {
        name: "السـلـعـة",
        value: `${a1}`,
        inline: true
      },
      {
        name: "وصف السلعه",
        value: `${a2}`,
        inline: true
      },
      {
        name: "بداية المزايده :",
        value: `30k`,
      }
    );
      const row = new ActionRowBuilder()
       .addComponents(
         new ButtonBuilder()
         .setCustomId('Click_to_bid')
         .setLabel('اضغط للمزايده')
         .setEmoji('\<:emoji_48:1267102800199028788>')
         .setStyle(ButtonStyle.Secondary),
         new ButtonBuilder()
         .setCustomId("End_auction")
         .setLabel("انهاء المزاد")
         .setEmoji('\<:emoji_47:1266884476735193098>')
         .setStyle(ButtonStyle.Secondary)
       );

    await interaction.reply({
      content: `**تم نشر السلعه**`,
      ephemeral: true,
    })
          const rows = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('post_item')
        .setLabel('نشر السلعة')
      .setEmoji('\<:emoji_45:1266883531666096230>')
      .setDisabled(true)
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('cancle_item')
        .setLabel('حذف السلعه')
      .setEmoji('\<:emoji_46:1266883575903682571>')
      .setDisabled(true)
        .setStyle(ButtonStyle.Secondary)
    );
      await interaction.message.edit({
        content: `> تم بداء المزاد`,        components: [rows]
      })
    await Auction_items.send({
      content: `**> @here سلعه جديده**`,
      embeds: [auction_done],
      components: [row]
    })
    await Auction_items.send({
      content: `**
> تدفع عن طريق بنك؟ و تحط ايدي بنك خارج السيرفر = مخالفة
> تدفع عن طريق بنك؟ و ما تحط الايدي = مخالفة
> تزاود على سلعة وبالاخير ما تشتري = بلاك لست 
> ممنوع أي كلمة في المزاد غير سعرك = مخالفة 
> اقل سعر للمزايدة 10 الاف = مخالفة 
> تدفع عن طريق بنك؟ حط الايدي**`
    });
      await Auction_items.send({
        content: `https://media.discordapp.net/attachments/1249856158458708100/1268148265862565988/1000311801.png?ex=66ab5e9b&is=66aa0d1b&hm=6693d601193dc45214b0ac1a0924f00d6c1c35ed5cad19b79cfddba4e174d156&`
      });
  }
});
client.on('interactionCreate', async interaction => {
  if (!interaction.isButton()) return;
    if (interaction.customId === 'Click_to_bid') {
     const modal = new ModalBuilder()
      .setCustomId('moadel_bid')
      .setTitle('مزايده علي المزاد')
      const bank = new TextInputBuilder()
      .setCustomId('bank')
      .setLabel('هل لديك بنك؟')
      .setStyle(TextInputStyle.Short)
      .setRequired(true)
      const amount_bid = new TextInputBuilder()
      .setCustomId("amount_bid")
      .setLabel("سعر مزايده")
      .setStyle(TextInputStyle.Short)
      .setRequired(true)
      const firstActionRow = new ActionRowBuilder().addComponents(bank);
      const secondActionRow = new ActionRowBuilder().addComponents(amount_bid);
      modal.addComponents(firstActionRow, secondActionRow);
      await interaction.showModal(modal);
    }
});
client.on('interactionCreate', async interaction => {
  if (!interaction.isModalSubmit()) return;
  if (interaction.customId === 'moadel_bid') {
    const bank = interaction.fields.getTextInputValue('bank');
    const amount_bid = interaction.fields.getTextInputValue('amount_bid');
    const auction_done = new EmbedBuilder()
    .setColor('#000100')
    .setDescription(`**> هناك بنك؟ ${bank}**\n\n**> السعر المزايده ${amount_bid}**`)
      .setAuthor({
        name: interaction.user.username,
        iconURL: interaction.user.avatarURL()
      })
      .setFooter({
        text: interaction.guild.name,
        iconURL: interaction.guild.iconURL()
      })
      .setThumbnail(interaction.guild.iconURL())
    .setTimestamp();
    const row = new ActionRowBuilder()
       .addComponents(
         new ButtonBuilder()
         .setCustomId('Member_warn')
         .setLabel('مخالفه العضو')
         .setEmoji('\<:emoji_46:1266883575903682571>')
         .setStyle(ButtonStyle.Secondary),
       )
    await interaction.reply({
      content: `**تم المزايدة بنجاح**`,
      ephemeral: true,
    })
    await interaction.channel.send({
      content: `${interaction.user}`,
      embeds: [auction_done],
      components: [row]
    })
  }
});
client.on('interactionCreate', async interaction => {
  if (!interaction.isButton()) return;
    if (interaction.customId === 'End_auction') {
      if (!interaction.member.permissions.has("1200896955010777181")) return interaction.reply({content: `**ليس لديك صلاحيات كافيه**`, ephemeral: true });
      const auction_done = new EmbedBuilder()
    .setColor('#000100')
    .setDescription(`**> تم عرض المزاد و قد انتهي**`)
      .setAuthor({
        name: interaction.guild.name,
          iconURL: interaction.guild.iconURL()
      })
      .setFooter({
        text: interaction.guild.name,
        iconURL: interaction.guild.iconURL()
      })
      .setThumbnail(interaction.guild.iconURL())
    .setTimestamp();
          const row = new ActionRowBuilder()
       .addComponents(
         new ButtonBuilder()
         .setCustomId('Click_to_bid')
         .setLabel('اضغط للمزايده')
         .setEmoji('\<:emoji_48:1267102800199028788>')
         .setDisabled(true)
         .setStyle(ButtonStyle.Secondary),
         new ButtonBuilder()
         .setCustomId("End_auction")
         .setLabel("انهاء المزاد")
         .setEmoji('\<:emoji_47:1266884476735193098>')
         .setDisabled(true)
         .setStyle(ButtonStyle.Secondary)
       );
      await interaction.update({
        content: `**> تم انهاء المزاد بنجاح -**`,
        embeds: [auction_done],
        components: [row]
      });
    } else if (interaction.customId === 'cancle_item') {
      if (!interaction.member.permissions.has("1145673209870561281")) return interaction.reply({content: `**ليس لديك صلاحيات كافيه**`, ephemeral: true });
      const auction_done = new EmbedBuilder()
    .setColor('#000100')
    .setDescription(`**> تم حذف السلعة 
 لأسباب تخص المسؤولين**`)
      .setAuthor({
        name: interaction.user.username,
        iconURL: interaction.user.avatarURL()
      })
      .setFooter({
        text: interaction.guild.name,
        iconURL: interaction.guild.iconURL()
      })
      .setThumbnail(interaction.guild.iconURL())
    .setTimestamp();
    await interaction.update({
      content: `**> تم حذف السلعة بنجاح**`,
      embeds: [auction_done],
      components: []
    });
    } else if (interaction.customId === 'Member_warn') {
      if (!interaction.member.permissions.has("1145673209870561281")) return interaction.reply({content: `**ليس لديك صلاحيات كافيه**`, ephemeral: true });
        const member = interaction.message.content.slice(2, 20);
        const user = interaction.guild.members.cache.get(member);

      const warn = new EmbedBuilder()
      .setColor("#000100")
      .setDescription(`**تم مخالفة العضو واعطائه تايم اوت : ${user}**`)
        .setThumbnail(interaction.guild.iconURL());
      await interaction.update({
        content: `**> ${user} **`,
        embeds: [warn],
        components: []
      });
    await user.timeout(3600000).catch((e) => console.log(e));
      await interaction.followUp({
        content: `**تم تحذير <@${member}>**`,
        ephemeral: true
      });
      
      
    }
});

