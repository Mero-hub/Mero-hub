const client = require("../../index.js");
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const blacklists = require("../../Datebase/model/apply/blacklist.js")
const apply = require("../../Datebase/model/apply/support_apply.js");
client.on("interactionCreate", async (interaction) => {
  if (interaction.isButton()) {
  if (interaction.customId === "blacklist_support") {
    if (!interaction.member.roles.cache.has("1197472555615916132")) return interaction.reply({ content: `You don't have permission to use this button.`, ephemeral: true })
      const member = interaction.message.content.slice(2, 20);
      const user = interaction.guild.members.cache.get(member); 
     const blacklist = new blacklists({
        guildId: interaction.guild.id,
        userId: user.id,
     });
     await blacklist.save();
                const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('accept_mediator')
          .setLabel(`قبول`)
        .setDisabled(true)
.setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId('decline_mediator')
          .setLabel('رفض')
        .setDisabled(true)
          .setStyle(ButtonStyle.Danger),
        new ButtonBuilder()
          .setCustomId('blacklist_report')
          .setLabel(`تم حظر الشخص بنجاح من قبل ${interaction.user.tag}`)
        .setDisabled(true)
          .setStyle(ButtonStyle.Secondary),
        
      );
      await interaction.message.edit({
components: [row]
      })
    await interaction.reply({
      content: `تم حظر <@${user.id}> من التقديم`,
      ephemeral: true,
    });
  } else if (interaction.customId === "blacklist_mediator") {
    if (!interaction.member.roles.cache.has("1197472555615916132")) return interaction.reply({ content: `You don't have permission to use this button.`, ephemeral: true })
      const member = interaction.message.content.slice(2, 20);
      const user = interaction.guild.members.cache.get(member); 
     const blacklist = new blacklists({
        guildId: interaction.guild.id,
        userId: user.id,
     });
     await blacklist.save();
     const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('accept_mediator')
          .setLabel(`قبول`)
        .setDisabled(true)
.setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId('decline_mediator')
          .setLabel('رفض')
        .setDisabled(true)
          .setStyle(ButtonStyle.Danger),
        new ButtonBuilder()
          .setCustomId('blacklist_report')
          .setLabel(`تم حظر الشخص بنجاح من قبل ${interaction.user.tag}`)
        .setDisabled(true)
          .setStyle(ButtonStyle.Secondary),
        
      );
      await interaction.message.edit({
components: [row]
      })
    await interaction.reply({
      content: `تم حظر <@${user.id}> من التقديم`,
      ephemeral: true,
    });
  } else if (interaction.customId === "blacklist_report") {
    if (!interaction.member.roles.cache.has("1197472555615916132")) return interaction.reply({ content: `You don't have permission to use this button.`, ephemeral: true })
      const member = interaction.message.content.slice(2, 20);
      const user = interaction.guild.members.cache.get(member); 
     const blacklist = new blacklists({
        guildId: interaction.guild.id,
        userId: user.id,
     });
     await blacklist.save();
    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('accept_mediator')
          .setLabel(`قبول`)
        .setDisabled(true)
.setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId('decline_mediator')
          .setLabel('رفض')
        .setDisabled(true)
          .setStyle(ButtonStyle.Danger),
        new ButtonBuilder()
          .setCustomId('blacklist_report')
          .setLabel(`تم حظر الشخص بنجاح من قبل ${interaction.user.tag}`)
        .setDisabled(true)
          .setStyle(ButtonStyle.Secondary),
        
      );
      await interaction.message.edit({
components: [row]
      })
    await interaction.reply({
      content: `تم حظر <@${user.id}> من التقديم`,
      ephemeral: true,
    });
  }
 }
});