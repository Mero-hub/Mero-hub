const { Client, GatewayIntentBits, Events, EmbedBuilder, ActionRowBuilder, ButtonBuilder } = require('discord.js');
const puppeteer = require('puppeteer');
const Tesseract = require('tesseract.js');
const { REST } = require('@discordjs/rest');
const { Routes } = require('discord-api-types/v9');
const { SlashCommandBuilder } = require('@discordjs/builders');
const { token, AccountToken, ServerID, ChannelID } = require('./config.json');

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
    ],
});

const rest = new REST({ version: '9' }).setToken(token);
const cooldowns = new Map();

(async () => {
    const clientId = '1147956814193889300'; // استبدل هذا بمعرف العميل الخاص بك

    const commands = [
        new SlashCommandBuilder()
            .setName('sahb')
            .setDescription('سحب الأموال')
            .addIntegerOption(option =>
                option.setName('المبلغ').setDescription('أدخل المبلغ المراد سحبه').setRequired(true),
            ),
    ].map(command => command.toJSON());

    try {
        console.log('بدأ تحديث أوامر التطبيق (/)');
        await rest.put(Routes.applicationCommands(clientId), { body: commands });
        console.log('تم إعادة تحميل أوامر التطبيق (/) بنجاح.');
    } catch (error) {
        console.error('حدث خطأ أثناء إعادة تحميل أوامر التطبيق (/):', error);
    }
})();

client.on(Events.ClientReady, () => {
    console.log(`Logged in as ${client.user.tag}!`);

    const activities = [
        { name: 'تم الصنع من قبل qa.y', type: 1, url: 'https://discord.gg/fpkMkGTWu8' },
        { name: 'تم صنع البوت لضمان حق الجميع.', type: 1, url: 'https://discord.gg/fpkMkGTWu8' },
    ];
    
    let currentActivity = 0;
    setInterval(() => {
        if (client.user) {
            client.user.setActivity(activities[currentActivity]);
            currentActivity = (currentActivity + 1) % activities.length;
        }
    }, 20000);
});

client.on(Events.InteractionCreate, async (interaction) => {
    if (!interaction.isCommand()) return;

    if (interaction.commandName === 'sahb') {
        const amount = interaction.options.getInteger('المبلغ');

        if (isNaN(amount) || amount <= 0 || amount > 70000000) {
            return interaction.reply({ content: 'الرجاء إدخال مبلغ صحيح بين 1 و 70 مليون.', ephemeral: true });
        }

        const now = Date.now();
        const cooldown = cooldowns.get(interaction.user.id);
        if (cooldown && now - cooldown < 30 * 60 * 1000) {
            return interaction.reply({ content: 'الرجاء المحاولة مرة أخرى بعد نصف ساعة.', ephemeral: true });
        }
        cooldowns.set(interaction.user.id, now);

        const embed = new EmbedBuilder()
            .setColor('#00ffff')
            .setTitle('طلب سحب')
            .setDescription('الرجاء انتظار الأونرات البقية لقبول عملية التحويل لك.');

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('approve').setLabel('موافق').setStyle('Primary'),
            new ButtonBuilder().setCustomId('disapprove').setLabel('غير موافق').setStyle('Danger'),
        );

        const message = await interaction.reply({
            content: '@everyone',
            embeds: [embed],
            components: [row],
            fetchReply: true,
        });

        const filter = i => i.customId === 'approve' || i.customId === 'disapprove';
        const collector = message.createMessageComponentCollector({
            filter,
            time: 10 * 60 * 1000, // 10 دقائق
        });

        let approveCount = 0;
        let disapproveCount = 0;

        collector.on('collect', async (i) => {
            if (i.user.id === interaction.user.id) {
                return i.reply({ content: 'لا يمكنك التصويت على طلبك الخاص.', ephemeral: true });
            }

            if (i.customId === 'approve') {
                approveCount++;
                if (approveCount >= 2) {
                    embed.setDescription('تم قبول عملية السحب الخاصة بك، الرجاء انتظار التحويل.');
                    await message.edit({ embeds: [embed], components: [] });

                    try {
                        await executeTransfer(interaction.user.id, amount, interaction.channel);
                        embed.setDescription(`تم التحويل بنجاح! المبلغ: ${amount}`);
                        await message.edit({ embeds: [embed] });
                        await interaction.followUp({ content: `${interaction.user}`, embeds: [embed] });
                    } catch (error) {
                        embed.setDescription('حدث خطأ أثناء عملية التحويل.');
                        await message.edit({ embeds: [embed] });
                        console.error('حدث خطأ أثناء تنفيذ عملية التحويل:', error.message);
                        console.error('تفاصيل الخطأ بالكامل:', error);
                    }
                }
            } else if (i.customId === 'disapprove') {
                disapproveCount++;
                if (disapproveCount >= 2) {
                    embed.setDescription('تم رفض عملية السحب الخاصة بك.');
                    await message.edit({ embeds: [embed], components: [] });
                }
            }
            try {
                 i.deferUpdate(); // تأكد من استدعاء هذا لتفادي مشكلات في التعامل مع التفاعل
            } catch (error) {
                console.error('حدث خطأ أثناء تأخير تحديث التفاعل:', error.message);
                console.error('تفاصيل الخطأ بالكامل:', error);
            }
        });

        collector.on('end', async collected => {
            if (collected.size === 0) {
                embed.setDescription('انتهت صلاحية الطلب بسبب عدم التفاعل.');
                await message.edit({ embeds: [embed], components: [] });
            }
        });
    }
});

async function executeTransfer(userId, amount, channel) {
    let browser;
    try {
        browser = await puppeteer.launch({
            headless: false,
            args: ['--no-sandbox', '--disable-setuid-sandbox'],
        });
        const page = await browser.newPage();

        // فتح صفحة تسجيل الدخول
        await page.goto('https://discord.com/login');

        // الانتظار 10 ثوانٍ للتأكد من تحميل الصفحة
        await page.waitForTimeout(10000);

        // استخدام أدوات المطورين لتحديث localStorage بالتوكن
        await page.evaluate((token) => {
            const localStorage = window.localStorage;
            localStorage.setItem('token', token);
            window.location.reload();
        }, AccountToken);

        // الانتظار حتى يتم تحميل الصفحة بعد إعادة التحميل
        await page.waitForNavigation({ waitUntil: 'networkidle2' });

        // الانتقال إلى القناة المطلوبة
        await page.goto(`https://discord.com/channels/${ServerID}/${ChannelID}`, { waitUntil: 'networkidle2' });

        // إرسال الأمر المطلوب
        await page.type('textarea', `#credit ${amount} ${userId}`);
        await page.keyboard.press('Enter');

        // الانتظار حتى تظهر الصورة
        const imageSelector = 'img[src*="discordapp.com"]'; // قم بتحديث المحدد بناءً على تنسيق الصورة
        await page.waitForSelector(imageSelector);

        // تحميل الصورة
        const imageUrl = await page.$eval(imageSelector, img => img.src);

        // استخدام Tesseract للتعرف على النص في الصورة
        const { data: { text } } = await Tesseract.recognize(imageUrl, 'eng');

        // استخراج الأرقام من النص
        const numbers = text.match(/\d+/g).join('');

        // إرسال الأرقام المستخرجة إلى نفس القناة
        await page.type('textarea', numbers); // تأكد من أن التحديد صحيح
        await page.keyboard.press('Enter');

    } catch (error) {
        console.error('حدث خطأ أثناء تنفيذ عملية التحويل:', error.message);
        console.error('تفاصيل الخطأ بالكامل:', error);
    } finally {
        if (browser) await browser.close();
    }
}

client.login(token);
