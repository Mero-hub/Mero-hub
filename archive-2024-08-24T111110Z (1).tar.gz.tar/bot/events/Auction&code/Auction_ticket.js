const client = require("../../index.js");
const { EmbedBuilder, ActionRowBuilder , ButtonBuilder , ButtonStyle, TextInputStyle,TextInputBuilder,ModalBuilder } = require("discord.js");
const counters = require('../../Datebase/model/counters/Auction_counter.js');
client.on('interactionCreate', async interaction => {
  if (!interaction.isStringSelectMenu()) return;
  if (interaction.customId === 'auction') {
    const selectedValue = interaction.values[0];
    if (selectedValue === 'auction_1') {
      const counter = await counters.updateOne(
      { guildId: interaction.guild.id },
      { $inc: { counter: 1 } },
      { upsert: true }
    );

    const findCount = await counters.findOne({ guildId: interaction.guild.id });

      const ctr = findCount.counter
      const auction = await
interaction.guild.channels.create({
        name: `auction-${ctr}`,
        type: 0,
        parent: '1264978774567424102',
        permissionOverwrites: [
          {
            id: interaction.guild.id,
            deny: ['ViewChannel'],
          },
          {
            id: interaction.user.id,
            allow: ['ViewChannel'],
          },
         {
            id: "1145673209870561281",
            allow: ['ViewChannel'],
          },
        ],
      });
          await interaction.reply({
              content: `تم إنشاء تذكرتك في ${auction}`,
              ephemeral: true,
            });
          const row = new ActionRowBuilder()
          .addComponents(
            new ButtonBuilder()
              .setCustomId('auction_buy')
              .setLabel('شراء مزاد')
              .setStyle(ButtonStyle.Secondary),
            new ButtonBuilder()
              .setCustomId("auction_claim")
              .setLabel("استلام التذكره")
              .setStyle(ButtonStyle.Secondary),
            new ButtonBuilder()
              .setCustomId("auction_help")
              .setLabel("مساعده طاقم المزاد")
              .setStyle(ButtonStyle.Secondary),
            new ButtonBuilder()
              .setCustomId("auction_delete_ticket")
              .setLabel("حذف التذكره")
              .setStyle(ButtonStyle.Danger)
          );
        const embed = new EmbedBuilder()
          .setColor("#000100")
          .setDescription(`**

نحتاج منك ملء النموذج:

                    


-  السلعة : 
- بداية المزايدة '30k' ، '10k' :
- : @ 


- اذا كان 7ساب ديسكورد عبي :


- عمر الـ7ـساب 
- سمعة الـ7ـساب 
- مستوى الـ7ـساب ( في بروبوت ) 
- مفعل نيتر9 قبل او لا؟
- صورة للـ7ـساب : 


- اذا كان سيرفر ديسكورد عبي هذا النموذج :


- عدد أعضاء السيرفر
- نوع السيرفر (كوميونتي، شـ9ب، الخ)
- عمر السيرفر
- كم توكن فيه
- معدل تفاعل السيرفر**`)
          .setImage("https://media.discordapp.net/attachments/1249856158458708100/1266813766570344470/Picsart_24-07-27_18-39-38-873.png?ex=66ab2102&is=66a9cf82&hm=943be00d79e951ffb8e6da5924a6d8feb884727ac3c2f7931af6a533d1cb6021&")
          .setAuthor({
            name: interaction.guild.name,
            iconURL: interaction.guild.iconURL()
          })
          .setFooter({
            text: interaction.guild.name,
            iconURL: interaction.guild.iconURL()
          })
          .setThumbnail(interaction.guild.iconURL());
        await auction.send({
                  content: `${interaction.user}||<@&1145673209870561281>`,
          components: [row],
          embeds: [embed],
        });
    }
  }
});