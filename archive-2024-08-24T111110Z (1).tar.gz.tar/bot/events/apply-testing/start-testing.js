const client = require("../../index.js");
const { EmbedBuilder, ActionRowBuilder , ButtonBuilder , ButtonStyle, TextInputStyle,TextInputBuilder,ModalBuilder } = require("discord.js");
client.on("interactionCreate", async (interaction) => {
  if (!interaction.isButton()) return;
  if (interaction.customId === "start-test1") {
    const start = new EmbedBuilder()
      .setTitle("نموذج 1")
      .setDescription(`- نصـاب فتح تكت وقال ابي اشيل رتبة نصـاب : 
**تقول له توجه لـ : طلب مشهر**
- اذا عضو فتح تكت وقال في نـصـاب نصبني : 
**تقول له توجه لـ : طلب مشهر**
- اذا جا عضو خاصك و قال في نصـاب نصبني  : 
**تقول له توجه لـ : طلب مشهر**`);
    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId("complet_testing-sup2")
          .setLabel("اكمال التعليم")
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId("call")
          .setLabel("استدعاء")
          .setStyle(ButtonStyle.Secondary)
      );
    interaction.channel.send({ embeds: [start], components: [row] });
    
    interaction.reply({ content: "**تم بدء التعليم\nاذ تريد اي استفسار اضغط على زر (استدعاء) وانتظر الرد**", ephemeral: true });
    const ro = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId('start-test1')
            .setLabel('بدء الاختبار')
          
          .setDisabled(true)
          .setStyle(ButtonStyle.Secondary),
          new ButtonBuilder()
            .setCustomId('delete_ticket')
            .setLabel('حذف التذكره')
            .setStyle(ButtonStyle.Danger)
        ); 
    interaction.message.edit({ components: [ro] });
  } else if (interaction.customId === "start-test2") {
    const start = new EmbedBuilder()
          .setTitle("نموذج 1")
          .setDescription(`- نصـاب فتح تكت وقال ابي اشيل رتبة نصـاب : 
    **تقول له توجه لـ : طلب مشهر**
    - اذا عضو فتح تكت وقال في نـصـاب نصبني : 
    **تقول له توجه لـ : طلب مشهر**
    - اذا جا عضو خاصك و قال في نصـاب نصبني  : 
    **تقول له توجه لـ : طلب مشهر**`);
        const row = new ActionRowBuilder()
          .addComponents(
            new ButtonBuilder()
              .setCustomId("complet_testing-mad2")
              .setLabel("اكمال التعليم")
              .setStyle(ButtonStyle.Secondary),
            new ButtonBuilder()
              .setCustomId("call")
              .setLabel("استدعاء")
              .setStyle(ButtonStyle.Secondary)
          );
        interaction.channel.send({ embeds: [start], components: [row] });

        interaction.reply({ content: "**تم بدء التعليم\nاذ تريد اي استفسار اضغط على زر (استدعاء) وانتظر الرد**", ephemeral: true });
        const ro = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId('start-test1')
            .setLabel('بدء الاختبار')
          
          .setDisabled(true)
          .setStyle(ButtonStyle.Secondary),
          new ButtonBuilder()
            .setCustomId('delete_ticket')
            .setLabel('حذف التذكره')
            .setStyle(ButtonStyle.Danger)
        ); 
    interaction.message.edit({ components: [ro] });
  } else if (interaction.customId === "start-test3") {
    const start = new EmbedBuilder()
      .setTitle("نموذج 1")
      .setDescription(`- نصـاب فتح تكت وقال ابي اشيل رتبة نصـاب : 
**تقول له توجه لـ : طلب مشهر**
- اذا عضو فتح تكت وقال في نـصـاب نصبني : 
**تقول له توجه لـ : طلب مشهر**
- اذا جا عضو خاصك و قال في نصـاب نصبني  : 
**تقول له توجه لـ : طلب مشهر**`);
    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId("complet_testing-report2")
          .setLabel("اكمال التعليم")
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId("call")
          .setLabel("استدعاء")
          .setStyle(ButtonStyle.Secondary)
      );
    interaction.channel.send({ embeds: [start], components: [row] });
    
    interaction.reply({ content: "**تم بدء التعليم\nاذ تريد اي استفسار اضغط على زر (استدعاء) وانتظر الرد**", ephemeral: true });
        const ro = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId('start-test1')
            .setLabel('بدء الاختبار')
          
          .setDisabled(true)
          .setStyle(ButtonStyle.Secondary),
          new ButtonBuilder()
            .setCustomId('delete_ticket')
            .setLabel('حذف التذكره')
            .setStyle(ButtonStyle.Danger)
        ); 
    interaction.message.edit({ components: [ro] });
  } else if (interaction.customId === "complet_testing-sup2") {
        const start = new EmbedBuilder()
      .setTitle("نموذج 2")
      .setDescription(`**- نصـاب فتح تكت وقال ابي اشيل رتبة نصـاب :**
تقول له توجه لـ : طلب مشهر
**- اذا عضو فتح تكت وقال في نـصـاب نصبني : **
تقول له توجه لـ : طلب مشهر
**- اذا جا عضو خاصك و قال في نصـاب نصبني  :** 
تقول له توجه لـ : طلب مشهر
**- شخص عايز يقدم على مزاد : **
تخليه بتوجه لروم تقديم على طاقم الادارة
**- شخص عايز يقدم على قاضي : **
تخليه بتوجه لروم تقديم على طاقم الادارة
**- لو شخص بيشتري إعلان**
تفحص الأ‘لان الأول تقوله يبعته خاصك و تتأكد انه مش مخالف للقوانين ثم بعدها
تقوله يكمل مع البوت لان الشراء تلقائي 
**- لو شخص محتاجك تضيف حسابه التاني للتكت**
عن طريق __مساعد الإدارة__ تختار إضافه شخص للتذكرة او إزاله شخص من التذكرة 
**- كيف تقدر تغير إسم التكت**
عن طريق __مساعد الإدارة__ تختار تغيير إسم التكت 
**- اشرح لو شخص محتاج رتبة الدعم الصوتي او رتبه صور** 
اذا كان عنده مشكله و تحتاج انه يكلم الدعم في الصوتي تختار من الأيمبد __مساعد الإدارة__ ثم بعدها تختار اضافة رتبه اول خانه تحط ايدي الشخص و الخانه التانيه تكتب الرتبه المحدده`);
    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId("complet_testing-sup3")
          .setLabel("اكمال التعليم")
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId("call")
          .setLabel("استدعاء")
          .setStyle(ButtonStyle.Secondary)
      );
      interaction.message.edit({ embeds: [start], components: [row] });
    interaction.reply({ content: `**تم تغير النموذج الي نموذج 2**`, ephemeral: true });
    
  } else if (interaction.customId === "complet_testing-mad2") {
        const start = new EmbedBuilder()
      .setTitle("نموذج 2")
      .setDescription(`**- نصـاب فتح تكت وقال ابي اشيل رتبة نصـاب :**
تقول له توجه لـ : طلب مشهر
**- اذا عضو فتح تكت وقال في نـصـاب نصبني : **
تقول له توجه لـ : طلب مشهر
**- اذا جا عضو خاصك و قال في نصـاب نصبني  :** 
تقول له توجه لـ : طلب مشهر
**- شخص عايز يقدم على مزاد : **
تخليه بتوجه لروم تقديم على طاقم الادارة
**- شخص عايز يقدم على قاضي : **
تخليه بتوجه لروم تقديم على طاقم الادارة
**- لو شخص بيشتري إعلان**
تفحص الأ‘لان الأول تقوله يبعته خاصك و تتأكد انه مش مخالف للقوانين ثم بعدها
تقوله يكمل مع البوت لان الشراء تلقائي 
**- لو شخص محتاجك تضيف حسابه التاني للتكت**
عن طريق __مساعد الإدارة__ تختار إضافه شخص للتذكرة او إزاله شخص من التذكرة 
**- كيف تقدر تغير إسم التكت**
عن طريق __مساعد الإدارة__ تختار تغيير إسم التكت 
**- اشرح لو شخص محتاج رتبة الدعم الصوتي او رتبه صور** 
اذا كان عنده مشكله و تحتاج انه يكلم الدعم في الصوتي تختار من الأيمبد __مساعد الإدارة__ ثم بعدها تختار اضافة رتبه اول خانه تحط ايدي الشخص و الخانه التانيه تكتب الرتبه المحدده`);
    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId("complet_testing-mad3")
          .setLabel("اكمال التعليم")
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId("call")
          .setLabel("استدعاء")
          .setStyle(ButtonStyle.Secondary)
      );
    interaction.message.edit({ embeds: [start], components: [row] });
    interaction.reply({ content: `**تم تغير النموذج الي نموذج 2**`, ephemeral: true });
  } else if (interaction.customId === "complet_testing-report2") {
        const start = new EmbedBuilder()
      .setTitle("نموذج 2")
      .setDescription(`**- نصـاب فتح تكت وقال ابي اشيل رتبة نصـاب :**
تقول له توجه لـ : طلب مشهر
**- اذا عضو فتح تكت وقال في نـصـاب نصبني : **
تقول له توجه لـ : طلب مشهر
**- اذا جا عضو خاصك و قال في نصـاب نصبني  :** 
تقول له توجه لـ : طلب مشهر
**- شخص عايز يقدم على مزاد : **
تخليه بتوجه لروم تقديم على طاقم الادارة
**- شخص عايز يقدم على قاضي : **
تخليه بتوجه لروم تقديم على طاقم الادارة
**- لو شخص بيشتري إعلان**
تفحص الأ‘لان الأول تقوله يبعته خاصك و تتأكد انه مش مخالف للقوانين ثم بعدها
تقوله يكمل مع البوت لان الشراء تلقائي 
**- لو شخص محتاجك تضيف حسابه التاني للتكت**
عن طريق __مساعد الإدارة__ تختار إضافه شخص للتذكرة او إزاله شخص من التذكرة 
**- كيف تقدر تغير إسم التكت**
عن طريق __مساعد الإدارة__ تختار تغيير إسم التكت 
**- اشرح لو شخص محتاج رتبة الدعم الصوتي او رتبه صور** 
اذا كان عنده مشكله و تحتاج انه يكلم الدعم في الصوتي تختار من الأيمبد __مساعد الإدارة__ ثم بعدها تختار اضافة رتبه اول خانه تحط ايدي الشخص و الخانه التانيه تكتب الرتبه المحدده`);
    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId("complet_testing-report3")
          .setLabel("اكمال التعليم")
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId("call")
          .setLabel("استدعاء")
          .setStyle(ButtonStyle.Secondary)
      );
    interaction.message.edit({ embeds: [start], components: [row] });
    interaction.reply({ content: `**تم تغير النموذج الي نموذج 2**`, ephemeral: true });
  } else if (interaction.customId === "complet_testing-sup3") {
           const start = new EmbedBuilder()
      .setTitle("نموذج 3")
      .setDescription(`**- شخص عايز اداره عليا : **
تساله عن السبب و تشوف السبب اذا هو مقنع تمنشن رتبة العليا و تغير اسم التكت لـ مطلوب عليا
**- شخص عايز اونر :**
تساله عن السبب و تشوف السبب اذا هو مقنع تمنشن رتبة العليا و هي يلي تجيب الاونر و تغير اسم التكت لـ مطلوب اونر
       
- شخص عايز يشتكي على اداري : 
**تقول له توجه علي تكت شكوة علي اداري**
            
- شخص عايز يقدم على وسيط : 
**تخليه بتوجه لروم تقديم على طاقم الادارة**`);
    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId("end_testing-sup")
          .setLabel("انهاء التعليم")
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId("call")
          .setLabel("استدعاء")
          .setStyle(ButtonStyle.Secondary)
      );
    interaction.message.edit({ embeds: [start], components: [row] });
    interaction.reply({ content: `**تم تغير النموذج الي نموذج 3**`, ephemeral: true });
  } else if (interaction.customId === "complet_testing-mad3") {
        const start = new EmbedBuilder()
      .setTitle("نموذج 3")
      .setDescription(`**- شخص عايز اداره عليا : **
تساله عن السبب و تشوف السبب اذا هو مقنع تمنشن رتبة العليا و تغير اسم التكت لـ مطلوب عليا
**- شخص عايز اونر :**
تساله عن السبب و تشوف السبب اذا هو مقنع تمنشن رتبة العليا و هي يلي تجيب الاونر و تغير اسم التكت لـ مطلوب اونر
       
- شخص عايز يشتكي على اداري : 
**تقول له توجه علي تكت شكوة علي اداري**
            
- شخص عايز يقدم على وسيط : 
**تخليه بتوجه لروم تقديم على طاقم الادارة**`);
    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId("end_testing-mad")
          .setLabel("انهاء التعليم")
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId("call")
          .setLabel("استدعاء")
          .setStyle(ButtonStyle.Secondary)
      );
    interaction.message.edit({ embeds: [start], components: [row] });
    interaction.reply({ content: `**تم تغير النموذج الي نموذج 3**`, ephemeral: true });
  } else if (interaction.customId === "complet_testing-report3") {
        const start = new EmbedBuilder()
      .setTitle("نموذج 3")
      .setDescription(`- نصـاب فتح تكت وقال ابي اشيل رتبة نصـاب : 
**تقول له توجه لـ : طلب مشهر**
- اذا عضو فتح تكت وقال في نـصـاب نصبني : 
**تقول له توجه لـ : طلب مشهر**
- اذا جا عضو خاصك و قال في نصـاب نصبني  : 
**تقول له توجه لـ : طلب مشهر**`);
    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId("end_testing-report")
          .setLabel("انهاء التعليم")
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId("call")
          .setLabel("استدعاء")
          .setStyle(ButtonStyle.Secondary)
      );
    interaction.message.edit({ embeds: [start], components: [row] });
    interaction.reply({ content: `**تم تغير النموذج الي نموذج 3**`, ephemeral: true });
  } else if (interaction.customId === "end_testing-sup") {
    const start = new EmbedBuilder()
      .setTitle("بدء الاختبار")
      .setDescription("يرجي الضغط علي الزر لبدا الاختبار ");
    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId("first-test-sup")
          .setLabel("الاختبار الاول")
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId("second-test-sup")
          .setLabel("الاختبار الثاني")
        .setDisabled(true)
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId("third-test-sup")
          .setLabel("الاختبار الثالث")
        .setDisabled(true)
          .setStyle(ButtonStyle.Secondary),
      );
    interaction.message.edit({ embeds: [start], components: [row] });
    interaction.reply({ content: `**تم انهاء التعليم \n عليك الاجابه علي الاساله لكي يتم قبولك**`, ephemeral: true });
  } else if (interaction.customId === "end_testing-mad") {
    const start = new EmbedBuilder()
      .setTitle("بدء الاختبار")
      .setDescription("يرجي الضغط علي الزر لبدا الاختبار ");
    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId("first-test-mad")
          .setLabel("الاختبار الاول")
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId("second-test-mad")
          .setLabel("الاختبار الثاني")
        .setDisabled(true)
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId("third-test-mad")
          .setLabel("الاختبار الثالث")
        .setDisabled(true)
          .setStyle(ButtonStyle.Secondary),
      );
    interaction.message.edit({ embeds: [start], components: [row] });
    interaction.reply({ content: `**تم انهاء التعليم \n عليك الاجابه علي الاساله لكي يتم قبولك**`, ephemeral: true });
  } else if (interaction.customId === "end_testing-report") {
    const start = new EmbedBuilder()
      .setTitle("بدء الاختبار")
      .setDescription("يرجي الضغط علي الزر لبدا الاختبار ");
    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId("first-test-report")
          .setLabel("الاختبار الاول")
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId("second-test-report")
          .setLabel("الاختبار الثاني")

        .setDisabled(true)
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId("third-test-report")
          .setLabel("الاختبار الثالث")
        .setDisabled(true)
          .setStyle(ButtonStyle.Secondary),
      );
    interaction.message.edit({ embeds: [start], components: [row] });
    interaction.reply({ content: `**تم انهاء التعليم \n عليك الاجابه علي الاساله لكي يتم قبولك**`, ephemeral: true });
  }
});
//   _____               _    
 // |___ /   _ __ ___   | | __
  // |_ \  | '_ ` _ \  | |/ /
  // ___) | | | | | | | |   < 
 // |____/  |_| |_| |_| |_|\_\
                                          