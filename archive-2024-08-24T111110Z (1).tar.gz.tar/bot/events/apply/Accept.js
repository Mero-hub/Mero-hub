const client = require("../../index.js");
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const apply = require("../../Datebase/model/apply/support_apply.js");
client.on("interactionCreate", async (interaction) => {
  if (interaction.isButton()) {
    if (interaction.customId === "accept_support") {
        if (!interaction.member.roles.cache.has("1262820500824920144")) return interaction.reply({ content: `You don't have permission to use this button.`, ephemeral: true })
const messageContent = interaction.message.content;

const regex = /<@!?(\d+)>/;

const match = messageContent.match(regex);

if (match) {

    const member = match[1];

    const user = interaction.guild.members.cache.get(member);

    

    if (user) {

        user.roles.add("1266357086678417563").catch((e) => console.log(e));

    } else {

        console.log(`User with ID ${member} not found`);

    }

} else {

    console.log("الرسالة مبيهة ايدي");

}


        

     const embed = new EmbedBuilder()
        .setTitle("تم قبولك")
        .setDescription(`تم قبولك ک اداري في سيرفر كينك حياك الله للاختبار والتعليم<#1266359399962640394>`)

        .setColor("#000100")

.setAuthor({
            name: interaction.guild.name,
            iconURL: interaction.guild.iconURL()
          })
          .setFooter({
            text: interaction.guild.name,
            iconURL: interaction.guild.iconURL()
          })
          .setThumbnail(interaction.guild.iconURL())
        .setTimestamp();
        const channel = interaction.guild.channels.cache.get("1252733230331985982");
        const member = match[1];
      await channel.send({
       content: `> <@${member}>`,
       embeds: [embed]
      });
      
      
      
      await interaction.reply({
        content: `تم قبول <@${member}> كـ اداري بسيرفر كينك`,
        ephemeral: true,
      })
            const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('accept_mediator')
          .setLabel(`تم قبول المقدم من قبل ${interaction.user.tag}`)
        .setDisabled(true)
.setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId('decline_mediator')
          .setLabel('رفض')
        .setDisabled(true)
          .setStyle(ButtonStyle.Danger),
        new ButtonBuilder()
          .setCustomId('blacklist_report')
          .setLabel('حظر')
        .setDisabled(true)
          .setStyle(ButtonStyle.Secondary),
      );
      await interaction.message.edit({
components: [row]
      })
    } else if (interaction.customId === "accept_mediator")  {
      if (!interaction.member.roles.cache.has("1262820500824920144")) return interaction.reply({ content: `You don't have permission to use this button.`, ephemeral: true })
      const messageContent = interaction.message.content;

const regex = /<@!?(\d+)>/;
const match = messageContent.match(regex);

if (match) {
    const member = match[1];
    const user = interaction.guild.members.cache.get(member);

    

    if (user) {
        user.roles.add("1266357086678417563").catch((e) => console.log(e));
    } else {
        console.log(`User with ID ${member} not found`);
    }
} else {
    console.log("ماكو ايدي بلرسالة");
}

      const embed = new EmbedBuilder()
        .setTitle("تم قبولك")
        .setDescription(`تم قبولك كـ وسيط بسيرفر كينك 
 حياك للتعليم و الأختبار <#1266359399962640394>
`)
      .setColor("#000100")

.setAuthor({
            name: interaction.guild.name,
            iconURL: interaction.guild.iconURL()
          })
          .setFooter({
            text: interaction.guild.name,
            iconURL: interaction.guild.iconURL()
          })
          .setThumbnail(interaction.guild.iconURL())
        .setTimestamp();
        const channel = interaction.guild.channels.cache.get("1252733230331985982");
        const member = match[1];
      await channel.send({
       content: `> <@${member}>`,
       embeds: [embed]
      });
      
      
      
      await interaction.reply({
        content: `تم قبول <@${member}> كـ وسيط بسيرفر كينك`,
        ephemeral: true,
      })
                  const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('accept_mediator')
          .setLabel(`تم قبول المقدم من قبل ${interaction.user.tag}`)
        .setDisabled(true)
.setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId('decline_mediator')
          .setLabel('رفض')
        .setDisabled(true)
          .setStyle(ButtonStyle.Danger),
        new ButtonBuilder()
          .setCustomId('blacklist_report')
          .setLabel('حظر')
        .setDisabled(true)
          .setStyle(ButtonStyle.Secondary),


      );
      await interaction.message.edit({
components: [row]
      })
    } else if (interaction.customId === "accept_report") {
      if (!interaction.member.roles.cache.has("1262820500824920144")) return interaction.reply({ content: `You don't have permission to use this button.`, ephemeral: true })
      const messageContent = interaction.message.content;

const regex = /<@!?(\d+)>/;

const match = messageContent.match(regex);

if (match) {
const member = match[1];
    
    const user = interaction.guild.members.cache.get(member);

        if (user) {

        user.roles.add("1266357086678417563").catch((e) => console.log(e));

    } else {

        console.log(`User with ID ${member} not found`);

    }

} else {

    console.log("ماكو ايدي بلرسالة");

}
      const embed = new EmbedBuilder()
        .setTitle("تم قبولك")
        .setDescription(`تم قبولك كـ قاضي بسيرفر كينك 
 حياك للتعليم و الأختبار <#1266359399962640394>`)
      .setColor("#000100")

.setAuthor({
            name: interaction.guild.name,
            iconURL: interaction.guild.iconURL()
          })
          .setFooter({
            text: interaction.guild.name,
            iconURL: interaction.guild.iconURL()
          })
          .setThumbnail(interaction.guild.iconURL())
        .setTimestamp();
        const channel = interaction.guild.channels.cache.get("1252733230331985982");
        const member = match[1];
      await channel.send({
       content: `> <@${member}>`,
       embeds: [embed]
      });
      
      
      
      await interaction.reply({
        content: `تم قبول <@${member}> كـ قاضي بسيرفر ريدبول`,
        ephemeral: true,
      })
                  const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('accept_mediator')
          .setLabel(`تم قبول المقدم من قبل ${interaction.user.tag}`)
        .setDisabled(true)
.setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId('decline_mediator')
          .setLabel('رفض')
        .setDisabled(true)
          .setStyle(ButtonStyle.Danger),
        new ButtonBuilder()
          .setCustomId('blacklist_report')
          .setLabel('حظر')
        .setDisabled(true)
          .setStyle(ButtonStyle.Secondary),
      );
      await interaction.message.edit({
components: [row]
      })
    }
  }
});