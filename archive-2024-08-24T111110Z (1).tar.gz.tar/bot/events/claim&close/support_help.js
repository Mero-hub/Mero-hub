const client = require("../../index.js");
const { EmbedBuilder, ApplicationCommandOptionType , Events , ActionRowBuilder , ButtonBuilder ,MessageAttachment, ButtonStyle , Message, TextInputStyle,TextInputBuilder,ModalBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, PermissionsBitField } = require("discord.js");
client.on('interactionCreate', async interaction => {
  if (!interaction.isButton()) return;
  if (interaction.customId === 'help') {
    if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) return interaction.reply({ content: `**هنهزر يسطا ولا ايه**`, ephemeral: true });
   const row = new StringSelectMenuBuilder()
    .setCustomId('support_help1')
    .setPlaceholder('برجاء التحديد')
    .addOptions(
      new StringSelectMenuOptionBuilder()
        .setLabel('اضافه شخص للتذكرة')
        .setValue('support_add_user'),
      new StringSelectMenuOptionBuilder()
        .setLabel('ازاله شخص من التذكرة')
        .setValue('support_remove_user'),
      new StringSelectMenuOptionBuilder()
        .setLabel('تغيير اسم التذكره')
        .setValue('support_change_name'),
      new StringSelectMenuOptionBuilder()
        .setLabel('اضافه رتبه لشخص')
        .setValue('support_add_role'),
    );
    const row1 = new ActionRowBuilder()
      .addComponents(row);
    interaction.reply({
      components: [row1],
      ephemeral: true
    });
  }
});
client.on('interactionCreate', async interaction => {
  if (!interaction.isStringSelectMenu()) return;
  if (interaction.customId === 'support_help1') {
    const selectedValue = interaction.values[0];
    if (selectedValue === 'support_add_user') {
      const modal = new ModalBuilder()
        .setCustomId('support_add_user_modal')
        .setTitle('اضافه شخص للتذكرة');
      const user_id = new TextInputBuilder()
        .setCustomId('support_user_id')
        .setLabel("ايدي الشخص")
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
        .setPlaceholder('حط ايدي الشخص');
      const row = new ActionRowBuilder().addComponents(user_id);
      modal.addComponents(row);
      await interaction.showModal(modal);
    } else if (selectedValue === 'support_remove_user') {
      const modal = new ModalBuilder()
        .setCustomId('support_remove_user_modal')
        .setTitle('ازاله شخص من التذكرة');
      const reovem_user_id = new TextInputBuilder()
        .setCustomId('support_remove_user_id')
        .setLabel("ايدي الشخص")
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
        .setPlaceholder('حط ايدي الشخص');
      const row = new ActionRowBuilder().addComponents(reovem_user_id);
      modal.addComponents(row);
      await interaction.showModal(modal);
    } else if (selectedValue === 'support_change_name') {
      const modal = new ModalBuilder()
        .setCustomId('support_change_name_modal')
        .setTitle('تغيير اسم التذكره');
      const name = new TextInputBuilder()
        .setCustomId('support_name')
        .setLabel("تغيير اسم التذكره")
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
        .setPlaceholder('حط اسم التذكرة');
      const row = new ActionRowBuilder().addComponents(name);
      modal.addComponents(row);
      await interaction.showModal(modal);
    } else if (selectedValue === 'support_add_role') {
      const modal = new ModalBuilder()
        .setCustomId('support_add_role_modal')
        .setTitle('اضافه رتبه لشخص');
      const user_id1 = new TextInputBuilder()
        .setCustomId("support_add_role_user_id")
        .setLabel("ايدي الشخص")
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
        .setPlaceholder('حط ايدي الشخص');
      const role_id = new TextInputBuilder()
        .setCustomId('support_role_id')
        .setLabel("ايدي الرتبه")
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
        .setPlaceholder('حط ايدي الرتبه');
      const row1 = new ActionRowBuilder().addComponents(user_id1)
      const row = new ActionRowBuilder().addComponents(role_id);
      modal.addComponents(row1, row);
      await interaction.showModal(modal);
    }
  }
});
client.on('interactionCreate', async interaction => {
  if (!interaction.isModalSubmit()) return;
  if (interaction.customId === 'support_add_user_modal') {
    const user_id = interaction.fields.getTextInputValue('support_user_id');
    const channel = interaction.channel;
    const member = interaction.guild.members.cache.get(user_id);
    if (!member) {
      return interaction.reply({
        content: 'الشخص غير موجود في السيرفر',
        ephemeral: true
      });
    }
  channel.permissionOverwrites.create(member, {
    ViewChannel: true,
    SendMessages: true
  });
  interaction.reply({
    content: `تم اضافه ${member} للتذكرة`,
    ephemeral: true
  });
  } else if (interaction.customId === 'support_remove_user_modal') {
    const remove_user_id = interaction.fields.getTextInputValue('support_remove_user_id');
    const channel = interaction.channel;
    const member = interaction.guild.members.cache.get(remove_user_id);
    if (!member) {
      return interaction.reply({
        content: 'الشخص غير موجود في السيرفر',
        ephemeral: true
      });
    }
    channel.permissionOverwrites.delete(member);
    interaction.reply({
      content: `تم ازاله ${member} من التذكرة`,
      ephemeral: true
    });
  } else if (interaction.customId === 'support_change_name_modal') {
    const name = interaction.fields.getTextInputValue('support_name');
    const channel = interaction.channel;
    channel.setName(name);
    interaction.reply({
      content: `تم تغيير اسم التذكره الى \`\`\`${name}\`\`\``,
      ephemeral: true
    });
  } else if (interaction.customId === 'support_add_role_modal') {
    const user_id = interaction.fields.getTextInputValue('support_add_role_user_id');
    const role_id = interaction.fields.getTextInputValue('support_role_id');
    const channel = interaction.channel;
    const member = interaction.guild.members.cache.get(user_id);
    const role = interaction.guild.roles.cache.get(role_id);
    if (!member) {
      return interaction.reply({
        content: 'الشخص غير موجود في السيرفر',
        ephemeral: true
      });
    }
    member.roles.add(role);
    await interaction.reply({
      content: `تم اضافه ${role} لـ ${member}`,
      ephemeral: true
    })
  }
});