const client = require("../../index.js");
const { EmbedBuilder, ActionRowBuilder , ButtonBuilder , ButtonStyle, TextInputStyle,TextInputBuilder,ModalBuilder } = require("discord.js");
const counters = require('../../Datebase/model/counters/tesing-counter1.js');
client.on('interactionCreate', async interaction => {
  if (!interaction.isStringSelectMenu()) return;
  if (interaction.customId === 'testing') {
    const selectedValue = interaction.values[0];
    if (selectedValue === 'testing-support') {
      const counter = await counters.updateOne(
        { guildId: interaction.guild.id },
        { $inc: { counter: 1 } },
        { upsert: true }
      );
      const findCount = await counters.findOne({ guildId: interaction.guild.id });
      const ctr = findCount.counter
      const test = await interaction.guild.channels.create({
        name: `test-${ctr}`,
        type: 0,
        parent: '1268156468050264114',
        permissionOverwrites: [
          {
            id: interaction.guild.id,
            deny: ['ViewChannel'],
          },
          {
            id: interaction.user.id,
            allow: ['ViewChannel'],
          },
        ],
      });
      await interaction.reply({
        content: `تم إنشاء تذكرتك في ${test}`,
        ephemeral: true,
      })
      const row = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId('start-test1')
            .setLabel('بدء الاختبار')
          .setStyle(ButtonStyle.Secondary),
          new ButtonBuilder()
            .setCustomId('delete_ticket-supy')
            .setLabel('حذف التذكره')
            .setStyle(ButtonStyle.Danger)
        ); 
const embed = new EmbedBuilder()
.setDescription(
  `**- اهلا وسهلا في تكت التعليم والاختبار علي طاقم الاداره\n يمكنك الضغط علي زر بدا الاختبار و تعبئه **`)
.setColor("#2f3136")
.setImage("https://media.discordapp.net/attachments/1249856158458708100/1267070830492516362/82fbde3cdddd9b41.jpg?ex=66aabeeb&is=66a96d6b&hm=2d655cfe8d37ffa70db309053a6f5fcbd63582c6d41b3cb329e7e515ec4b4bf7&")
.setTimestamp()
      .setAuthor({
        name: interaction.guild.name,
        iconURL: interaction.guild.iconURL()})
        .setFooter({
        text: interaction.guild.name,
          iconURL: interaction.guild.iconURL()
        })

        .setThumbnail(interaction.guild.iconURL());
      await test.send({
        content: `${interaction.user}||<@&1262820500824920144>`,
        components: [row],
        embeds: [embed],
      });

    } else if (selectedValue === 'testing-mediator') {
      const counter = await counters.updateOne(
        { guildId: interaction.guild.id },
        { $inc: { counter: 1 } },
        { upsert: true }
      );
      const findCount = await counters.findOne({ guildId: interaction.guild.id });
      const ctr = findCount.counter
      const test = await interaction.guild.channels.create({
        name: `test-${ctr}`,
        type: 0,
        parent: '1268156468050264114',
        permissionOverwrites: [
          {
            id: interaction.guild.id,
            deny: ['ViewChannel'],
          },
          {
            id: interaction.user.id,
            allow: ['ViewChannel'],
          },
         {
            id: "1262820500824920144",
            allow: ['ViewChannel'],
          },
        ],
      });
      await interaction.reply({
        content: `تم إنشاء تذكرتك في ${test}`,
        ephemeral: true,
      })
    const row = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId('start-test2')
            .setLabel('بدء الاختبار')
          .setStyle(ButtonStyle.Secondary),
          new ButtonBuilder()
            .setCustomId('delete_ticket-medi')
            .setLabel('حذف التذكره')
            .setStyle(ButtonStyle.Danger)
        ); 
const embed = new EmbedBuilder()
.setDescription(
  `**- اهلا وسهلا في تكت التعليم والاختبار علي طاقم الاداره\n يمكنك الضغط علي زر بدا الاختبار و تعبئه **`)
.setColor("#2f3136")
.setImage("https://media.discordapp.net/attachments/1249856158458708100/1267070830492516362/82fbde3cdddd9b41.jpg?ex=66aabeeb&is=66a96d6b&hm=2d655cfe8d37ffa70db309053a6f5fcbd63582c6d41b3cb329e7e515ec4b4bf7&")
.setTimestamp()
      .setAuthor({
        name: interaction.guild.name,
        iconURL: interaction.guild.iconURL()})
        .setFooter({
        text: interaction.guild.name,
          iconURL: interaction.guild.iconURL()
        })

        .setThumbnail(interaction.guild.iconURL());
      await test.send({
        content: `${interaction.user}||<@&1262820500824920144>`,
        components: [row],
        embeds: [embed],
      });
    
    } else if (selectedValue === 'testing-report') {
      const counter = await counters.updateOne(
        { guildId: interaction.guild.id },
        { $inc: { counter: 1 } },
        { upsert: true }
      );
      const findCount = await counters.findOne({ guildId: interaction.guild.id });
      const ctr = findCount.counter
      const test = await interaction.guild.channels.create({
        name: `test-${ctr}`,
        type: 0,
        parent: '1268156468050264114',
        permissionOverwrites: [
          {
            id: interaction.guild.id,
            deny: ['ViewChannel'],
          },
          {
            id: interaction.user.id,
            allow: ['ViewChannel'],
          },
         {
            id: "1262820500824920144",
            allow: ['ViewChannel'],
          },
        ],
      });
      await interaction.reply({
        content: `تم إنشاء تذكرتك في ${test}`,
        ephemeral: true,
      })
    const row = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId('start-test3')
            .setLabel('بدء الاختبار')
          .setStyle(ButtonStyle.Secondary),
          new ButtonBuilder()
            .setCustomId('delete_ticket-reporty')
            .setLabel('حذف التذكره')
            .setStyle(ButtonStyle.Danger)
        ); 
const embed = new EmbedBuilder()
.setDescription(
  `**- اهلا وسهلا في تكت التعليم والاختبار علي طاقم الاداره\n يمكنك الضغط علي زر بدا الاختبار و تعبئه **`)
.setColor("#2f3136")
.setImage("https://media.discordapp.net/attachments/1249856158458708100/1267070830492516362/82fbde3cdddd9b41.jpg?ex=66aabeeb&is=66a96d6b&hm=2d655cfe8d37ffa70db309053a6f5fcbd63582c6d41b3cb329e7e515ec4b4bf7&")
.setTimestamp()
      .setAuthor({
        name: interaction.guild.name,
        iconURL: interaction.guild.iconURL()})
        .setFooter({
        text: interaction.guild.name,
          iconURL: interaction.guild.iconURL()
        })

        .setThumbnail(interaction.guild.iconURL());
      await test.send({
        content: `${interaction.user}||<@&1262820500824920144>`,
        components: [row],
        embeds: [embed],
      });
    }
  }
});
client.on('interactionCreate', async interaction => {
  if (!interaction.isButton()) return;
  if (interaction.customId === 'call') {
    interaction.channel.send({
      content: `**<@&1262820500824920144>`
    });
    interaction.reply({
      content: `تم استدعاء الاداره`,
      ephemeral: true
    });
  } else if (interaction.customId === 'delete_ticket-supy') {
   if (!interaction.member.roles.cache.has('1262820500824920144')) return interaction.reply({ content: `**لا يمكنك استخدام هذا الزر**`, ephemeral: true });
    const embed = new EmbedBuilder()
      .setDescription(`** سوف يتم حذف التذكره بعد 5 ثواني**`)
      .setColor('#000100')
      .setTimestamp();
    await interaction.reply({ embeds: [embed] });
    setTimeout(async () => {
interaction.channel.delete() 
}, 5000)
  } else if (interaction.customId === 'delete_ticket-medi') {
    if (!interaction.member.roles.cache.has('1262820500824920144')) return interaction.reply({ content: `**لا يمكنك استخدام هذا الزر**`, ephemeral: true });
    const embed = new EmbedBuilder()
      .setDescription(`** سوف يتم حذف التذكره بعد 5 ثواني**`)
      .setColor('#000100')
      .setTimestamp();
    await interaction.reply({ embeds: [embed] });
    setTimeout(async () => {
interaction.channel.delete() 
}, 5000)
  } else if (interaction.customId === 'delete_ticket-reporty') {
    if (!interaction.member.roles.cache.has('1262820500824920144')) return interaction.reply({ content: `**لا يمكنك استخدام هذا الزر**`, ephemeral: true });
    const embed = new EmbedBuilder()
      .setDescription(`** سوف يتم حذف التذكره بعد 5 ثواني**`)
      .setColor('#000100')
      .setTimestamp();
    await interaction.reply({ embeds: [embed] });
    setTimeout(async () => {
interaction.channel.delete() 
}, 5000)
  }
});
