const client = require("../../index.js");
const config = require("../../config.json")
const { EmbedBuilder, ApplicationCommandOptionType , Events , ActionRowBuilder , ButtonBuilder ,MessageAttachment, ButtonStyle , Message, TextInputStyle,TextInputBuilder,ModalBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, PermissionsBitField } = require("discord.js");
const ms = require("ms")
const moment = require("moment")
const users = require('../../Datebase/model/buy.js');
const rooms = require('../../Datebase/model/Private-room.js')


client.on('interactionCreate', async interaction => {
  if (!interaction.isStringSelectMenu()) return;
  if (interaction.customId === 'buy') {
  const selectedValue = interaction.values[0];
if (selectedValue === 'room') {

  
    let check = await rooms.findOne({
        Privatecount: {
          $gt: 0
        }
      })
    const Privatecount = require('../../Datebase/model/Private-room.js')

if(Privatecount === 15) return interaction.reply({
        content: `**تم شراء العدد الاقصي من الرومات الخاصة**`,
        ephemeral: true
      });
///////////////////////////////{{{===========================================buy=============================================}}}
    let price = config.price_room;
  let result = price;
  let tax = Math.floor(price * (20 / 19) + 1);
  let owner = config.owner;
  const embed = new EmbedBuilder()
    
    .setTitle("شراء روم خاص")
    .setDescription(`**قم بلتحويل لإكمال العملية**
    **قم بتحويل الى** <@${owner}> 
    **قم بتحويل مبلغ** ${tax}
    \`\`\`
    #credit ${owner} ${tax} 
    \`\`\``) 
    .setColor(`#2AB3A9`)
      .setThumbnail(interaction.guild.iconURL({dynamic:true}))
      .setTimestamp();
    await interaction.update({
      embeds: [embed],
      components: [],
       
    })
    await interaction.channel.send({
      content: `#credit ${owner} ${tax}`
    })
  const filter = ({ content, author: { id } }) => {
        return (
            content.startsWith(`**:moneybag: | ${interaction.user.username}, has transferred `) &&
            content.includes(`${owner}`) &&
            id === "282859044593598464" &&
            (Number(content.slice(content.lastIndexOf("`") - String(tax).length, content.lastIndexOf("`"))) >= result)
        );
    };

      const collector = interaction.channel.createMessageCollector({ 
        filter,               
        max: 1,
        time: 60000,
        });
        let iscollected = false;
        collector.on('collect', async (collected) => {
        iscollected = true;
        const embed = new EmbedBuilder()
    .setTitle("شراء روم خاص")
    .setDescription(`**تم شراء روم خاص بنجاح**`)
    .setColor(`#2AB3A9`)
    .setThumbnail(interaction.guild.iconURL({dynamic:true}))
    .setTimestamp();
  const row = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('room-name')
        .setLabel('قم بوضع اسم الروم')
        .setStyle(ButtonStyle.Success)
    );
  await interaction.editReply({
    embeds: [embed],
    components: [row],
  })

const user = await users.deleteOne({ userId: interaction.user.id });
});
    collector.on('end', async (collected) => {
  if (!iscollected) {
    const embed = new EmbedBuilder()
      .setTitle("شراء روم خاص")
      .setDescription(`**انتهى الوقت للتحويل**`)
      .setColor(`#2AB3A9`)
      .setThumbnail(interaction.guild.iconURL({dynamic:true}))
      .setTimestamp();
    await interaction.editReply({
      embeds: [embed],
      components: [],
    })
    const user = await users.deleteOne({ userId: interaction.user.id });
  }
});
  
  
    } 
  }
});
//=============================================================={{{========================}}}}}
client.on('interactionCreate', async interaction => {
  if (!interaction.isButton()) return;
  if (interaction.customId === 'room-name') {
    const modal = new ModalBuilder()
      .setCustomId('room-name-modal')
     .setTitle('قم بوضع اسم الروم');
    const name = new TextInputBuilder()
      .setCustomId('name')
      .setLabel("اسم الروم")
      .setStyle(TextInputStyle.Short);
    const firstActionRow = new ActionRowBuilder().addComponents(name);
    modal.addComponents(firstActionRow);
    await interaction.showModal(modal);
  }
});
//==============================================================================================//
client.on('interactionCreate', async interaction => {
  if (!interaction.isModalSubmit()) return;
  if (interaction.customId === 'room-name-modal') {
    const name = interaction.fields.getTextInputValue('name');
    
    const room = await interaction.guild.channels.create({
      name: name,
      type: 0,
      parent: config.privateroomcatogray,
      permissionOverwrites: [
        {
          id: interaction.guild.id,
            allow: ['ViewChannel'],
        },
        {
          id: interaction.user.id,
          allow: ["SendMessages", "ViewChannel", "MentionEveryone", "AttachFiles"]
        },
      ],
    });
const userroom = await rooms.create({
guildId: interaction.guild.id,
ownerId: interaction.user.id,
channelId: room.id
})
userroom.save();

const updatecount = await rooms.updateOne(
  { guildId: interaction.guild.id },
  { $inc: { Privatecount: 1 } },
  { upsert: true }
);

  const row = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('room-name')
        .setLabel('قم بوضع اسم الروم')
        .setStyle(ButtonStyle.Success)
    );
    interaction.message.edit({
      components: [row],
    })
    await interaction.reply({
          content: `تم إنشاء الروم الخاص في ${room}`,
          ephemeral: true,
        });
    const embed = new EmbedBuilder()
    .setTitle(`روم خاص جديد`) 
    .addFields(
      {
        name: `صاحب الروم`,
        value: `${interaction.user}`,
        inline: true
      },
      {
        name: `وقت الانشاء`,
        value: `
${moment(room.createdAt).format(`**<t:${Math.floor(Date.now() / 1000)}:R>**`)}`,
        inline: true
      },
      {
        name: `وقت الانتهاء`,
        value: `<t:${Math.floor((Date.now() + ms("7d")) / 1000)}:R>`,
        inline: true
      },
    )
    .setTimestamp()
    .setFooter({
      text: interaction.guild.name,
        iconURL: interaction.guild.iconURL()
    })
    .setThumbnail(interaction.guild.iconURL())
    .setAuthor({
      name: interaction.guild.name,
        iconURL: interaction.guild.iconURL()
    })
    .setColor("#000100");
    const change = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('change-name-Private')
        .setLabel('تغيير اسم الروم')
        .setStyle(ButtonStyle.Success)
    );
    await room.send({
      embeds: [embed],
      components: [change]
    });
    await room.send({
   content: `نشر بعد اغلاق الرومات او قبل فتح الرومات = تحذير
تحذيرين = حذف الروم`
    });


const expiration = moment().add(7, 'days').toDate();
    const reminder = moment(expiration).subtract(1, 'days').toDate();

    setTimeout(() => {
        room.send('Your temporary room will expire in 1 day. Renew it or it will be deleted.');
    }, reminder - Date.now());

    setTimeout(() => {
        room.delete();
    }, expiration - Date.now());
  
  }
});
//=============================================================={{{========================}}}}}


client.on('interactionCreate', async interaction => {
  if (!interaction.isButton()) return;
  const rooom = await rooms.findOne({ guildId: interaction.guild.id, ownerId: interaction.user.id, channelId: interaction.channel.id });
  if (interaction.customId === 'change-name-Private') {
    
    if (interaction.user.id === rooom.ownerId) {
    const modal = new ModalBuilder()
      .setCustomId('change-name-Private-modal')
      .setTitle('تغيير اسم الروم');
    const name = new TextInputBuilder()
      .setCustomId('name')
      .setLabel("اسم الروم")
      .setStyle(TextInputStyle.Short);
    const firstActionRow = new ActionRowBuilder().addComponents(name);
    modal.addComponents(firstActionRow);
    await interaction.showModal(modal);
      } else {
      interaction.reply({
        content: `**لا يمكنك تغيير اسم الروم**`,
        ephemeral: true,
      })
    }
  }
});