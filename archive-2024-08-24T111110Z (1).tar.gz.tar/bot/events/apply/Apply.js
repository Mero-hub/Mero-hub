const client = require("../../index.js");
const { EmbedBuilder, ApplicationCommandOptionType , Events , ActionRowBuilder , ButtonBuilder ,MessageAttachment, ButtonStyle , Message, TextInputStyle,TextInputBuilder,ModalBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, PermissionsBitField } = require("discord.js");
const apply = require("../../Datebase/model/apply/support_apply.js");
const blacklists = require("../../Datebase/model/apply/blacklist.js");

client.on('interactionCreate', async interaction => {
  if (!interaction.isButton()) return;
  if (interaction.customId === 'support_apply') {
  const support = await apply.findOne({ guildId: interaction.guild.id, userId: interaction.user.id });
  if (support) return interaction.reply({ content: `You already have an application in progress.`, ephemeral: true });
const blacklist = await blacklists.findOne({ guildId: interaction.guild.id, userId: interaction.user.id });
  if (blacklist) return interaction.reply({ content: `You are blacklisted from applying`, ephemeral: true });
if (interaction.member.roles.cache.has("1266357086678417563")) return interaction.reply({ content: `You already are With in the administration `, ephemeral: true });
     const model = new ModalBuilder()
      .setCustomId("support_model")
      .setTitle("التقديم على الدعم الفني")
      const name = new TextInputBuilder()
      .setCustomId('name')
      .setLabel("ما اسمك؟")
      .setStyle(TextInputStyle.Short)
      .setRequired(true);
      const age = new TextInputBuilder()
      .setCustomId('age')
      .setLabel('كم عمرك؟')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);
      const country = new TextInputBuilder()
      .setCustomId('country')
      .setLabel("ماهي البلد؟")
      .setStyle(TextInputStyle.Short)
      .setRequired(true);
      const experience = new TextInputBuilder()
      .setCustomId('experience')
      .setLabel('ماهي هي الخبرات؟')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);
      const why = new TextInputBuilder()
      .setCustomId('why')
      .setLabel('ما هو سبب التقديم؟')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);
      const firstActionRow = new ActionRowBuilder().addComponents(name);
      const secondActionRow = new ActionRowBuilder().addComponents(age);
      const thirdActionRow = new ActionRowBuilder().addComponents(country);
      const fourthActionRow = new ActionRowBuilder().addComponents(experience);
      const fifthActionRow = new ActionRowBuilder().addComponents(why);
      model.addComponents(firstActionRow, secondActionRow, thirdActionRow, fourthActionRow, fifthActionRow)
      await interaction.showModal(model);
    } else if (interaction.customId === 'mediator_apply') {
const mad = await apply.findOne({ guildId: interaction.guild.id, userId: interaction.user.id });
  if (mad) return interaction.reply({ content: `You already have an application in progress.`, ephemeral: true });
if (interaction.member.roles.cache.has("1266357086678417563")) return interaction.reply({ content: `You already are With in the administration `, ephemeral: true });
     const model = new ModalBuilder()
      .setCustomId("mediator_model")
      .setTitle("التقديم على الوسطاء")
      const name = new TextInputBuilder()
      .setCustomId('mediator_name')
      .setLabel("ما اسمك؟")
      .setStyle(TextInputStyle.Short)
      .setRequired(true);
      const age = new TextInputBuilder()
      .setCustomId('mediator_age')
      .setLabel('كم عمرك؟')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);
      const country = new TextInputBuilder()
      .setCustomId('mediator_country')
      .setLabel("ماهي البلد؟")
      .setStyle(TextInputStyle.Short)
      .setRequired(true);
          const experience = new TextInputBuilder()
      .setCustomId('mediator_experience')
      .setLabel('ماهي هي الخبرات؟')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);
      const why = new TextInputBuilder()
        
      .setCustomId('mediator_why')
      .setLabel('ما هو سبب التقديم؟')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);
      const firstActionRow = new ActionRowBuilder().addComponents(name);
      const secondActionRow = new ActionRowBuilder().addComponents(age);
      const thirdActionRow = new ActionRowBuilder().addComponents(country);
      const fourthActionRow = new ActionRowBuilder().addComponents(experience);
      const fifthActionRow = new ActionRowBuilder().addComponents(why);
      model.addComponents(firstActionRow, secondActionRow, thirdActionRow, fourthActionRow, fifthActionRow)
      await interaction.showModal(model);
    } else if (interaction.customId === 'report_apply') {
    const report = await apply.findOne({ guildId: interaction.guild.id, userId: interaction.user.id });
  if (report) return interaction.reply({ content: `You already have an application in progress.`, ephemeral: true });
if (interaction.member.roles.cache.has("1266357086678417563")) return interaction.reply({ content: `You already are With in the administration `, ephemeral: true });
     const model = new ModalBuilder()
      .setCustomId("report_model")
      .setTitle("التقديم على القضاه")
      const name = new TextInputBuilder()
      .setCustomId('report_name')
      .setLabel("ما اسمك؟")
      .setStyle(TextInputStyle.Short)
      .setRequired(true);
      const age = new TextInputBuilder()
      .setCustomId('report_age')
      .setLabel('كم عمرك؟')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);
      const country = new TextInputBuilder()
      .setCustomId('report_country')
      .setLabel("ماهي البلد؟")
      .setStyle(TextInputStyle.Short)
      .setRequired(true);
          const experience = new TextInputBuilder()
      .setCustomId('report_experience')
      .setLabel('ماهي هي الخبرات؟')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);
      const why = new TextInputBuilder()
        
      .setCustomId('report_why')
      .setLabel('ما هو سبب التقديم؟')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);
      const firstActionRow = new ActionRowBuilder().addComponents(name);
      const secondActionRow = new ActionRowBuilder().addComponents(age);
      const thirdActionRow = new ActionRowBuilder().addComponents(country);
      const fourthActionRow = new ActionRowBuilder().addComponents(experience);
      const fifthActionRow = new ActionRowBuilder().addComponents(why);
      model.addComponents(firstActionRow, secondActionRow, thirdActionRow, fourthActionRow, fifthActionRow)
      await interaction.showModal(model);
    }
});
client.on('interactionCreate', async interaction => {
  if (!interaction.isModalSubmit()) return;
  if (interaction.customId === 'support_model') {
    const name = interaction.fields.getTextInputValue('name');
    const age = interaction.fields.getTextInputValue('age');
    const country = interaction.fields.getTextInputValue('country');
    const experience = interaction.fields.getTextInputValue('experience');
    const why = interaction.fields.getTextInputValue('why');
    const channel = interaction.guild.channels.cache.get("1268972881564532897");
    const embed = new EmbedBuilder()
      .setTitle("تقديم جديد !")
       .addFields(
         {
           name: "الاسم",
           value: `${name}`
         },
         {
           name: "العمر",
           value: `${age}`
         },
         {
           name: "البلد",
           value: `${country}`
         },
         {
           name: "الخبرات",
           value: `${experience}`
         },
         {
           name: "سبب التقديم",
           value: `${why}`
         }
       )
      .setTimestamp()
      .setFooter({ text: interaction.user.username , iconURL: interaction.user.displayAvatarURL() });
    await interaction.reply({
      content: "تم ارسال التقديم بنجاح",
      ephemeral: true
    });
    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('accept_support')
          .setLabel('قبول')
          .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId('decline_support')
          .setLabel('رفض')
          .setStyle(ButtonStyle.Danger),
        new ButtonBuilder()
          .setCustomId('blacklist_support')
          .setLabel('حظر')
          .setStyle(ButtonStyle.Secondary),
      );
    await channel.send({ content: `<@${interaction.user.id}>`, embeds: [embed], components: [row] });
const model = new apply({
  guildId: interaction.guild.id,
  userId: interaction.user.id
});
await model.save();
  } else if (interaction.customId === 'mediator_model') {
    const name = interaction.fields.getTextInputValue('mediator_name');
    const age = interaction.fields.getTextInputValue('mediator_age');
    const country = interaction.fields.getTextInputValue('mediator_country');
    const experience = interaction.fields.getTextInputValue('mediator_experience');
    const why = interaction.fields.getTextInputValue('mediator_why');
    const channel = interaction.guild.channels.cache.get("1255860582309953648");
    const embed = new EmbedBuilder()
      .setTitle("تقديم جديد !")
       .addFields(
         {
           name: "الاسم",
           value: `${name}`
         },
         {
           name: "العمر",
           value: `${age}`
         },
         {
           name: "البلد",
           value: `${country}`
         },
         {
           name: "الخبرات",
           value: `${experience}`
         },
         {
           name: "سبب التقديم",
           value: `${why}`
         }
       )
      .setTimestamp()
      .setFooter({ text: interaction.user.username , iconURL: interaction.user.displayAvatarURL() });
    await interaction.reply({
      content: "تم ارسال التقديم بنجاح",
      ephemeral: true
    });
    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('accept_mediator')
          .setLabel('قبول')
          .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId('decline_mediator')
          .setLabel('رفض')
          .setStyle(ButtonStyle.Danger),
        new ButtonBuilder()
          .setCustomId('blacklist_mediator')
          .setLabel('حظر')
          .setStyle(ButtonStyle.Secondary),
      );
    await channel.send({ content: `<@${interaction.user.id}>`, embeds: [embed], components: [row] });
  } else if (interaction.customId === 'report_model') {
    const name = interaction.fields.getTextInputValue('report_name');
    const age = interaction.fields.getTextInputValue('report_age');
    const country = interaction.fields.getTextInputValue('report_country');
    const experience = interaction.fields.getTextInputValue('report_experience');
    const why = interaction.fields.getTextInputValue('report_why');
    const channel = interaction.guild.channels.cache.get("1268972926171090976");
    const embed = new EmbedBuilder()
      .setTitle("تقديم جديد !")
       .addFields(
         {
           name: "الاسم",
           value: `${name}`
         },
         {
           name: "العمر",
           value: `${age}`
         },
         {
           name: "البلد",
           value: `${country}`
         },
         {
           name: "الخبرات",
           value: `${experience}`
         },
         {
           name: "سبب التقديم",
           value: `${why}`
         }
       )
      .setTimestamp()
      .setFooter({ text: interaction.user.username , iconURL: interaction.user.displayAvatarURL() });
    await interaction.reply({
      content: "تم ارسال التقديم بنجاح",
      ephemeral: true
    });
    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('accept_report')
          .setLabel('قبول')
          .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId('decline_report')
          .setLabel('رفض')
          .setStyle(ButtonStyle.Danger),
        new ButtonBuilder()
          .setCustomId('blacklist_report')
          .setLabel('حظر')
          .setStyle(ButtonStyle.Secondary),
      );
    await channel.send({ content: `<@${interaction.user.id}>`, embeds: [embed], components: [row] });
  }
});