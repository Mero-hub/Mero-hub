const { ActivityType,ApplicationCommandType,ContextMenuCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { prefix } = require('../../config.json');

module.exports = {
    name: 'ready',
    once: true,
    execute(client) {
        console.log(`Logged in as ${client.user.tag}`);
        console.log(`Servers: ${client.guilds.cache.size}`, `Users: ${client.guilds.cache
            .reduce((a, b) => a + b.memberCount, 0)
            .toLocaleString()}`, `Commands: ${client.commands.size}`);
        client.user.setStatus("idle")
        client.user.setActivity(`My Developer Eyad`, { type: ActivityType.Listening })
          client.guilds.cache.forEach(async (Guild) => {
    Guild.commands.set([
      {
        name: 'Warn',
        type: ApplicationCommandType.Message,
        default_member_permissions: PermissionFlagsBits.Administrator,
        dm_permission: false,
        
      }
    ])
  })
        
      
    }
};