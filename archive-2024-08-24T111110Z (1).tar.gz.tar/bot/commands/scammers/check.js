const { EmbedBuilder } = require('discord.js');
const scammers = require('../../Datebase/model/scammers.js');
module.exports = {
  name: 'فحص',
  description: 'Check a user\'s scammer status.',
  aliases: [],
    async execute(client, message, args) {
        try {
    const user = message.mentions.users.first() || message.guild.members.cache.get(args[0]);

    if (!user) {
      return message.reply('Please mention a user or provide a user ID.');
    }

    const scammer = await scammers.findOne({ guildID: message.guild.id, userID: user.id });

    if (!scammer) {
      const embed = new EmbedBuilder()
      .setColor('#000100')
      .setTitle('فحص الشخص')
      .setDescription(`**الايدي الذي ادخلته ليس موجود في قائمة النصابين**`)
        .setFooter({
        text: `ولكن إنتبه! هذا لا يعني انه مضمون`
        })
        .setThumbnail(message.guild.iconURL())
      .setTimestamp();
      message.reply({ embeds: [embed] });
    }

    const embed = new EmbedBuilder()
      .setTitle('Scammer Check')
      .addFields(
        {
          name: 'الحاله',
          value: `نصاب!`
        },
        { name: 'User ID', value: scammer.userID },
        { name: 'Reason', value: scammer.reason },
        { name: 'Time', value: `<t:${Math.floor(scammer.time / 1000)}:R>` },
      )
      .setThumbnail(message.guild.iconURL())
      .setColor('#FF0000');

    message.channel.send({ embeds: [embed] });
          } catch (err) {
            console.log(err);
        }
    },
};