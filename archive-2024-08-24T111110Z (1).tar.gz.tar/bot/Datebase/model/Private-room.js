const mongoose = require('mongoose');
const PrivateRoomSchema = new mongoose.Schema({
  guildId: {
    type: String,
    required: true,
  },
  channelId: {
    type: String,
    required: true,
  },
  ownerId: {
    type: String,
    required: true,
  },
  Privatecount: {
    type: Number,
    default: 0,
  },
  time: {
    type: Number,
    required: false,
  },
  createdAt: {
    type: Date,
    required: false,
    default: Date.now,
  },
  endAt: {
    type: Date,
    required: false,
  }
});
module.exports = mongoose.model('PrivateRoom', PrivateRoomSchema);