const Mongoose = require('mongoose');
const blacklist = new Mongoose.Schema({
    guildId: {
        type: String,
        required: true
    },
    userId: {
        type: String,
        required: true
    },
});
module.exports = Mongoose.model('blacklist', blacklist);
