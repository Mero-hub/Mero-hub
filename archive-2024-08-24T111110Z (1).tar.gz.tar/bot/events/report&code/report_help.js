const client = require("../../index.js");
const { EmbedBuilder, ApplicationCommandOptionType , Events , ActionRowBuilder , ButtonBuilder ,MessageAttachment, ButtonStyle , Message, TextInputStyle,TextInputBuilder,ModalBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, PermissionsBitField } = require("discord.js");
client.on('interactionCreate', async interaction => {
  if (!interaction.isButton()) return;
  if (interaction.customId === 'report_help') {
    if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) return interaction.reply({ content: `**هنهزر يسطا ولا ايه**`, ephemeral: true });
   const row = new StringSelectMenuBuilder()
    .setCustomId('report_help1')
    .setPlaceholder('برجاء التحديد')
    .addOptions(
      new StringSelectMenuOptionBuilder()
        .setLabel('اضافه شخص للتذكرة')
        .setValue('add_user'),
      new StringSelectMenuOptionBuilder()
        .setLabel('ازاله شخص من التذكرة')
        .setValue('remove_user'),
      new StringSelectMenuOptionBuilder()
        .setLabel('تغيير اسم التذكره')
        .setValue('change_name'),
      new StringSelectMenuOptionBuilder()
        .setLabel('اضافه رتبه لشخص')
        .setValue('add_role'),
    );
    const row1 = new ActionRowBuilder()
      .addComponents(row);
    interaction.reply({
      components: [row1],
      ephemeral: true
    });
  }
});
client.on('interactionCreate', async interaction => {
  if (!interaction.isStringSelectMenu()) return;
  if (interaction.customId === 'report_help1') {
    const selectedValue = interaction.values[0];
    if (selectedValue === 'add_user') {
      const modal = new ModalBuilder()
        .setCustomId('add_user_modal')
        .setTitle('اضافه شخص للتذكرة');
      const user_id = new TextInputBuilder()
        .setCustomId('user_id')
        .setLabel("ايدي الشخص")
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
        .setPlaceholder('حط ايدي الشخص');
      const row = new ActionRowBuilder().addComponents(user_id);
      modal.addComponents(row);
      await interaction.showModal(modal);
    } else if (selectedValue === 'remove_user') {
      const modal = new ModalBuilder()
        .setCustomId('remove_user_modal')
        .setTitle('ازاله شخص من التذكرة');
      const reovem_user_id = new TextInputBuilder()
        .setCustomId('remove_user_id')
        .setLabel("ايدي الشخص")
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
        .setPlaceholder('حط ايدي الشخص');
      const row = new ActionRowBuilder().addComponents(reovem_user_id);
      modal.addComponents(row);
      await interaction.showModal(modal);
    } else if (selectedValue === 'change_name') {
      const modal = new ModalBuilder()
        .setCustomId('change_name_modal')
        .setTitle('تغيير اسم التذكره');
      const name = new TextInputBuilder()
        .setCustomId('name')
        .setLabel("تغيير اسم التذكره")
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
        .setPlaceholder('حط اسم التذكرة');
      const row = new ActionRowBuilder().addComponents(name);
      modal.addComponents(row);
      await interaction.showModal(modal);
    } else if (selectedValue === 'add_role') {
      const modal = new ModalBuilder()
        .setCustomId('report_add_role_modal')
        .setTitle('اضافه رتبه لشخص');
      const user_id1 = new TextInputBuilder()
        .setCustomId("report_add_role_user_id")
        .setLabel("ايدي الشخص")
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
        .setPlaceholder('حط ايدي الشخص');
      const role_id = new TextInputBuilder()
        .setCustomId('report_role_id')
        .setLabel("ايدي الرتبه")
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
        .setPlaceholder('حط ايدي الرتبه');
      const row1 = new ActionRowBuilder().addComponents(user_id1)
      const row = new ActionRowBuilder().addComponents(role_id);
      modal.addComponents(row1, row);
      await interaction.showModal(modal);
    }
  }
});
client.on('interactionCreate', async interaction => {
  if (!interaction.isModalSubmit()) return;
  if (interaction.customId === 'add_user_modal') {
    const user_id = interaction.fields.getTextInputValue('user_id');
    const channel = interaction.channel;
    const member = interaction.guild.members.cache.get(user_id);
    if (!member) {
      return interaction.reply({
        content: 'الشخص غير موجود في السيرفر',
        ephemeral: true
      });
    }
  channel.permissionOverwrites.create(member, {
    ViewChannel: true,
    SendMessages: true
  });
  interaction.reply({
    content: `تم اضافه ${member} للتذكرة`,
    ephemeral: true
  });
  } else if (interaction.customId === 'remove_user_modal') {
    const remove_user_id = interaction.fields.getTextInputValue('remove_user_id');
    const channel = interaction.channel;
    const member = interaction.guild.members.cache.get(remove_user_id);
    if (!member) {
      return interaction.reply({
        content: 'الشخص غير موجود في السيرفر',
        ephemeral: true
      });
    }
    channel.permissionOverwrites.delete(member);
    interaction.reply({
      content: `تم ازاله ${member} من التذكرة`,
      ephemeral: true
    });
  } else if (interaction.customId === 'change_name_modal') {
    const name = interaction.fields.getTextInputValue('name');
    const channel = interaction.channel;
    channel.setName(name);
    interaction.reply({
      content: `تم تغيير اسم التذكره الى \`\`\`${name}\`\`\``,
      ephemeral: true
    });
  } else if (interaction.customId === 'report_add_role_modal') {
    const user_id = interaction.fields.getTextInputValue('report_add_role_user_id');
    const role_id = interaction.fields.getTextInputValue('report_role_id');
    const channel = interaction.channel;
    const member = interaction.guild.members.cache.get(user_id);
    const role = interaction.guild.roles.cache.get(role_id);
    if (!member) {
      return interaction.reply({
        content: 'الشخص غير موجود في السيرفر',
        ephemeral: true
      });
    }
    member.roles.add(role);
    await interaction.reply({
      content: `تم اضافه ${role} لـ ${member}`,
      ephemeral: true
    })
  }
});