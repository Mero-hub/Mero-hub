const client = require("../../index.js");
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js')
const config = require('../../config.json')
const claim = require('../../Datebase/model/claim.js')
const points = require('../../Datebase/model/points.js')

client.on('interactionCreate', async (interaction) => {
  if (!interaction.isButton()) return;
  if (interaction.customId === 'auction_claim') {
    if (!interaction.member.roles.cache.has("1145673209870561281")) return interaction.reply({ content: `You`, ephemeral: true })
    const embed = new EmbedBuilder()
      .setDescription(`** تم استلام تذكره ${interaction.channel}  من قبل ${interaction.user}**`)
      .setColor('#000100')
      .setTimestamp();
    await interaction.reply({ embeds: [embed] });

          const row = new ActionRowBuilder()
          .addComponents(
            new ButtonBuilder()
              .setCustomId('auction_buy')
              .setLabel('شراء مزاد')
              .setStyle(ButtonStyle.Secondary),
            new ButtonBuilder()
            .setCustomId('auction_un_claim')
              .setLabel('الغاء الاستلام')
            .setStyle(ButtonStyle.Secondary),
            new ButtonBuilder()
              .setCustomId("auction_help")
              .setLabel("مساعده طاقم المزاد")
              .setStyle(ButtonStyle.Secondary),
            new ButtonBuilder()
              .setCustomId("auction_delete_ticket")
              .setLabel("حذف التذكره")
              .setStyle(ButtonStyle.Danger)
          );
            
      
    await interaction.message.edit({ components: [row] });

interaction.channel.setName(`claimed-${interaction.user.username}`)

    interaction.channel.permissionOverwrites.edit(interaction.user.id, {
      SendMessages: true,
      ViewChannel: true,
      ReadMessageHistory: true,
    });
  interaction.channel.permissionOverwrites.edit("1145673209870561281", {
      SendMessages: false,
      ViewChannel: false,
      ReadMessageHistory: false,
  });

const newData = await claim.create({
userId: interaction.user.id,
channelId: interaction.channel.id
});
await newData.save();

    const point = await points.updateOne(
      { guildId: interaction.guild.id, userId: interaction.user.id },
      { $inc: { points: 1 } },
      { upsert: true }
    );
const log = client.channels.cache.get(config.log)
if (point) {
  const embed = new EmbedBuilder()
    .addFields(
      {
        name: "تم اضافة نقطه الى",
        value: `${interaction.user}`
      },
      {
        name: "بسبب استلام تذكره",
        value: `${interaction.channel}`
      }
    )
    .setColor('#000100')
    .setTimestamp();
  await log.send({ embeds: [embed] });
}

  } else if (interaction.customId === 'auction_un_claim') {
    const unclaim = await claim.findOne({ userId: interaction.user.id,
channelId: interaction.channel.id })
if (!unclaim) return interaction.reply({ content: `You don't have permission to use this button.`, ephemeral: true });
const embed = new EmbedBuilder()
      .setDescription(
        `** تم الغاء استلام التذكره ${interaction.channel} من قبل ${interaction.user}**`)
      .setColor('#000100')
      .setTimestamp();
    await interaction.reply({ embeds: [embed] });
    const row = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('auction_buy')
        .setLabel('شراء مزاد')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId("auction_claim")
        .setLabel("استلام التذكره")
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId("auction_help")
        .setLabel("مساعده طاقم المزاد")
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId("auction_delete_ticket")
        .setLabel("حذف التذكره")
        .setStyle(ButtonStyle.Danger)
    );
    await interaction.message.edit({ components: [row] });
interaction.channel.setName(`ticket-${interaction.user.username}`)

interaction.channel.permissionOverwrites.edit("1145673209870561281", {
      SendMessages: true,
      ViewChannel: true,
      ReadMessageHistory: true,
  });
    const pointt = await points.updateOne(
      { guildId: interaction.guild.id, userId: interaction.user.id },
      { $inc: { points: -1 } },
      { upsert: true }
    );
  const log = client.channels.cache.get(config.log)
if (pointt) {
  const embed = new EmbedBuilder()
    .addFields(
      {
        name: "تم ازاله نقطه من",
        value: `${interaction.user}`
      },
      {
        name: "بسبب الغاء استلام تذكره",
        value: `${interaction.channel}`
      }
    )
    .setColor('#000100')
    .setTimestamp();
  await log.send({ embeds: [embed] });
}

  } else if (interaction.customId === 'auction_delete_ticket') {
   const embed = new EmbedBuilder()
      .setDescription(`** سوف يتم حذف التذكره بعد 5 ثواني**`)
      .setColor('#000100')
      .setTimestamp();
    await interaction.reply({ embeds: [embed] });
    setTimeout(async () => {
interaction.channel.delete() 
}, 5000)
  }
});