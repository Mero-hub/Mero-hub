const client = require("../../index.js");
const { EmbedBuilder, ActionRowBuilder , ButtonBuilder , ButtonStyle, TextInputStyle,TextInputBuilder,ModalBuilder } = require("discord.js");

/////////////test///////////////
client.on("interactionCreate", async (interaction) => {
  if (!interaction.isButton()) return;
  if (interaction.customId === "first-test-mad") {
    const modal = new ModalBuilder()
      .setCustomId("1-mad")
      .setTitle("الاختبار الاول");
    const one = new TextInputBuilder()
      .setCustomId("1-mad")
      .setLabel("لو حد عايز يشيل رتبه نصاب؟")
      .setPlaceholder("اكتب إجابتك هنا")
      .setStyle(TextInputStyle.Short);
    
    const two = new TextInputBuilder()
      .setCustomId("2-mad")
      .setLabel("شخص فتح تكت وقال في نصاب نصبني؟")
      .setPlaceholder("اكتب إجابتك هنا")
      .setStyle(TextInputStyle.Short);
    const three = new TextInputBuilder()
      .setCustomId("3-mad")
      .setLabel("اذا جاء عضو خاصك و قال في نصاب نصبني؟")
      .setPlaceholder("اكتب إجابتك هنا")
      .setStyle(TextInputStyle.Short);
    const four = new TextInputBuilder()
      .setCustomId("4-mad")
      .setLabel("لو شخص سالك كيف اقدم علي قاضي ؟")
      .setPlaceholder("اكتب إجابتك هنا")
      .setStyle(TextInputStyle.Short);
    const five = new TextInputBuilder()
      .setCustomId("5-mad")
      .setLabel("شخص عايز اداره عليا؟")
      .setPlaceholder("اكتب إجابتك هنا")
      .setStyle(TextInputStyle.Short);
    const row1 = new ActionRowBuilder().addComponents(one)
    const row2 = new ActionRowBuilder().addComponents(two)
    const row3 = new ActionRowBuilder().addComponents(three)
    const row4 = new ActionRowBuilder().addComponents(four)
    const row5 = new ActionRowBuilder().addComponents(five)
    modal.addComponents(row1, row2, row3, row4, row5);
    await interaction.showModal(modal);
  } else if (interaction.customId === "second-test-mad") {
    const modal = new ModalBuilder()
      .setCustomId("2-mad")
      .setTitle("الاختبار الثاني");
    const one = new TextInputBuilder()
      .setCustomId("1-two-mad")
      .setLabel("لو عضو عايز يشتري اعلان؟")
      .setPlaceholder("اكتب إجابتك هنا")
      .setStyle(TextInputStyle.Short);
    const two = new TextInputBuilder()
      .setCustomId("2-two-mad")
      .setLabel("طريقه تغير اسم التكت؟")
      .setPlaceholder("اكتب إجابتك هنا")
      .setStyle(TextInputStyle.Short);
    const three = new TextInputBuilder()
      .setCustomId("3-two-mad")
      .setLabel("شكوه علي اداري؟")
      .setPlaceholder("اكتب إجابتك هنا")
      .setStyle(TextInputStyle.Short);
    const four = new TextInputBuilder()
      .setCustomId("4-two-mad")
      .setLabel("اشرح طريقه اضافه رتبه لعضو؟")
      .setPlaceholder("اكتب إجابتك هنا")
      .setStyle(TextInputStyle.Short);
    const five = new TextInputBuilder()
      .setCustomId("5-two-mad")
      .setLabel("شخص عايز يقدم علي وسيط")
      .setPlaceholder("اكتب إجابتك هنا")
      .setStyle(TextInputStyle.Short);
    const row1 = new ActionRowBuilder().addComponents(one)
    const row2 = new ActionRowBuilder().addComponents(two)
    const row3 = new ActionRowBuilder().addComponents(three)
    const row4 = new ActionRowBuilder().addComponents(four)
    const row5 = new ActionRowBuilder().addComponents(five)
    modal.addComponents(row1, row2, row3, row4, row5);
    await interaction.showModal(modal);
  } else if (interaction.customId === "third-test-mad") {
    const modal = new ModalBuilder()
      .setCustomId("3-mad")
      .setTitle("الاختبار الثالث");
    const one = new TextInputBuilder()
      .setCustomId("1-three-mad")
      .setLabel("اشرح طريقه اضافه عضو للتذكرة")
      .setPlaceholder("اكتب إجابتك هنا")
      .setStyle(TextInputStyle.Short);
    const two = new TextInputBuilder()
      .setCustomId("2-three-mad")
      .setLabel("شخص عايز يشتري رتبه؟")
      .setPlaceholder("اكتب إجابتك هنا")
      .setStyle(TextInputStyle.Short);
    const three = new TextInputBuilder()
      .setCustomId("3-three-mad")
      .setLabel("شخص قالك ابي اونر؟")
      .setPlaceholder("اكتب إجابتك هنا")
      .setStyle(TextInputStyle.Short);
    const row1 = new ActionRowBuilder().addComponents(one)
    const row2 = new ActionRowBuilder().addComponents(two)
    const row3 = new ActionRowBuilder().addComponents(three)
    modal.addComponents(row1, row2, row3);
    await interaction.showModal(modal);
  }
});
client.on("interactionCreate", async (interaction) => {
  if (!interaction.isModalSubmit()) return;
  if (interaction.customId === "1-mad") {
    const one = interaction.fields.getTextInputValue("1-mad");
    const two = interaction.fields.getTextInputValue("2-mad");
    const three = interaction.fields.getTextInputValue("3-mad");
    const four = interaction.fields.getTextInputValue("4-mad");
    const five = interaction.fields.getTextInputValue("5-mad");
    const channel = interaction.guild.channels.cache.get("1255860582309953648");
    const embed = new EmbedBuilder()
      .setTitle("الاختبار الاول")
      .setDescription("اجابتك علي الاسئله")
      .addFields(
        { name: "1-", value: `${one}` },
        { name: "2-", value: `${two}` },
        { name: "3-", value: `${three}` },
        { name: "4-", value: `${four}` },
        { name: "5-", value: `${five}` },
      )
      .setTimestamp();
    await channel.send({ 
    content: `** المختبر: ${interaction.user}**`,
    embeds: [embed] });
    await interaction.reply({ content: `**يرجي بدا الاختبار التاني**`, ephemeral: true });
        const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId("first-test-sup")
          .setLabel("الاختبار الاول")
        .setDisabled(true)
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId("second-test-mad")
          .setLabel("الاختبار الثاني")
        
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId("hh")
          .setLabel("الاختبار الثالث")
        .setDisabled(true)
          .setStyle(ButtonStyle.Secondary),
      );
interaction.message.edit({ components: [row] });
  } else if (interaction.customId === "2-mad") {
    const one = interaction.fields.getTextInputValue("1-two-mad");
    const two = interaction.fields.getTextInputValue("2-two-mad");
    const three = interaction.fields.getTextInputValue("3-two-mad");
    const four = interaction.fields.getTextInputValue("4-two-mad");
    const five = interaction.fields.getTextInputValue("5-two-mad");
    const channel = interaction.guild.channels.cache.get("1226483099718909994");
    const embed = new EmbedBuilder()
      .setTitle("الاختبار الثاني")
      .setDescription("اجابتك علي الاسئله")
      .addFields(
        { name: "1-", value: `${one}` },
        { name: "2-", value: `${two}` },
        { name: "3-", value: `${three}` },
        { name: "4-", value: `${four}` },
        { name: "5-", value: `${five}` },
      )
      .setTimestamp();
    await channel.send({
    content: `** المختبر: ${interaction.user}**`,
    embeds: [embed]
    });
    await interaction.reply({ content: `**يرجي بدا الاختبار الثالث**`, ephemeral: true });
                const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId("first-test-sup")
          .setLabel("الاختبار الاول")
        .setDisabled(true)
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId("second-test-sup")
          .setLabel("الاختبار الثاني")
        .setDisabled(true)
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId("third-test-mad")
          .setLabel("الاختبار الثالث")
        
          .setStyle(ButtonStyle.Secondary),
      );
interaction.message.edit({ components: [row] });
  } else if (interaction.customId === "3-mad") {
    const one = interaction.fields.getTextInputValue("1-three-mad");
    const two = interaction.fields.getTextInputValue("2-three-mad");
    const three = interaction.fields.getTextInputValue("3-three-mad");
    const channel = interaction.guild.channels.cache.get("1255860582309953648");
    const embed = new EmbedBuilder()
      .setTitle("الاختبار الثالث")
      .setDescription("اجابتك علي الاسئله")
      .addFields(
        { name: "1-", value: `${one}` },
        { name: "2-", value: `${two}` },
        { name: "3-", value: `${three}` },
      )
      .setTimestamp();
    await channel.send({
    content: `** المختبر: ${interaction.user}**`,
    embeds: [embed]
    });
    await interaction.reply({ content: `**تم انهاء الاختبار بنجاح**`, ephemeral: true });

const start = new EmbedBuilder()
    .setTitle("تم انهاء الاختبار بنجاح")
    .setDescription("تم ارسال جميع البيانات يرجي انتظر الرد من مسوول")
            const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId("first-test-sup")
          .setLabel("الاختبار الاول")
        .setDisabled(true)
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId("second-test-sup")
          .setLabel("الاختبار الثاني")
        .setDisabled(true)
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId("third-test-sup")
          .setLabel("الاختبار الثالث")
        .setDisabled(true)
          .setStyle(ButtonStyle.Secondary),
      );
interaction.message.edit({ 
  embeds: [start],
  components: [row] });
  }
});