const client = require("../../index.js");
const config = require("../../config.json");
const { EmbedBuilder, ApplicationCommandOptionType , Events , ActionRowBuilder , ButtonBuilder ,MessageAttachment, ButtonStyle , Message, TextInputStyle,TextInputBuilder,ModalBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, PermissionsBitField } = require("discord.js");

const users = require('../../Datebase/model/buy.js');

client.on('interactionCreate', async interaction => {
  if (!interaction.isStringSelectMenu()) return;
  if (interaction.customId === 'buy') {
  const selectedValue = interaction.values[0];
  if (selectedValue === 'warn') {
    const warn25 = config.rolewarn25;
    const warn50 = config.rolewarn50;
  const hasrole = interaction.member.roles.cache.some(role => role.id === warn25 || role.id === warn50);
    if (hasrole) {
      const dlwarm = new StringSelectMenuBuilder()
      .setCustomId('dlwarn')
      .setPlaceholder('اختر التحذير التي تريد ازالتها')
      .addOptions(
        new StringSelectMenuOptionBuilder()
          .setLabel('warn25%')
          .setValue('warn25'),
        new StringSelectMenuOptionBuilder()
          .setLabel('warn50%')
          .setValue('warn50')
      );
      const row = new ActionRowBuilder()
        .addComponents(dlwarm);
      const embed = new EmbedBuilder()
        .setColor('#000100')
        .setDescription(
          `**اختر التحذير الذي تريد ازالته**`)
      .setTimestamp()
    .setFooter({
      text: interaction.guild.name,
        iconURL: interaction.guild.iconURL()
    })
    .setAuthor({
      name: interaction.guild.name,
        iconURL: interaction.guild.iconURL()
    });
      await interaction.update({
        embeds: [embed],
        components: [row],
      })
        
    } else {
      const non = new EmbedBuilder()
        .setColor('#000100')
        .setDescription(`لا يوجد لديك تحذيرات لإزالتها`)
      interaction.update({
      embeds: [non],
      components: [],
      })
    }
  }
  }
});
client.on('interactionCreate', async interaction => {
  if (!interaction.isStringSelectMenu()) return;
  if (interaction.customId === 'dlwarn') {
  const selectedValue = interaction.values[0];
  if (selectedValue === 'warn25') {
    const warn25 = config.rolewarn25;
    let price = config.price_warn;
    let result = price;
    let tax = Math.floor(price * (20 / 19) + 1);
    let owner = config.owner;
    const embed = new EmbedBuilder()
      .setColor('#000100')
      .setDescription(`**قم بتحويل مبلغ \`${tax}\` لـ <@${owner}>**\n\n**C ${owner} ${tax}**`)
      .setTimestamp();
    await interaction.update({
      embeds: [embed],
      components: [],
    })
    await interaction.channel.send({
      content: `#credit ${owner} ${tax}`
    })
  const filter = ({ content, author: { id } }) => {
        return (
            content.startsWith(`**:moneybag: | ${interaction.user.username}, has transferred `) &&
            content.includes(`${owner}`) &&
            id === "282859044593598464" &&
            (Number(content.slice(content.lastIndexOf("`") - String(tax).length, content.lastIndexOf("`"))) >= result)
        );
    };

    const collector = interaction.channel.createMessageCollector({ 
      filter,               
      max: 1,
      time: 60000,
    });
let iscollected = false;
collector.on('collect', async (collected) => {
  iscollected = true;
  const embed = new EmbedBuilder()
    .setColor('#000100') 
    .setDescription(`**تم ازالة التحذير بنجاح**`)
  await interaction.editReply({
    embeds: [embed],
    components: [],
  })
  const role = interaction.guild.roles.cache.get(warn25);
  const member = interaction.guild.members.cache.get(interaction.user.id);
  member.roles.remove(role);
  
const user = await users.deleteOne({ userId: interaction.user.id });


const log = client.channels.cache.get(config.wrn)
const logembed = new EmbedBuilder()
.setColor('#000100')
.setDescription(`**تم ازالة تحذير للعضو : <@${interaction.user.id}>` + `\n\nالتحذير الذي تم ازالته : warn25%` + `\n\nالمبلغ المدفوع : ${price}` + `\n\nالمبلغ المستحق : ${result}` + `\n\nالمبلغ المستحق بعد الضريبة : ${tax}`);
log.send({
  embeds: [logembed]
})
   });
collector.on('end', async (collected) => {
  if (!iscollected) {
    const embed = new EmbedBuilder()
      .setColor('#000100')
      .setDescription(`**انتهى الوقت للتحويل**`);
    await interaction.editReply({
      embeds: [embed],
      components: [],
    })
    const user = await users.deleteOne({ userId: interaction.user.id });
  }
});
  
    } else if (selectedValue === 'warn50') {
    const warn50 = config.rolewarn50;
    let price = config.pr_wrn;
    let result = price;
    let tax = Math.floor(price * (20 / 19) + 1);
    let owner = config.owner;
    const embed = new EmbedBuilder()
      .setColor('#000100')
      .setDescription(`**قم بتحويل مبلغ \`${tax}\` لـ <@${owner}>**\n\n**C ${owner} ${tax}**`)
      .setTimestamp();
    await interaction.update({
      embeds: [embed],
      components: [],
    })
    await interaction.channel.send({
      content: `#credit ${owner} ${tax}`
    })
  const filter = ({ content, author: { id } }) => {
        return (
            content.startsWith(`**:moneybag: | ${interaction.user.username}, has transferred `) &&
            content.includes(`${owner}`) &&
            id === "282859044593598464" &&
            (Number(content.slice(content.lastIndexOf("`") - String(tax).length, content.lastIndexOf("`"))) >= result)
        );
  
  };
  const collector = interaction.channel.createMessageCollector({
    filter,               
    max: 1,
    time: 60000,
  })
  let iscollected = false;
  collector.on('collect', async (collected) => {
    iscollected = true;
    const embed = new EmbedBuilder()
      .setColor('#000100') 
      .setDescription(`**تم ازالة التحذير بنجاح**`)
    await interaction.editReply({
      embeds: [embed],
      components: [],
    })
    const role = interaction.guild.roles.cache.get(warn50);
    const member = interaction.guild.members.cache.get(interaction.user.id);
    member.roles.remove(role);

    const user = await users.deleteOne({ userId: interaction.user.id });

const log = client.channels.cache.get(config.wrn)
const logembed = new EmbedBuilder()
.setColor('#000100')
.setDescription(`**تم ازالة تحذير للعضو : <@${interaction.user.id}>` + `\n\nالتحذير الذي تم ازالته : warn25%` + `\n\nالمبلغ المدفوع : ${price}` + `\n\nالمبلغ المستحق : ${result}` + `\n\nالمبلغ المستحق بعد الضريبة : ${tax}`);
log.send({
  embeds: [logembed]
})
  });
  collector.on('end', async (collected) => {
    if (!iscollected) {
      const embed = new EmbedBuilder()
        .setColor('#000100')
        .setDescription(`**انتهى الوقت للتحويل**`);
      await interaction.editReply({
        embeds: [embed],
        components: [],
      })
      const user = await users.deleteOne({ userId: interaction.user.id });
    }
  });
    }
  }
});