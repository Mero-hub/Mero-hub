const { EmbedBuilder, ButtonStyle, ButtonBuilder, ActionRowBuilder } = require("discord.js");
module.exports = {
  name: "warn_panel",
    aliases: [],
       owners: true,
       async execute(client, message, args) {
        try{
    
    const embed = new EmbedBuilder()
      .setTitle("Warn Panel")
      .setDescription(`> **To warn a member, click on the button below.**`)
      .setAuthor({
        name: message.guild.name,
        iconURL: message.guild.iconURL()
      })
      .setFooter({
        text: message.guild.name,
        iconURL: message.guild.iconURL()
      })
      .setThumbnail(message.guild.iconURL())
      .setTimestamp();
    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('warn_member')
          .setLabel('Warn')
          .setStyle(ButtonStyle.Danger)
      );
      message.channel.send({ embeds: [embed], components: [row] });
          } catch (error) {
            console.error(error);
            message.reply('There was an error while executing this command!');
          }
  },
};