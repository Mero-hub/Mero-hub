const client = require("../../index.js");
const db = require("pro.db");
const { EmbedBuilder, ApplicationCommandOptionType , Events , ActionRowBuilder , ButtonBuilder ,MessageAttachment, ButtonStyle , Message, TextInputStyle,TextInputBuilder,ModalBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, PermissionsBitField } = require("discord.js");
const users = require('../../Datebase/model/buy.js');
client.on('interactionCreate', async interaction => {
  if (!interaction.isButton()) return;
  if (interaction.customId === 'buy') {

    const user = await users.findOne({ userId: interaction.user.id, buy: true });

if (user && user.buy === true) {
    return interaction.reply({ content: `**لديك عملية شراء بالفعل**`, ephemeral: true });
}

if (!user) {
    await users.create({ userId: interaction.user.id, buy: true });
} else {
    user.buy = true;
    await user.save();
} 

    const buy = new StringSelectMenuBuilder()
    .setCustomId('buy')
    .setPlaceholder('اختر نوع الشي')
    .addOptions(
      new StringSelectMenuOptionBuilder()
        .setLabel('شراء رتبه')
        .setValue('role'),
      new StringSelectMenuOptionBuilder()
        .setLabel('ازاله تحذيرات')
        .setValue('warn'),
      new StringSelectMenuOptionBuilder()
        .setLabel('شراء منشورات مميزة')
        .setValue('manshort'),
      new StringSelectMenuOptionBuilder()
        .setLabel('شراء روم خاص')
        .setValue('room'),
      new StringSelectMenuOptionBuilder()
        .setLabel('شراء اعلان')
        .setValue('ads'),
    );
    const row = new ActionRowBuilder()
      .addComponents(buy);
    const embed = new EmbedBuilder()
      .setColor('#000100')
      .setDescription(`**
      <:emoji_50:1270042822434885824>   __يمكنك الاختيار من المنيو الموجودة بالاسفل__

لشراء رتبة » لكي تستطيع النشر برومات البيع <:emoji_50:1270042822434885824> 

إزاله تحذيرات » اذا عندك تحذيرات تقدر تشيلها <:emoji_50:1270042822434885824>

منشور مميز » لأنشاء طلب خاص بك في روم منشورات مميزه <:emoji_50:1270042822434885824>

روم خاصه » لشراء روم خاصه بك لنشر سلعتك <:emoji_50:1270042822434885824>

إعلان » لشراء إعلان لسيرفرك <:emoji_50:1270042822434885824>**`);
    await interaction.reply({
      embeds: [embed],
      components: [row],
    });
    }
  });