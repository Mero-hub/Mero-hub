const { EmbedBuilder, ApplicationCommandOptionType , Events , ActionRowBuilder , ButtonBuilder ,MessageAttachment, ButtonStyle , Message, TextInputStyle,TextInputBuilder,ModalBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, PermissionsBitField } = require("discord.js");

module.exports = {
    name: "rules",
    aliases: [],
     owners: true,
    async execute(client, message, args) {
        try{
                    const embed = new EmbedBuilder()
          .setColor('#000100')
          .setTitle('**القوانين**')
          .setDescription(`**لرؤية قوانين السيرفر اختار قوانين السيرفر
  لرؤية قوانين البائعين اختار قوانين البائعين
  لرؤية قوانين الادارة اختار قونين الادارة
  لرؤية قوانين القضاة اختار قوانين القضاة
  لرؤية قوانين الوسطاء اختار قوانين الوسطاء**`)
            .setImage("https://media.discordapp.net/attachments/1249856158458708100/1270404847023427584/4824a5b83e5c4025.png?ex=66b39436&is=66b242b6&hm=3f4e79020690d48a98538c7939a9e06c2d9c05e014b4845f9975777f0bb682dc&")
          .setAuthor({
            name: message.guild.name 
          })
            .setTimestamp();
          const rules = new StringSelectMenuBuilder()
          .setCustomId('rules')
          .setPlaceholder('اختار هنا')
        .addOptions(
          new StringSelectMenuOptionBuilder()
          .setLabel('قوانين السيرفر')
          .setValue('rules_server'),
          new StringSelectMenuOptionBuilder()
          .setLabel('قوانين البائعين')
          .setValue('rules_seller'),
          new StringSelectMenuOptionBuilder()
          .setLabel('قوانين الادارة')
          .setValue('rules_admin'),
          new StringSelectMenuOptionBuilder()
          .setLabel('قوانين القضاة')
          .setValue('rules_law'),
          new StringSelectMenuOptionBuilder()
          .setLabel('قوانين الوسطاء')
          .setValue('rules_staff')
        );
          const row = new ActionRowBuilder()
          .addComponents(rules);
          message.channel.send({ embeds: [embed], components: [row] });
     } catch (error) {
            console.error(error);
            message.reply('There was an error while executing this command!');
     }
  },
};