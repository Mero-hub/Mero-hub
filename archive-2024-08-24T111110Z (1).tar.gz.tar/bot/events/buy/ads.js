const client = require("../../index.js");
const { EmbedBuilder, ApplicationCommandOptionType , Events , ActionRowBuilder , ButtonBuilder ,MessageAttachment, ButtonStyle , Message, TextInputStyle,TextInputBuilder,ModalBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, PermissionsBitField } = require("discord.js");
const users = require('../../Datebase/model/buy.js');
const config = require("../../config.json");

client.on('interactionCreate', async interaction => {
 if (!interaction.isStringSelectMenu()) return;
 if (interaction.customId === 'buy') {
 const selectedValue = interaction.values[0];
 if (selectedValue === 'ads') {
 const mention = new StringSelectMenuBuilder()
 .setCustomId('mention-ads')
 .setPlaceholder('اختر نوع المنشن')
 .addOptions(
 new StringSelectMenuOptionBuilder()
 .setLabel('بدون منشن')
 .setValue('non-ads'),
 new StringSelectMenuOptionBuilder()
 .setLabel('منشن هير')
 .setValue('here-ads'),
 new StringSelectMenuOptionBuilder()
 .setLabel('منشن ايفري')
 .setValue('everyone-ads'),
new StringSelectMenuOptionBuilder()
.setLabel('روم هدايا الاعلانات')
.setValue('inroomgivaway-ads'),
new StringSelectMenuOptionBuilder()
.setLabel('روم خاص بدون قيف اواي')
.setValue('private-ads'),
new StringSelectMenuOptionBuilder()
.setLabel('روم خاص بقيف اواي')
.setValue('private-giveaway-ads'),
 );
 const row = new ActionRowBuilder()
 .addComponents(mention);
   
 const embed = new EmbedBuilder()
 .setColor('#000100')
 .setDescription(`**
<:emoji_37:1261219316804882514>  No Mention | بدون منشن 
<:emoji_49:1270025870308016169>  100,000
  
 <:emoji_37:1261219316804882514> Here | منشن هير
<:emoji_49:1270025870308016169>  150,000
  
 <:emoji_37:1261219316804882514>  Everyone | منشن للكل
<:emoji_49:1270025870308016169> 200,000
  
 <:emoji_37:1261219316804882514>  Ads Gifts | هدايا الاعلانات 
<:emoji_49:1270025870308016169>  300,000
  
<:emoji_37:1261219316804882514>  Private Channel Without Giveaway | روم خاص بدون قيف اواي
<:emoji_49:1270025870308016169> 500,000  
  
<:emoji_37:1261219316804882514>  Private Channel With Giveaway | روم خاص مع قيف اواي
<:emoji_49:1270025870308016169>  800,000
  
<:emoji_50:1270042822434885824>  ملاحظات :  
  
في حال نشر اشياء 18+ سيتم مسح اعلانك <:emoji_50:1270042822434885824> 
اعلانات الرومات الخاصة لمدة ثلاث ايام طبعاً تقدر تمدد المدة كل يوم = 150k و مع منشن افري ون <:emoji_50:1270042822434885824> 
يسموح نعمل  reroll في حال لم يطبق الشروط كل الفائزين مرة واحدة فقط لا غير <:emoji_50:1270042822434885824>
لا يوجد ضمان دخول اعضاء <:emoji_50:1270042822434885824> 
في حال وصلنا ان ادارة السيرفر أو اصحاب السيرفر نصابين مع الدلائل بيتم مسح الإعلان بدون تعويض <:emoji_50:1270042822434885824> 
يرجى انتظار اداري لان اذا حصل خطأ او كان سيرفرك مخالف أو شي ما رح يتم تعويضك <:emoji_50:1270042822434885824> 
يسموح تعديل الاعلان بعد شرائه بعد مدة قصيرة من شرائه في حال مرة مدة طويلة غير مسموح تعدل <:emoji_50:1270042822434885824>
اي اعلان بخص الكريدت ممنوع | بيع او شراء <:emoji_50:1270042822434885824> 
 
ممنوع اي اعلان يكون فيه رابط اضافة بوت ممنوع بدك بعد ما يدخل الأعضاء عطهم الرابط<:emoji_50:1270042822434885824>
  
 **`)
    .setTimestamp()
    .setFooter({
      text: interaction.guild.name,
        iconURL: interaction.guild.iconURL()
    })
    .setAuthor({
      name: interaction.guild.name,
        iconURL: interaction.guild.iconURL()
    });
 await interaction.update({
 embeds: [embed],
 components: [row],
 });

   
 }
 } else if (interaction.customId === 'mention-ads') {
  const selectedValue = interaction.values[0];
  if (selectedValue === 'non-ads') {
         let price = config.price_non_ads;
     let result = price;
     
     let tax = Math.floor(price * (20 / 19) + 1);
     let owner = config.owner;
    const embed = new EmbedBuilder()
      .setColor("#000100")
      .setTitle("**عمليه شراء اعلان بدون منشن**")
      .setDescription(`**لأكمال عملية شراء اعلان بدون منشن , يرجي نسخ الكود بالاسفل واتمام عملية التحويل

 \`\`\`#credit ${owner} ${tax}\`\`\`**`)
    .setAuthor({
             name: interaction.guild.name,
             iconURL: interaction.guild.iconURL()})
             .setFooter({
             text: interaction.guild.name,
               iconURL: interaction.guild.iconURL()
             })

             .setThumbnail(interaction.guild.iconURL())

         .setTimestamp();
     await interaction.update({
       embeds: [embed],
       components: [],
     })
    await interaction.channel.send({
  content: `#credit ${owner} ${tax}`
  })
    const filter = ({ content, author: { id } }) => {
    return (
        content.startsWith(`**:moneybag: | ${interaction.user.username}, has transferred `) &&
        content.includes(`${owner}`) &&
        id === "282859044593598464" &&
        (Number(content.slice(content.lastIndexOf("`") - String(tax).length, content.lastIndexOf("`"))) >= result)
    );
  };
    const collector = interaction.channel.createMessageCollector({ 
  filter,               
  max: 1,
  time: 60000,
  });
  let iscollected = false;
  collector.on('collect', async (collected) => {
  iscollected = true;
  const embed = new EmbedBuilder()
  .setColor('#000100')
  .setTitle(
  `تمت عملية الشراء بنجاح`)
  .setDescription(
  `**تم شراء المنشور المميز بنجاح**`)
  .setAuthor({
             name: interaction.guild.name,
             iconURL: interaction.guild.iconURL()})
             .setFooter({
             text: interaction.guild.name,
               iconURL: interaction.guild.iconURL()
             })

             .setThumbnail(interaction.guild.iconURL())

         .setTimestamp();
      const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('done-buyads-non')
          .setLabel('قم بوضع اعلانك هنا')
          .setStyle(ButtonStyle.Success)
      );
      await interaction.editReply({
  embeds: [embed],
  components: [row],
  });
const user = await users.deleteOne({ userId: interaction.user.id });
    
});
    
collector.on('end', async (collected) => {
  if (!iscollected) {
  const embed = new EmbedBuilder()
  .setColor('#000100')
  .setTitle(
  `انتهى وقت العمليه`)
  .setDescription(
  `**انتهى وقت العمليه**`)
    .setAuthor({
         name: interaction.guild.name,
         iconURL: interaction.guild.iconURL()})
         .setFooter({
         text: interaction.guild.name,
           iconURL: interaction.guild.iconURL()
         })

         .setThumbnail(interaction.guild.iconURL())

     .setTimestamp();
  await interaction.editReply({
  embeds: [embed],
  components: [],
  });
  const user = await users.deleteOne({ userId: interaction.user.id });
  }
});
    
    } else if (selectedValue === 'here-ads') {
         let price = config.price_here_ads;
     let result = price;
     
     let tax = Math.floor(price * (20 / 19) + 1);
     let owner = config.owner;
    const embed = new EmbedBuilder()
      .setColor("#000100")
      .setTitle(
      `**عمليه شراء اعلان منشن هير**`)
      .setDescription(
      `**لأكمال عملية شراء اعلان منشن هير , يرجي نسخ الكود بالاسفل واتمام عملية التحويل **`)
        .setAuthor({
             name: interaction.guild.name,
             iconURL: interaction.guild.iconURL()})
             .setFooter({
             text: interaction.guild.name,
               iconURL: interaction.guild.iconURL()
             })

             .setThumbnail(interaction.guild.iconURL())

         .setTimestamp();
     await interaction.update({
       embeds: [embed],
       components: [],
     })
    await interaction.channel.send({
  content: `#credit ${owner} ${tax}`
  })
    const filter = ({ content, author: { id } }) => {
    return (
        content.startsWith(`**:moneybag: | ${interaction.user.username}, has transferred `) &&
        content.includes(`${owner}`) &&
        id === "282859044593598464" &&
        (Number(content.slice(content.lastIndexOf("`") - String(tax).length, content.lastIndexOf("`"))) >= result)
    );
  };
    const collector = interaction.channel.createMessageCollector({ 
  filter,               
  max: 1,
  time: 60000,
  });
  let iscollected = false;
  collector.on('collect', async (collected) => {
  iscollected = true;
    const embed = new EmbedBuilder()
  .setColor('#000100')
  .setTitle(
  `تمت عملية الشراء بنجاح`)
  .setDescription(
  `**تم شراء اعلان منشن هير بنجاح**`)
  .setAuthor({
             name: interaction.guild.name,
             iconURL: interaction.guild.iconURL()})
             .setFooter({
             text: interaction.guild.name,
               iconURL: interaction.guild.iconURL()
             })

             .setThumbnail(interaction.guild.iconURL())

         .setTimestamp();
      const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('done-buyads-here')
          .setLabel('قم بوضع اعلانك هنا')
          .setStyle(ButtonStyle.Success)
      );
      await interaction.editReply({
  embeds: [embed],
  components: [row],
  });
    const user = await users.deleteOne({ userId: interaction.user.id });
    
});
  collector.on('end', async (collected) => {
  if (!iscollected) {
  const embed = new EmbedBuilder()
  .setColor('#000100')
  .setTitle(
  `انتهى وقت العمليه`)
  .setDescription(
  `**انتهى وقت العمليه**`)
    .setAuthor({
         name: interaction.guild.name,
         iconURL: interaction.guild.iconURL()})
         .setFooter({
         text: interaction.guild.name,
           iconURL: interaction.guild.iconURL()
         })

         .setThumbnail(interaction.guild.iconURL())

     .setTimestamp();
  await interaction.editReply({
  embeds: [embed],
  components: [],
  });
  const user = await users.deleteOne({ userId: interaction.user.id });
  }
});
    
    } else if (selectedValue === 'everyone-ads') {
         let price = config.price_everyone_ads;
     let result = price;
     
     let tax = Math.floor(price * (20 / 19) + 1);
     let owner = config.owner;
    const embed = new EmbedBuilder()
      .setColor("#000100")
      .setTitle(
      `**عمليه شراء اعلان منشن ايفري**`)
      .setDescription(
      `**لأكمال عملية شراء اعلان منشن ايفري , يرجي نسخ الكود بالاسفل واتمام عملية التحويل **`)
        .setAuthor({
             name: interaction.guild.name,
             iconURL: interaction.guild.iconURL()})
             .setFooter({
             text: interaction.guild.name,
               iconURL: interaction.guild.iconURL()
             })

             .setThumbnail(interaction.guild.iconURL())

         .setTimestamp();
     await interaction.update({
       embeds: [embed],
       components: [],
     })
    await interaction.channel.send({
  content: `#credit ${owner} ${tax}`
  })
    const filter = ({ content, author: { id } }) => {
    return (
        content.startsWith(`**:moneybag: | ${interaction.user.username}, has transferred `) &&
        content.includes(`${owner}`) &&
        id === "282859044593598464" &&
        (Number(content.slice(content.lastIndexOf("`") - String(tax).length, content.lastIndexOf("`"))) >= result)
    );
  };
    const collector = interaction.channel.createMessageCollector({ 
  filter,               
  max: 1,
  time: 60000,
  });
  let iscollected = false;
  collector.on('collect', async (collected) => {
  iscollected = true;
    const embed = new EmbedBuilder()
  .setColor('#000100')
  .setTitle(
  `تمت عملية الشراء بنجاح`)
  .setDescription(
  `**تم شراء اعلان منشن ايفري بنجاح**`)
  .setAuthor({
             name: interaction.guild.name,
             iconURL: interaction.guild.iconURL()
  })
             .setFooter({
             text: interaction.guild.name,
               iconURL: interaction.guild.iconURL()
             })
             .setThumbnail(interaction.guild.iconURL())
         .setTimestamp();
      const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('done-buyads-everyone')
          .setLabel('قم بوضع اعلانك هنا')
          .setStyle(ButtonStyle.Success)
      );
      await interaction.editReply({
  embeds: [embed],
  components: [row],
      });
    const user = await users.deleteOne({ userId: interaction.user.id });
    
});
    collector.on('end', async (collected) => {
  if (!iscollected) {
  const embed = new EmbedBuilder()
  .setColor('#000100')
  .setTitle(
  `انتهى وقت العمليه`)
  .setDescription(
  `**انتهى وقت العمليه**`)
    .setAuthor({
         name: interaction.guild.name,
         iconURL: interaction.guild.iconURL()})
         .setFooter({
         text: interaction.guild.name,
           iconURL: interaction.guild.iconURL()
         })

         .setThumbnail(interaction.guild.iconURL())

     .setTimestamp();
  await interaction.editReply({
  embeds: [embed],
  components: [],
  });
  const user = await users.deleteOne({ userId: interaction.user.id });
  }
});

    
    } else if (selectedValue === 'inroomgivaway-ads') {
         let price = config.price_in_room_givaway_ads;
     let result = price;
     
     let tax = Math.floor(price * (20 / 19) + 1);
     let owner = config.owner;
    const embed = new EmbedBuilder()
      .setColor("#000100")
      .setTitle(
      `**عمليه شراء اعلان قيف اوي في روم**`)
      .setDescription(
      `**لأكمال عملية شراء اعلان قيف اوي في روم , يرجي نسخ الكود بالاسفل واتمام عملية التحويل **`)
               .setAuthor({
             name: interaction.guild.name,
             iconURL: interaction.guild.iconURL()})
             .setFooter({
             text: interaction.guild.name,
               iconURL: interaction.guild.iconURL()
             })

             .setThumbnail(interaction.guild.iconURL())

         .setTimestamp();
     await interaction.update({
       embeds: [embed],
       components: [],
     })
    await interaction.channel.send({
  content: `#credit ${owner} ${tax}` })
    const filter = ({ content, author: { id } }) => {
    return (
        content.startsWith(`**:moneybag: | ${interaction.user.username}, has transferred `) &&
        content.includes(`${owner}`) &&
        id === "282859044593598464" &&
        (Number(content.slice(content.lastIndexOf("`") - String(tax).length, content.lastIndexOf("`"))) >= result)
    );
  };
   const collector = interaction.channel.createMessageCollector({ 
  filter,               
  max: 1,
  time: 60000,
  });
  let iscollected = false;
  collector.on('collect', async (collected) => {
  iscollected = true;
    const embed = new EmbedBuilder()
  .setColor('#000100')
  .setTitle(
  `تمت عملية الشراء بنجاح`)
  .setDescription(
  `**تم شراء اعلان قيف اوي في روم الجيف اواي**`)
         .setAuthor({
             name: interaction.guild.name,
             iconURL: interaction.guild.iconURL()})
             .setFooter({
             text: interaction.guild.name,
               iconURL: interaction.guild.iconURL()
             })

             .setThumbnail(interaction.guild.iconURL())

         .setTimestamp();
      const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('done-buyads-inroom')
          .setLabel('قم بوضع اعلانك هنا')
          .setStyle(ButtonStyle.Success)
      );
      await interaction.editReply({
  embeds: [embed],
  components: [row],
      })
    const user = await users.deleteOne({ userId: interaction.user.id });
});

          collector.on('end', async (collected) => {
  if (!iscollected) {
  const embed = new EmbedBuilder()
  .setColor('#000100')
  .setTitle(
  `انتهى وقت العمليه`)
  .setDescription(
  `**انتهى وقت العمليه**`)
    .setAuthor({
         name: interaction.guild.name,
         iconURL: interaction.guild.iconURL()})
         .setFooter({
         text: interaction.guild.name,
           iconURL: interaction.guild.iconURL()
         })

         .setThumbnail(interaction.guild.iconURL())

     .setTimestamp();
  await interaction.editReply({
  embeds: [embed],
  components: [],
  });
  const user = await users.deleteOne({ userId: interaction.user.id });
  }
});
      
    } else if (selectedValue === 'private-ads') {
         let price = config.price_private_ads;
     let result = price;
     
     let tax = Math.floor(price * (20 / 19) + 1);
     let owner = config.owner;
    const embed = new EmbedBuilder()
      .setColor("#000100")
      .setTitle(
      `**عمليه شراء اعلان خاص**`)
      .setDescription(
      `**لأكمال عملية شراء اعلان خاص , يرجي نسخ الكود بالاسفل واتمام عملية التحويل **`)
                      .setAuthor({
             name: interaction.guild.name,
             iconURL: interaction.guild.iconURL()})
             .setFooter({
             text: interaction.guild.name,
               iconURL: interaction.guild.iconURL()
             })

             .setThumbnail(interaction.guild.iconURL())

         .setTimestamp();
     await interaction.update({
       embeds: [embed],
       components: [],
     })
    await interaction.channel.send({
  content: `#credit ${owner} ${tax}` })

    const filter = ({ content, author: { id } }) => {
    return (
        content.startsWith(`**:moneybag: | ${interaction.user.username}, has transferred `) &&
        content.includes(`${owner}`) &&
        id === "282859044593598464" &&
        (Number(content.slice(content.lastIndexOf("`") - String(tax).length, content.lastIndexOf("`"))) >= result)
    );
  };
    const collector = interaction.channel.createMessageCollector({ 
  filter,               
  max: 1,
  time: 60000,
  });
  let iscollected = false;
  collector.on('collect', async (collected) => {
  iscollected = true;
    const embed = new EmbedBuilder()
  .setColor('#000100')
  .setTitle(
  `تمت عملية الشراء بنجاح`)
  .setDescription(
  `**تم شراء اعلان خاص بنجاح**`)
                .setAuthor({
             name: interaction.guild.name,
             iconURL: interaction.guild.iconURL()})
             .setFooter({
             text: interaction.guild.name,
               iconURL: interaction.guild.iconURL()
             })

             .setThumbnail(interaction.guild.iconURL())

         .setTimestamp();
      const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('done-buyads-private')
          .setLabel('قم بوضع اعلانك هنا')
          .setStyle(ButtonStyle.Success)
      );
      await interaction.editReply({
  embeds: [embed],
  components: [row],
      })
    const user = await users.deleteOne({ userId: interaction.user.id });
});
        collector.on('end', async (collected) => {
  if (!iscollected) {
  const embed = new EmbedBuilder()
  .setColor('#000100')
  .setTitle(
  `انتهى وقت العمليه`)
  .setDescription(
  `**انتهى وقت العمليه**`)
    .setAuthor({
         name: interaction.guild.name,
         iconURL: interaction.guild.iconURL()})
         .setFooter({
         text: interaction.guild.name,
           iconURL: interaction.guild.iconURL()
         })

         .setThumbnail(interaction.guild.iconURL())

     .setTimestamp();
  await interaction.editReply({
  embeds: [embed],
  components: [],
  });
  const user = await users.deleteOne({ userId: interaction.user.id });
  }
});
      

      
    
    } else if (selectedValue === 'private-giveaway-ads') {
         let price = config.price_private_giveaway_ads;
     let result = price;
     
     let tax = Math.floor(price * (20 / 19) + 1);
     let owner = config.owner; 
    const embed = new EmbedBuilder()
      .setColor("#000100")
      .setTitle(
      `**عمليه شراء اعلان قيف اوي خاص**`)
      .setDescription(
      `**لأكمال عملية شراء اعلان قيف اوي خاص , يرجي نسخ الكود بالاسفل واتمام عملية التحويل **`)
           .setAuthor({
             name: interaction.guild.name,
             iconURL: interaction.guild.iconURL()})
             .setFooter({
             text: interaction.guild.name,
               iconURL: interaction.guild.iconURL()
             })

             .setThumbnail(interaction.guild.iconURL())

         .setTimestamp();
     await interaction.update({
       embeds: [embed],
       components: [],
     })
    await interaction.channel.send({
  content: `#credit ${owner} ${tax}` })
  const filter = ({ content, author: { id } }) => {
    return (
        content.startsWith(`**:moneybag: | ${interaction.user.username}, has transferred `) &&
        content.includes(`${owner}`) &&
        id === "282859044593598464" &&
        (Number(content.slice(content.lastIndexOf("`") - String(tax).length, content.lastIndexOf("`"))) >= result)
    );
  };
    const collector = interaction.channel.createMessageCollector({ 
  filter,               
  max: 1,
  time: 60000,
  });
  let iscollected = false;
  collector.on('collect', async (collected) => {
  iscollected = true;
    const embed = new EmbedBuilder()
  .setColor('#000100')
  .setTitle(
  `تمت عملية الشراء بنجاح`)
  .setDescription(
  `**تم شراء اعلان قيف اوي خاص بنجاح**`)
           .setAuthor({
             name: interaction.guild.name,
             iconURL: interaction.guild.iconURL()})
             .setFooter({
             text: interaction.guild.name,
               iconURL: interaction.guild.iconURL()
             })

             .setThumbnail(interaction.guild.iconURL())

         .setTimestamp();
      const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('done-buyads-private-giveaway')
          .setLabel('قم بوضع اعلانك هنا')
          .setStyle(ButtonStyle.Success)
      );
      await interaction.editReply({
  embeds: [embed],
  components: [row],
      })
    const user = await users.deleteOne({ userId: interaction.user.id });
});
        collector.on('end', async (collected) => {
  if (!iscollected) {
  const embed = new EmbedBuilder()
  .setColor('#000100')
  .setTitle(
  `انتهى وقت العمليه`)
  .setDescription(
  `**انتهى وقت العمليه**`)
    .setAuthor({
         name: interaction.guild.name,
         iconURL: interaction.guild.iconURL()})
         .setFooter({
         text: interaction.guild.name,
           iconURL: interaction.guild.iconURL()
         })

         .setThumbnail(interaction.guild.iconURL())

     .setTimestamp();
  await interaction.editReply({
  embeds: [embed],
  components: [],
  });
  const user = await users.deleteOne({ userId: interaction.user.id });
  }
});
    }
  }
});