const Mongoose = require('mongoose');
const testingSchema = new Mongoose.Schema(
  {
      guildId: {
        type: String,
        required: false,
      },
      counter: {
        type: Number,
        default: 0,
      },
  },
);
module.exports = Mongoose.model('testing', testingSchema);