const client = require("../../index.js");
const { EmbedBuilder, ActionRowBuilder , ButtonBuilder , ButtonStyle, TextInputStyle,TextInputBuilder,ModalBuilder } = require("discord.js");
const counters = require('../../Datebase/model/counters/mediator_counter.js');
client.on('interactionCreate', async interaction => {
  if (!interaction.isStringSelectMenu()) return;
  if (interaction.customId === 'mediator') {
    const selectedValue = interaction.values[0];
    if (selectedValue === 'mediator_1') {
      const counter = await counters.updateOne(
        { guildId: interaction.guild.id },
        { $inc: { counter: 1 } },
        { upsert: true }
      );
      const findCount = await counters.findOne({ guildId: interaction.guild.id });
      const ctr = findCount.counter
      const mediator = await interaction.guild.channels.create({
        name: `mediator-${ctr}`,
        type: 0,
        parent: '1264866777817681931',
        permissionOverwrites: [
          {
            id: interaction.guild.id,
            deny: ['ViewChannel'],
          },
          {
            id: interaction.user.id,
            allow: ['ViewChannel'],
          },
         {
            id: "1145673219752333383",
            allow: ['ViewChannel'],
          },
        ],
      });
      await interaction.reply({
        content: `تم إنشاء تذكرتك في ${mediator}`,
        ephemeral: true,
      })
      const row = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId('Sample')
            .setLabel('النموذج')
            .setStyle(ButtonStyle.Secondary),
          new ButtonBuilder()
            .setCustomId('delete_ticket')
            .setLabel('حذف التذكره')
            .setStyle(ButtonStyle.Danger)
        ); 
const embed = new EmbedBuilder()
.setTitle("**__Mediator Ticket__**")
.setDescription(
  `**- مرحبا عزيزي العضو , انت هنا في تذكرة طلب وسيط لضمانك من عدم النصب وضمان حقك
- يرجى الضغط على الزر بالاسفل (النموذج) وقم بتعبئة البيانات المطلوبة منك لكي يتم بدء عملية التوسط واستلام التذكرة من الوسطاء
- يجب عليك ملأ النموذج بشكل كامل وصحيح وعلى حسب الاتفاق بينك وبين الطرف الآخر وبعناية**`)
.setColor("#2f3136")
.setImage("https://media.discordapp.net/attachments/1249856158458708100/1266791369750351972/1000359736.png?ex=66ab0c26&is=66a9baa6&hm=000a65d6385633993b85e461f1da3ac720015725abd5937552fa0e50488cf81e&")
.setTimestamp()
      .setAuthor({
        name: interaction.guild.name,
        iconURL: interaction.guild.iconURL()})
        .setFooter({
        text: interaction.guild.name,
          iconURL: interaction.guild.iconURL()
        })

        .setThumbnail(interaction.guild.iconURL());
      await mediator.send({
        content: `${interaction.user}||<@&1145673223145529385>`,
        components: [row],
        embeds: [embed],
      });

    } else if (selectedValue === 'mediator_2') {
      const counter = await counters.updateOne(
        { guildId: interaction.guild.id },
        { $inc: { counter: 1 } },
        { upsert: true }
      );
      const findCount = await counters.findOne({ guildId: interaction.guild.id });
      const ctr = findCount.counter
      const mediator = await interaction.guild.channels.create({
        name: `mediator-${ctr}`,
        type: 0,
        parent: '1264869290796912764',
        permissionOverwrites: [
          {
            id: interaction.guild.id,
            deny: ['ViewChannel'],
          },
          {
            id: interaction.user.id,
            allow: ['ViewChannel'],
          },
         {
            id: "1145673218733133924",
            allow: ['ViewChannel'],
          },
        ],
      });
      await interaction.reply({
        content: `تم إنشاء تذكرتك في ${mediator}`,
        ephemeral: true,
      })
    const row = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId('Sample2')
            .setLabel('النموذج')
            .setStyle(ButtonStyle.Secondary),
          new ButtonBuilder()
            .setCustomId('delete_ticket')
            .setLabel('حذف التذكره')
            .setStyle(ButtonStyle.Danger)
        ); 
const embed = new EmbedBuilder()
.setTitle("**__Mediator Ticket__**")
.setDescription(
  `**- مرحبا عزيزي العضو , انت هنا في تذكرة طلب وسيط لضمانك من عدم النصب وضمان حقك
- يرجى الضغط على الزر بالاسفل (النموذج) وقم بتعبئة البيانات المطلوبة منك لكي يتم بدء عملية التوسط واستلام التذكرة من الوسطاء
- يجب عليك ملأ النموذج بشكل كامل وصحيح وعلى حسب الاتفاق بينك وبين الطرف الآخر وبعناية**`)
.setColor("#2f3136")
.setImage("https://media.discordapp.net/attachments/1249856158458708100/1266791369750351972/1000359736.png?ex=66ab0c26&is=66a9baa6&hm=000a65d6385633993b85e461f1da3ac720015725abd5937552fa0e50488cf81e&")
.setTimestamp()
      .setAuthor({
        name: interaction.guild.name,
        iconURL: interaction.guild.iconURL()})
        .setFooter({
        text: interaction.guild.name,
          iconURL: interaction.guild.iconURL()
        })

        .setThumbnail(interaction.guild.iconURL());
      await mediator.send({
        content: `${interaction.user}||<@&1145673223145529385>`,
        components: [row],
        embeds: [embed],
      });
    
    } else if (selectedValue === 'mediator_3') {
      const counter = await counters.updateOne(
        { guildId: interaction.guild.id },
        { $inc: { counter: 1 } },
        { upsert: true }
      );
      const findCount = await counters.findOne({ guildId: interaction.guild.id });
      const ctr = findCount.counter
      const mediator = await interaction.guild.channels.create({
        name: `mediator-${ctr}`,
        type: 0,
        parent: '1264869362981015685',
        permissionOverwrites: [
          {
            id: interaction.guild.id,
            deny: ['ViewChannel'],
          },
          {
            id: interaction.user.id,
            allow: ['ViewChannel'],
          },
         {
            id: "1145673217822953556",
            allow: ['ViewChannel'],
          },
        ],
      });
      await interaction.reply({
        content: `تم إنشاء تذكرتك في ${mediator}`,
        ephemeral: true,
      })
    const row = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId('Sample3')
            .setLabel('النموذج')
            .setStyle(ButtonStyle.Secondary),
          new ButtonBuilder()
            .setCustomId('delete_ticket')
            .setLabel('حذف التذكره')
            .setStyle(ButtonStyle.Danger)
        ); 
const embed = new EmbedBuilder()
.setTitle("**__Mediator Ticket__**")
.setDescription(
  `**- مرحبا عزيزي العضو , انت هنا في تذكرة طلب وسيط لضمانك من عدم النصب وضمان حقك
- يرجى الضغط على الزر بالاسفل (النموذج) وقم بتعبئة البيانات المطلوبة منك لكي يتم بدء عملية التوسط واستلام التذكرة من الوسطاء
- يجب عليك ملأ النموذج بشكل كامل وصحيح وعلى حسب الاتفاق بينك وبين الطرف الآخر وبعناية**`)
.setColor("#2f3136")
.setImage("https://media.discordapp.net/attachments/1249856158458708100/1266791369750351972/1000359736.png?ex=66ab0c26&is=66a9baa6&hm=000a65d6385633993b85e461f1da3ac720015725abd5937552fa0e50488cf81e&")
.setTimestamp()
      .setAuthor({
        name: interaction.guild.name,
        iconURL: interaction.guild.iconURL()})
        .setFooter({
        text: interaction.guild.name,
          iconURL: interaction.guild.iconURL()
        })

        .setThumbnail(interaction.guild.iconURL());
      await mediator.send({
        content: `${interaction.user}||<@&1145673223145529385>`,
        components: [row],
        embeds: [embed],
      });
    } else if (selectedValue === 'mediator_4') {
      const counter = await counters.updateOne(
        { guildId: interaction.guild.id },
        { $inc: { counter: 1 } },
        { upsert: true }
      );
      const findCount = await counters.findOne({ guildId: interaction.guild.id });
      const ctr = findCount.counter
      const mediator = await interaction.guild.channels.create({
        name: `mediator-${ctr}`,
        type: 0,
        parent: '1264869449215774751',
        permissionOverwrites: [
          {
            id: interaction.guild.id,
            deny: ['ViewChannel'],
          },
          {
            id: interaction.user.id,
            allow: ['ViewChannel'],
          },
         {
            id: "1145673216027803658",
            allow: ['ViewChannel'],
          },
        ],
      });
      await interaction.reply({
        content: `تم إنشاء تذكرتك في ${mediator}`,
        ephemeral: true,
      })
      const row = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId('Sample4')
            .setLabel('النموذج')
            .setStyle(ButtonStyle.Secondary),
          new ButtonBuilder()
            .setCustomId('delete_ticket')
            .setLabel('حذف التذكره')
            .setStyle(ButtonStyle.Danger)
        ); 
const embed = new EmbedBuilder()
.setTitle("**__Mediator Ticket__**")
.setDescription(
  `**- مرحبا عزيزي العضو , انت هنا في تذكرة طلب وسيط لضمانك من عدم النصب وضمان حقك
- يرجى الضغط على الزر بالاسفل (النموذج) وقم بتعبئة البيانات المطلوبة منك لكي يتم بدء عملية التوسط واستلام التذكرة من الوسطاء
- يجب عليك ملأ النموذج بشكل كامل وصحيح وعلى حسب الاتفاق بينك وبين الطرف الآخر وبعناية**`)
.setColor("#2f3136")
.setImage("https://media.discordapp.net/attachments/1249856158458708100/1266791369750351972/1000359736.png?ex=66ab0c26&is=66a9baa6&hm=000a65d6385633993b85e461f1da3ac720015725abd5937552fa0e50488cf81e&")
.setTimestamp()
      .setAuthor({
        name: interaction.guild.name,
        iconURL: interaction.guild.iconURL()})
        .setFooter({
        text: interaction.guild.name,
          iconURL: interaction.guild.iconURL()
        })

        .setThumbnail(interaction.guild.iconURL());
      await mediator.send({
        content: `${interaction.user}||<@&1145673223145529385>`,
        components: [row],
        embeds: [embed],
      });
    } else if (selectedValue === 'mediator_5') {
      const counter = await counters.updateOne(
        { guildId: interaction.guild.id },
        { $inc: { counter: 1 } },
        { upsert: true }
      );
      const findCount = await counters.findOne({ guildId: interaction.guild.id });
      const ctr = findCount.counter
      const mediator = await interaction.guild.channels.create({
        name: `mediator-${ctr}`,
        type: 0,
        parent: '1264871185523544104',
        permissionOverwrites: [
          {
            id: interaction.guild.id,
            deny: ['ViewChannel'],
          },
          {
            id: interaction.user.id,
            allow: ['ViewChannel'],
          },
         {
            id: "1264870422436905022",
            allow: ['ViewChannel'],
          },
        ],
      });
      await interaction.reply({
        content: `تم إنشاء تذكرتك في ${mediator}`,
        ephemeral: true,
      })
      const row = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId('Sample5')
            .setLabel('النموذج')
            .setStyle(ButtonStyle.Secondary),
          new ButtonBuilder()
            .setCustomId('delete_ticket')
            .setLabel('حذف التذكره')
            .setStyle(ButtonStyle.Danger)
        ); 
const embed = new EmbedBuilder()
.setTitle("**__Mediator Ticket__**")
.setDescription(
  `**- مرحبا عزيزي العضو , انت هنا في تذكرة طلب وسيط لضمانك من عدم النصب وضمان حقك
- يرجى الضغط على الزر بالاسفل (النموذج) وقم بتعبئة البيانات المطلوبة منك لكي يتم بدء عملية التوسط واستلام التذكرة من الوسطاء
- يجب عليك ملأ النموذج بشكل كامل وصحيح وعلى حسب الاتفاق بينك وبين الطرف الآخر وبعناية**`)
.setColor("#2f3136")
.setImage("https://media.discordapp.net/attachments/1249856158458708100/1266791369750351972/1000359736.png?ex=66ab0c26&is=66a9baa6&hm=000a65d6385633993b85e461f1da3ac720015725abd5937552fa0e50488cf81e&")
.setTimestamp()
      .setAuthor({
        name: interaction.guild.name,
        iconURL: interaction.guild.iconURL()})
        .setFooter({
        text: interaction.guild.name,
          iconURL: interaction.guild.iconURL()
        })

        .setThumbnail(interaction.guild.iconURL());
      await mediator.send({
        content: `${interaction.user}||<@&1145673223145529385>`,
        components: [row],
        embeds: [embed],
      });
    }
  }
});
