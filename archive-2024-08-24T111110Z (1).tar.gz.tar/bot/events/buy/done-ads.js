const client = require("../../index.js");
const { EmbedBuilder, ApplicationCommandOptionType , Events , ActionRowBuilder , ButtonBuilder ,MessageAttachment, ButtonStyle , Message, TextInputStyle,TextInputBuilder,ModalBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, PermissionsBitField } = require("discord.js");

const config = require("../../config.json");


const bad = ["👉👌",
"🖕",
 "احا",
 "احه",
 "اير",
 "لعين",
 "واطي",
  "ال",
  "المرا",
  "المره",
  "النيك",
  "عاهر",
  "كلب",
  "احيه",
  "اخو ال",
  "اخو القحبه",
  "افسخك",
  "اقلب وجهك",
  "الخرائ",
  "الزب",
  "السافل",
  "الساقط",
  "العايب",
  "العربان",
  "العرص",
  "العمى",
  "القحبه",
  "الكحبه",
  "الكحبه",
  "الكس",
  "الكلب",
  " ياخ",
  "انذال",
  "انذل",
  "انكح",
  "انيك",
  "انيكك",
  "اهبل",
  "اونطه",
  "اونطه",
  "اونطي",
  "ايري",
  "ايور",
  "بزاز",
  "بعبص",
  "بعص",
  "بغاي",
  "بندوق",
  "بهيمه",
  "تافه",
  "تجليخ",
  "ترهيط",
  "تسد بوزك",
  "تفو",
  "جلخ",
  "جلق",
  "حرامي",
  "حقير",
  "حلبتها",
  "حلبتو",
  "حلمات",
  "حمير",
  "حيوان",
  "خرا",
  "خراء",
  "خراي عل",
  "خراي",
  "خره",
  "خرى",
  "خري",
  "خسيس",
  "خنيث",
  "خوازيق",
  "خول",
  "داشر",
  "داعر",
  "دعاره",
  "دلخ",
  "ديوث",
  "ديود",
  "زامل",
  "زب",
  "زبار",
  "زبر",
  "زبه",
  "زبي",
  "زراط",
  "زق",
  "زناه",
    "زناطير",
  "ساذج",
  "سارموتا",
  "سافل",
  "سرموتا",
  "سفاله",
  "سكسي",
  "سيكس",
  "سيكسي",
  "شرمها",
  "شرموط",
  "شرموطه",
  "شرموطه",
  "شلقه",
  "شلكه",
  "صايع",
  "صياعه",
  "ضرب عشره",
  "طز في",
  "طيز",
  "عاهر",
  "عاهره",
  "عايبه",
  "عبيط",
  "عرص",
  "عكروت",
  "غبي",
  "غتصب",
  "فاجر",
  "فاسق",
  "فجور",
  "فسختها",
  "قحاب",
  "قحب",
  "قحبه",
  "قذر",
  "قضيب",
  "قضيبي",
  "كحبه",
  "كذاب",
  "كس",
  "كسا",
  "كسمك",
  "كسمكم",
  "كسها",
  "كلاب",
  "كلب",
  "كلخر",
  "لحس",
  "لعنه",
  "لقحاب",
  "لوطي",
  "مأجور",
  "مبعوص",
  "متخوزق",
  "متناك",
  "مجنون",
  "مخانيث",
  "مخنث",
  "مدلس",
  "معوهر",
  "مفسوخ",
  "مكسكس",
  "مكوتها",
                  "ممحون",
  "منايك",
  "منيك",
  "منيوك",
  "ناكك",
  "نجس",
  "نذل",
  "نفضك",
  "نفظك",
  "نكت",
  "نياكه",
  "نياكه",
  "وسخ",
  "يتناك",
  "يزغب",
  "يفضح",
  "يفظح",
  "يولاد ال",
  "يلعن",
  "سكس",
  "طيزي",
  "طيزو",
  "شرج",
  "لعق",
  "لحس",
  "مص",
  "تمص",
  "بيضان",
  "ثدي",
  "بز",
  "بزاز",
  "حلمه",
  "مفلقسه",
  "بظر",
  "كس",
  "كسي",
  "فرج",
  "شهوه",
  "شاذ",
  "مبادل",
  "عاهره",
  "جماع",
  "قضيب",
  "زب",
  "لوطي",
  "لواط",
  "سحاق",
  "سحاقيه",
  "اغتصاب",
  "خنثي",
  "احتلام",
  "نيك",
  "متناك",
  "متناكه",
  "شرموطه",
  "عرص",
  "خول",
  "قحبه",
  "لبوه",
  "السكس",
  "الطيز",
  "الطيزي",
  "الطيزو",
  "الشرج",
  "اللعق",
  "اللحس",
  "المص",
  "التمص",
  "البيضان",
  "الثدي",
  "البز",
  "البزاز",
  "الحلمه",
  "المفلقسه",
  "البظر",
  "الكس",
  "الكسي",
  "الفرج",
  "الشهوه",
  "الشاذ",
  "المبادل",
  "العاهره",
  "الجماع",
  "القضيب",
  "الزب",
  "اللوطي",
  "اللواط",
  "السحاق",
  "السحاقيه",
  "الاغتصاب",
  "الخنثي",
  "الخنثي",
  "الاحتلام",
  "النيك",
  "المتناك",
  "المتناكه",
  "الشرموطه",
  "العرص",
  "الخول",
  "القحبه",
  "اللبوه",
  "الفشخه",
  "فشخه",
  "هنيكك",
  "الممحونه",
  "ممحونه",
  "ايري",
  "الاير",
  "بخش",
  "البخش",
  "بخشي",
  "طيزا",
  "عكروت",
  "نايك",
  "انكحك",
  "انتاك",
    "خرايا",
  "ديوث",
  "قواد",
  "يلعن",
  "يلعنك",
  "ملحات",
  "زاكا",
  "صرمك يا خول"
];

client.on('interactionCreate', async interaction => {
  if (!interaction.isButton()) return;
  if (interaction.customId === 'done-buyads-non') {
    const modal = new ModalBuilder()
      .setCustomId('non-ads')
      .setTitle('شراء اعلان');
    const nonads = new TextInputBuilder()
      .setCustomId('nonads')
      .setLabel('اكتب اعلانك هنا')
      .setStyle(TextInputStyle.Paragraph)
      .setRequired(true);
    const firstActionRow = new ActionRowBuilder().addComponents(nonads);
    modal.addComponents(firstActionRow);
    await interaction.showModal(modal);
  } else if (interaction.customId === 'done-buyads-here') {
    const modal = new ModalBuilder()
      .setCustomId('here-ads')
      .setTitle('شراء اعلان');
    const hereads = new TextInputBuilder()
      .setCustomId('hereads')
      .setLabel('اكتب اعلانك هنا')
      .setStyle(TextInputStyle.Paragraph)
      .setRequired(true);
    const firstActionRow = new ActionRowBuilder().addComponents(hereads);
    modal.addComponents(firstActionRow);
    await interaction.showModal(modal);
  } else if (interaction.customId === 'done-buyads-everyone') {
    const modal = new ModalBuilder()
      .setCustomId('everyone-ads')
      .setTitle('شراء اعلان');
    const everyoneads = new TextInputBuilder()
      .setCustomId('everyoneads')
      .setLabel('اكتب اعلانك هنا')
      .setStyle(TextInputStyle.Paragraph)
      .setRequired(true);
    const firstActionRow = new ActionRowBuilder().addComponents(everyoneads);
    modal.addComponents(firstActionRow);
    await interaction.showModal(modal);
  } else if (interaction.customId === 'done-buyads-inroom') {
    const modal = new ModalBuilder()
      .setCustomId('inroom-ads')
      .setTitle('شراء اعلان');
    const inroomads = new TextInputBuilder()
      .setCustomId('inroomads')
      .setLabel('اكتب اعلانك هنا')
      .setStyle(TextInputStyle.Paragraph)
      .setRequired(true);
    const firstActionRow = new ActionRowBuilder().addComponents(inroomads);
    modal.addComponents(firstActionRow);
    await interaction.showModal(modal);
  } else if (interaction.customId === 'done-buyads-private') {
    const modal = new ModalBuilder()
      .setCustomId('private-ads')
      .setTitle('شراء اعلان');
    const nameprivateroom = new TextInputBuilder()
      .setCustomId('nameprivateroom')
      .setLabel('اسم الروم')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);
    const privateads = new TextInputBuilder()
      .setCustomId('privateads')
      .setLabel('اكتب اعلانك هنا')
      .setStyle(TextInputStyle.Paragraph)
      .setRequired(true);
    const firstActionRow = new ActionRowBuilder().addComponents(nameprivateroom);
    const secondActionRow = new ActionRowBuilder().addComponents(privateads);
    modal.addComponents(firstActionRow, secondActionRow);
    await interaction.showModal(modal);
  } else if (interaction.customId === 'done-buyads-private-giveaway') {
    const modal = new ModalBuilder()
      .setCustomId('private-giveaway-ads')
      .setTitle('شراء اعلان');
    const nameprivateroom = new TextInputBuilder()
      .setCustomId('nameprivaterooom')
      .setLabel('اسم الروم')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);
    const privateads = new TextInputBuilder()
      .setCustomId('givawayprivateads')
      .setLabel('اكتب اعلانك هنا')
      .setStyle(TextInputStyle.Paragraph)
      .setRequired(true);
    const firstActionRow = new ActionRowBuilder().addComponents(nameprivateroom);
    const secondActionRow = new ActionRowBuilder().addComponents(privateads);
    modal.addComponents(firstActionRow, secondActionRow);
    await interaction.showModal(modal);
  }
});
client.on('interactionCreate', async interaction => {
  if (!interaction.isModalSubmit()) return;
  if (interaction.customId === 'non-ads') {
    const nonads = interaction.fields.getTextInputValue('nonads');

    


    if (bad.some(word => nonads.includes(word))) { 
      const embed = new EmbedBuilder()
        .setColor('#000100')
        .setTitle(`عملية الشراء تم الغاءها`)
        .setDescription(`**تم إلغاء عملية الشراء لأن الرسالة تحتوي على كلمات ممنوعة**`);
      await interaction.reply({
        embeds: [embed],
        ephemeral: true,
      });
    } else {
    
    const channel = client.channels.cache.get(config.adschannel);
         const embed = new EmbedBuilder()
     .setColor('#000100')
     .setTitle('تم نشر اعلانك بنجاح')
     .setDescription("`**تم عمالية الشراء سيتم قفل تكت بعد 5 ثواني .**`")
    
      const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('1')
        .setLabel('تم شراء بنجاح')
.setStyle(ButtonStyle.Success)
.setDisabled(true)
      ); 
    await interaction.update({
      components: [row],
      embeds: [embed]
    })
    await channel.send({
      content: `${nonads}`
    })
  await channel.send({
    content: `ليس لنا أدنى علاقه بما يحدث داخل السيرفرات المعلن عنها كلها إعلانات مدفوعه ، لطلب إعلان مثله حياك <#>`
  })

setTimeout(async () => {
interaction.channel.delete() 
}, 5000)
      const log = client.channels.cache.get(config.adds)
const log1 = new EmbedBuilder()
  .setColor("#000100")
  .setTitle("تم شراء اعلان")
  .addFields(
    {
      name: "الاعلان",
      value: `${nonads}`
    },
    {
      name: "المنشن",
      value: `بدون منشن`,
    },
    {
      name: "صاحب الاعلان",
      value: `${interaction.user}`
    },
    {
      name: "تاريخ شراء الاعلان",
      value: `**<t:${Math.floor(Date.now() / 1000)}:R>**`
    }
  )
      .setAuthor({
           name: interaction.guild.name,
           iconURL: interaction.guild.iconURL()})
           .setFooter({
           text: interaction.guild.name,
             iconURL: interaction.guild.iconURL()
           })

           .setThumbnail(interaction.guild.iconURL())

       .setTimestamp();
    log.send({
      embeds: [log1]
    });
  }
  
  } else if (interaction.customId === 'here-ads') {
    const hereads = interaction.fields.getTextInputValue('hereads');
    
    
    if (bad.some(word => hereads.includes(word))) { 
      const embed = new EmbedBuilder()
        .setColor('#000100')
        .setTitle(`عملية الشراء تم الغاءها`)
        .setDescription(`**تم إلغاء عملية الشراء لأن الرسالة تحتوي على كلمات ممنوعة**`);
      await interaction.reply({
        embeds: [embed],
        ephemeral: true,
      });
    } else {
    const channel = client.channels.cache.get(config.adschannel);
    
         const embed = new EmbedBuilder()
     .setColor('#000100')
     .setTitle('تم نشر اعلانك بنجاح')
     .setDescription("`**تم عمالية الشراء سيتم قفل تكت بعد 5 ثواني .**`")
    
      const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('1')
        .setLabel('تم شراء بنجاح')
.setStyle(ButtonStyle.Success)
.setDisabled(true)
      ); 
    await interaction.update({
      components: [row],
      embeds: [embed]
    })
    await channel.send({
      content: `${hereads}\n@here`
    })
  await channel.send({
    content: `ليس لنا أدنى علاقه بما يحدث داخل السيرفرات المعلن عنها كلها إعلانات مدفوعه ، لطلب إعلان مثله حياك #⌬〢تكتات`
  })

setTimeout(async () => {
interaction.channel.delete() 
}, 5000)
const log = client.channels.cache.get(config.adds)
const log2 = new EmbedBuilder()
  .setColor("#000100")
  .setTitle("تم شراء اعلان")
  .addFields(
    {
      name: "الاعلان",
      value: `${hereads}`
    },
    {
      name: "المنشن",
      value: `**@here**`,
    },
    {
      name: "صاحب الاعلان",
      value: `${interaction.user}`
    },
    {
      name: "تاريخ شراء الاعلان",
      value: `**<t:${Math.floor(Date.now() / 1000)}:R>**`
    }
  )
      .setAuthor({
           name: interaction.guild.name,
           iconURL: interaction.guild.iconURL()})
           .setFooter({
           text: interaction.guild.name,
             iconURL: interaction.guild.iconURL()
           })

           .setThumbnail(interaction.guild.iconURL())

       .setTimestamp();
    log.send({
      embeds: [log2]
    });
    }
  } else if (interaction.customId === 'everyone-ads') {
    const everyoneads = interaction.fields.getTextInputValue('everyoneads');
      if (bad.some(word => everyoneads.includes(word))) { 
        const embed = new EmbedBuilder()
          .setColor('#000100')
          .setTitle(`عملية الشراء تم الغاءها`)
          .setDescription(`**تم إلغاء عملية الشراء لأن الرسالة تحتوي على كلمات ممنوعة**`);
        await interaction.reply({
          embeds: [embed],
          ephemeral: true,
        });
      } else {
      const channel = client.channels.cache.get(config.adschannel);
             const embed = new EmbedBuilder()
     .setColor('#000100')
     .setTitle('تم نشر اعلانك بنجاح')
     .setDescription("`**تم عمالية الشراء سيتم قفل تكت بعد 5 ثواني .**`")
    
      const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('1')
        .setLabel('تم شراء بنجاح')
.setStyle(ButtonStyle.Success)
.setDisabled(true)
      ); 
    await interaction.update({
      components: [row],
      embeds: [embed]
    })
    await channel.send({
      content: `${everyoneads}\n@everyone`
    })
  await channel.send({
    content: `ليس لنا أدنى علاقه بما يحدث داخل السيرفرات المعلن عنها كلها إعلانات مدفوعه ، لطلب إعلان مثله حياك #⌬〢تكتات`
  })

setTimeout(async () => {
interaction.channel.delete() 
}, 5000)
   const log = client.channels.cache.get(config.adds)
const log3 = new EmbedBuilder()
  .setColor("#000100")
  .setTitle("تم شراء اعلان")
  .addFields(
    {
      name: "الاعلان",
      value: `${everyoneads}`
    },
    {
      name: "المنشن",
      value: `**@everyone**`,
    },
    {
      name: "صاحب الاعلان",
      value: `${interaction.user}`
    },
    {
      name: "تاريخ شراء الاعلان",
      value: `**<t:${Math.floor(Date.now() / 1000)}:R>**`
    }
  )
      .setAuthor({
           name: interaction.guild.name,
           iconURL: interaction.guild.iconURL()})
           .setFooter({
           text: interaction.guild.name,
             iconURL: interaction.guild.iconURL()
           })

           .setThumbnail(interaction.guild.iconURL())

       .setTimestamp();
    log.send({
      embeds: [log3]
    });
    }
  } else if (interaction.customId === 'inroom-ads') {
    const inroomads = interaction.fields.getTextInputValue('inroomads');
  if (bad.some(word => inroomads.includes(word))) { 
        const embed = new EmbedBuilder()
          .setColor('#000100')
          .setTitle(`عملية الشراء تم الغاءها`)
          .setDescription(`**تم إلغاء عملية الشراء لأن الرسالة تحتوي على كلمات ممنوعة**`);
        await interaction.reply({
          embeds: [embed],
          ephemeral: true,
        });
      } else {
      const channel = client.channels.cache.get(config.givaway_adschannel);
    const embed = new EmbedBuilder()
     .setColor('#000100')
     .setTitle('تم نشر اعلانك بنجاح')
     .setDescription("`**تم عمالية الشراء سيتم قفل تكت بعد 5 ثواني .**`")
    
      const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('1')
        .setLabel('تم شراء بنجاح')
.setStyle(ButtonStyle.Success)
.setDisabled(true)
      ); 
    await interaction.update({
      components: [row],
      embeds: [embed]
    })
    await channel.send({
      content: `${inroomads}\n@everyone`
    })
  await channel.send({
    content: `ليس لنا أدنى علاقه بما يحدث داخل السيرفرات المعلن عنها كلها إعلانات مدفوعه ، لطلب إعلان مثله حياك #⌬〢تكتات`
  })
    setTimeout(async () => {
interaction.channel.delete() 
}, 5000)
   const log = client.channels.cache.get(config.adds)
const log4 = new EmbedBuilder()
  .setColor("#000100")
  .setTitle("تم شراء اعلان")
  .addFields(
    {
      name: "الاعلان",
      value: `${inroomads}`
    },
    {
      name: "المنشن",
      value: `** في روم هدايا الاعلانات و @everyone**`,
    },
    {
      name: "صاحب الاعلان",
      value: `${interaction.user}`
    },
    {
      name: "تاريخ شراء الاعلان",
      value: `**<t:${Math.floor(Date.now() / 1000)}:R>**`
    }
  )
      .setAuthor({
           name: interaction.guild.name,
           iconURL: interaction.guild.iconURL()})
           .setFooter({
           text: interaction.guild.name,
             iconURL: interaction.guild.iconURL()
           })

           .setThumbnail(interaction.guild.iconURL())

       .setTimestamp();
    log.send({
      embeds: [log4]
    });
    }
  } else if (interaction.customId === 'private-ads') {
    const privateads = interaction.fields.getTextInputValue('privateads');
  const nameroom = interaction.fields.getTextInputValue('nameprivateroom')

  if (bad.some(word => privateads.includes(word))) { 
    const embed = new EmbedBuilder()
      .setColor('#000100')
      .setTitle(`عملية الشراء تم الغاءها`)
      .setDescription(`**تم إلغاء عملية الشراء لأن الرسالة تحتوي على كلمات ممنوعة**`);
    await interaction.reply({
      embeds: [embed],
      ephemeral: true,
    });
  } else {
    const categoryroom = client.channels.cache.get(config.categoryroom);
                 const embed = new EmbedBuilder()
     .setColor('#000100')
     .setTitle('تم نشر اعلانك بنجاح')
     .setDescription("`**تم عمالية الشراء سيتم قفل تكت بعد 5 ثواني .**`")
    
      const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('1')
        .setLabel('تم شراء بنجاح')
.setStyle(ButtonStyle.Success)
.setDisabled(true)
      ); 
    await interaction.update({
      components: [row],
      embeds: [embed]
    })
    const privateads1 = await interaction.guild.channels.create({
      name: `${nameroom}`,
      type: 0,
      parent: categoryroom,
            permissionOverwrites: [
          {
            id: interaction.guild.id,
            allow: ['ViewChannel'],
            deny: ['SendMessages'],
          },
        ],
      });
    await privateads1.send({
      content: `${privateads}\n@everyone`
    })
  await privateads1.send({
    content: `ليس لنا أدنى علاقه بما يحدث داخل السيرفرات المعلن عنها كلها إعلانات مدفوعه ، لطلب إعلان مثله حياك #⌬〢تكتات`
  })
  setTimeout(async () => {
interaction.channel.delete() 
}, 5000)
   const log = client.channels.cache.get(config.adds)
    const log5 = new EmbedBuilder()
  .setColor("#000100")
  .setTitle("تم شراء اعلان")
  .addFields(
    {
      name: "الاعلان",
      value: `${privateads}`
    },
    {
      name: "المنشن",
      value: `**روم خاص بدون جيف اواي **`,
    },
    {
      name: "صاحب الاعلان",
      value: `${interaction.user}`
    },
    {
      name: "تاريخ شراء الاعلان",
      value: `**<t:${Math.floor(Date.now() / 1000)}:R>**`
    }
  )
      .setAuthor({
           name: interaction.guild.name,
           iconURL: interaction.guild.iconURL()})
           .setFooter({
           text: interaction.guild.name,
             iconURL: interaction.guild.iconURL()
           })

           .setThumbnail(interaction.guild.iconURL())

       .setTimestamp();
    log.send({
      embeds: [log5]
    });
    }
  } else if (interaction.customId === 'private-giveaway-ads') {
    const privateads1 = interaction.fields.getTextInputValue('givawayprivateads');
  const nameroom1 = interaction.fields.getTextInputValue('nameprivaterooom')
  if (bad.some(word => privateads1.includes(word))) { 
    const embed = new EmbedBuilder()
      .setColor('#000100')
      .setTitle(`عملية الشراء تم الغاءها`)
      .setDescription(`**تم إلغاء عملية الشراء لأن الرسالة تحتوي على كلمات ممنوعة**`);
    await interaction.reply({
      embeds: [embed],
      ephemeral: true,
    });
  } else {
    const categoryroom = client.channels.cache.get(config.categoryroom);
                 const embed = new EmbedBuilder()
     .setColor('#000100')
     .setTitle('تم نشر اعلانك بنجاح')
     .setDescription("`**تم عمالية الشراء سيتم قفل تكت بعد 5 ثواني .**`")
    
      const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('1')
        .setLabel('تم شراء بنجاح')
.setStyle(ButtonStyle.Success)
.setDisabled(true)
      ); 
    await interaction.update({
      components: [row],
      embeds: [embed]
    })
    const privateads2 = await interaction.guild.channels.create({
      name: `${nameroom1}`,
      type: 0,
      parent: categoryroom,
            permissionOverwrites: [
          {
            id: interaction.guild.id,
            allow: ['ViewChannel'],
            deny: ['SendMessages'],
          },
        ],
      });
    await privateads2.send({
      content: `${privateads1}\n@everyone`
    })
  await privateads2.send({
    content: `ليس لنا أدنى علاقه بما يحدث داخل السيرفرات المعلن عنها كلها إعلانات مدفوعه ، لطلب إعلان مثله حياك #⌬〢تكتات`
  })
  setTimeout(async () => {
interaction.channel.delete() 
}, 5000)
   const log = client.channels.cache.get(config.adds)
    const log6 = new EmbedBuilder()
  .setColor("#000100")
  .setTitle("تم شراء اعلان")
  .addFields(
    {
      name: "الاعلان",
      value: `${privateads1}`
    },
    {
      name: "المنشن",
      value: `**روم خاص معا جيف اواي **`,
    },
    {
      name: "صاحب الاعلان",
      value: `${interaction.user}`
    },
    {
      name: "تاريخ شراء الاعلان",
      value: `**<t:${Math.floor(Date.now() / 1000)}:R>**`
    }
  )
      .setAuthor({
           name: interaction.guild.name,
           iconURL: interaction.guild.iconURL()})
           .setFooter({
           text: interaction.guild.name,
             iconURL: interaction.guild.iconURL()
           })

           .setThumbnail(interaction.guild.iconURL())

       .setTimestamp();
    log.send({
      embeds: [log6]
    });
    }
  }
});