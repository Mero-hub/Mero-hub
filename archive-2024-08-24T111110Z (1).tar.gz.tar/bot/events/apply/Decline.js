const client = require("../../index.js");
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const apply = require("../../Datebase/model/apply/support_apply.js");
client.on("interactionCreate", async (interaction) => {
  if (interaction.isButton()) {
    if (interaction.customId === "decline_support") {
      if (!interaction.member.roles.cache.has("1197472555615916132"))
        return interaction.reply({
          content: `You don't have permission to use this button.`,
          ephemeral: true,
        });
      const member = interaction.message.content.slice(2, 20);
      const user = interaction.guild.members.cache.get(member);
      const channel = interaction.guild.channels.cache.get("1252733230331985982");
      const decline = await             apply.findOne({
      guildId: interaction.guild.id,
      userId: user.id,
      });   
      await apply.deleteOne({
      guildId: interaction.guild.id,
      userId: user.id,
    });
    
      const embed = new EmbedBuilder()
        .setTitle("تم رفضك")
        .setDescription(`تم رفضك كـ اداري بسيرفر كينك
 بسبب عدم توافر الشروط`)
        .setColor("#000100")
        .setAuthor({
            name: interaction.guild.name,
            iconURL: interaction.guild.iconURL()
          })
          .setFooter({
            text: interaction.guild.name,
            iconURL: interaction.guild.iconURL()
          })
          .setThumbnail(interaction.guild.iconURL())
        .setTimestamp();
      await channel.send({
       content: `> <@${member}>`,
       embeds: [embed]
      });
      await interaction.reply({
        content: `تم رفض <@${member}> كـ اداري بسيرفر كينك`,
        ephemeral: true,
      })
      const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('accept_mediator')
          .setLabel('قبول')
        .setDisabled(true)
.setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId('decline_mediator')
          .setLabel(`تم رفض المقدم من قبل ${interaction.user.tag}`)
        .setDisabled(true)
          .setStyle(ButtonStyle.Danger),
        new ButtonBuilder()
          .setCustomId('blacklist_report')
          .setLabel('حظر')
        .setDisabled(true)
          .setStyle(ButtonStyle.Secondary),


      );
      await interaction.message.edit({
components: [row]
      })

    } else if (interaction.customId === "decline_mediator") {
      if (!interaction.member.roles.cache.has("1262820500824920144"))
        return interaction.reply({
          content: `You don't have permission to use this button.`,
          ephemeral: true,
        });
      const member = interaction.message.content.slice(2, 20);
      const user = interaction.guild.members.cache.get(member);
      const channel = interaction.guild.channels.cache.get("1252733230331985982");
      const decline = await             apply.findOne({
      guildId: interaction.guild.id,
      userId: user.id,
      });   
      await apply.deleteOne({
      guildId: interaction.guild.id,
      userId: user.id,
    });
      
      const embed = new EmbedBuilder()
        .setTitle("تم رفضك")
        .setDescription(`تم رفضك كـ وسيط بسيرفر كينك 
 بسبب عدم توافر الشروط`)
        .setColor("#000100")
        .setAuthor({
            name: interaction.guild.name,
            iconURL: interaction.guild.iconURL()
          })
          .setFooter({
            text: interaction.guild.name,
            iconURL: interaction.guild.iconURL()
          })
          .setThumbnail(interaction.guild.iconURL())
        .setTimestamp();
      await channel.send({
       content: `> <@${member}>`,
       embeds: [embed]
      });
      await interaction.reply({
        content: `تم رفض <@${member}> كـ  وسيط بسيرفر كينك`,
        ephemeral: true,
      })
      const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('accept_mediator')
          .setLabel('قبول')
        .setDisabled(true)
.setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId('decline_mediator')
          .setLabel(`تم رفض المقدم من قبل ${interaction.user.tag}`)
        .setDisabled(true)
          .setStyle(ButtonStyle.Danger),
        new ButtonBuilder()
          .setCustomId('blacklist_report')
          .setLabel('حظر')
        .setDisabled(true)
          .setStyle(ButtonStyle.Secondary),
      );
      await interaction.message.edit({
components: [row]
      })
    } else if (interaction.customId === "decline_report") {
      if (!interaction.member.roles.cache.has("1262820500824920144"))
        return interaction.reply({
          content: `You don't have permission to use this button.`,
          ephemeral: true,
        });
      const member = interaction.message.content.slice(2, 20);
      const user = interaction.guild.members.cache.get(member);
      const channel = interaction.guild.channels.cache.get("1252733230331985982");
      const decline = await             apply.findOne({
      guildId: interaction.guild.id,
      userId: user.id,
      });   
      await apply.deleteOne({
      guildId: interaction.guild.id,
      userId: user.id,
    });
      const embed = new EmbedBuilder()
        .setTitle("تم رفضك")
        .setDescription(`تم رفضك كـ قاضي بسيرفر كينك بسبب عدم توافر الشروط`)


        .setColor("#000100")
        .setAuthor({
            name: interaction.guild.name,
            iconURL: interaction.guild.iconURL()
          })
          .setFooter({
            text: interaction.guild.name,
            iconURL: interaction.guild.iconURL()
          })
          .setThumbnail(interaction.guild.iconURL())
        .setTimestamp();
      await channel.send({
       content: `> <@${member}>`,
       embeds: [embed]
      });
      await interaction.reply({
        content: `تم رفض <@${member}> كـ قاضي بسيرفر ريدبول`,
        ephemeral: true,
      })
      const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('accept_mediator')
          .setLabel('قبول')
        .setDisabled(true)
.setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId('decline_mediator')
          .setLabel(`تم رفض المقدم من قبل ${interaction.user.tag}`)
        .setDisabled(true)
          .setStyle(ButtonStyle.Danger),
        new ButtonBuilder()
          .setCustomId('blacklist_report')
          .setLabel('حظر')
        .setDisabled(true)
          .setStyle(ButtonStyle.Secondary),
      );
      await interaction.message.edit({
components: [row]
      })
    }
   }
});
