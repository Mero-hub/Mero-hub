const client = require("../../index.js");
const { EmbedBuilder, ApplicationCommandOptionType , Events , ActionRowBuilder , ButtonBuilder ,MessageAttachment, ButtonStyle , Message, TextInputStyle,TextInputBuilder,ModalBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, PermissionsBitField } = require("discord.js");
client.on('interactionCreate', async interaction => {
  if (!interaction.isButton()) return;
  if (interaction.customId === 'mediator_help') {
    if (!interaction.member.permissions.has("1145673223145529385")) return interaction.reply({ content: `**هنهزر يسطا ولا ايه**`, ephemeral: true });
   const row = new StringSelectMenuBuilder()
    .setCustomId('mediator_help1')
    .setPlaceholder('برجاء التحديد')
    .addOptions(
      new StringSelectMenuOptionBuilder()
        .setLabel('اضافه شخص للتذكرة')
        .setValue('mediator_add_user'),
      new StringSelectMenuOptionBuilder()
        .setLabel('ازاله شخص من التذكرة')
        .setValue('mediator_remove_user'),
      new StringSelectMenuOptionBuilder()
        .setLabel('تغيير اسم التذكره')
        .setValue('mediator_change_name'),
      new StringSelectMenuOptionBuilder()
        .setLabel('اضافه رتبه لشخص')
        .setValue('mediator_add_role'),
    );
    const row1 = new ActionRowBuilder()
      .addComponents(row);
    interaction.reply({
      components: [row1],
      ephemeral: true
    });
  }
});
client.on('interactionCreate', async interaction => {
  if (!interaction.isStringSelectMenu()) return;
  if (interaction.customId === 'mediator_help1') {
    const selectedValue = interaction.values[0];
    if (selectedValue === 'mediator_add_user') {
      const modal = new ModalBuilder()
        .setCustomId('mediator_add_user_modal')
        .setTitle('اضافه شخص للتذكرة');
      const user_id = new TextInputBuilder()
        .setCustomId('mediator_user_id')
        .setLabel("ايدي الشخص")
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
        .setPlaceholder('حط ايدي الشخص');
      const row = new ActionRowBuilder().addComponents(user_id);
      modal.addComponents(row);
      await interaction.showModal(modal);
    } else if (selectedValue === 'mediator_remove_user') {
      const modal = new ModalBuilder()
        .setCustomId('mediator_remove_user_modal')
        .setTitle('ازاله شخص من التذكرة');
      const reovem_user_id = new TextInputBuilder()
        .setCustomId('mediator_remove_user_id')
        .setLabel("ايدي الشخص")
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
        .setPlaceholder('حط ايدي الشخص');
      const row = new ActionRowBuilder().addComponents(reovem_user_id);
      modal.addComponents(row);
      await interaction.showModal(modal);
    } else if (selectedValue === 'mediator_change_name') {
      const modal = new ModalBuilder()
        .setCustomId('mediator_change_name_modal')
        .setTitle('تغيير اسم التذكره');
      const name = new TextInputBuilder()
        .setCustomId('mediator_name')
        .setLabel("تغيير اسم التذكره")
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
        .setPlaceholder('حط اسم التذكرة');
      const row = new ActionRowBuilder().addComponents(name);
      modal.addComponents(row);
      await interaction.showModal(modal);
    } else if (selectedValue === 'mediator_add_role') {
      const modal = new ModalBuilder()
        .setCustomId('mediator_add_role_modal')
        .setTitle('اضافه رتبه لشخص');
      const user_id1 = new TextInputBuilder()
        .setCustomId("mediator_add_role_user_id")
        .setLabel("ايدي الشخص")
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
        .setPlaceholder('حط ايدي الشخص');
      const role_id = new TextInputBuilder()
        .setCustomId('mediator_role_id')
        .setLabel("ايدي الرتبه")
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
        .setPlaceholder('حط ايدي الرتبه');
      const row1 = new ActionRowBuilder().addComponents(user_id1)
      const row = new ActionRowBuilder().addComponents(role_id);
      modal.addComponents(row1, row);
      await interaction.showModal(modal);
    }
  }
});
client.on('interactionCreate', async interaction => {
  if (!interaction.isModalSubmit()) return;
  if (interaction.customId === 'mediator_add_user_modal') {
    const user_id = interaction.fields.getTextInputValue('mediator_user_id');
    const channel = interaction.channel;
    const member = interaction.guild.members.cache.get(user_id);
    if (!member) {
      return interaction.reply({
        content: 'الشخص غير موجود في السيرفر',
        ephemeral: true
      });
    }
  channel.permissionOverwrites.create(member, {
    ViewChannel: true,
    SendMessages: true
  });
  interaction.reply({
    content: `تم اضافه ${member} للتذكرة`,
    ephemeral: true
  });
  } else if (interaction.customId === 'mediator_remove_user_modal') {
    const remove_user_id = interaction.fields.getTextInputValue('mediator_remove_user_id');
    const channel = interaction.channel;
    const member = interaction.guild.members.cache.get(remove_user_id);
    if (!member) {
      return interaction.reply({
        content: 'الشخص غير موجود في السيرفر',
        ephemeral: true
      });
    }
    channel.permissionOverwrites.delete(member);
    interaction.reply({
      content: `تم ازاله ${member} من التذكرة`,
      ephemeral: true
    });
  } else if (interaction.customId === 'mediator_change_name_modal') {
    const name = interaction.fields.getTextInputValue('auction_name');
    const channel = interaction.channel;
    channel.setName(name);
    interaction.reply({
      content: `تم تغيير اسم التذكره الى \`\`\`${name}\`\`\``,
      ephemeral: true
    });
  } else if (interaction.customId === 'mediator_add_role_modal') {
    const user_id = interaction.fields.getTextInputValue('mediator_add_role_user_id');
    const role_id = interaction.fields.getTextInputValue('mediator_role_id');
    const channel = interaction.channel;
    const member = interaction.guild.members.cache.get(user_id);
    if (!member) {
      return interaction.reply({
        content: 'الشخص غير موجود في السيرفر',
        ephemeral: true
      });
    }
    const role = interaction.guild.roles.cache.get(role_id);
    if (!role) {
      return interaction.reply({
        content: 'الرتبه غير موجوده في السيرفر',
        ephemeral: true
      });
    }
    member.roles.add(role);
    interaction.reply({
      content: `تم اضافه ${role} لـ ${member}`,
      ephemeral: true
    })
  }
});