const client = require("../../index.js");
const { EmbedBuilder, ApplicationCommandOptionType , Events , ActionRowBuilder , ButtonBuilder ,MessageAttachment, ButtonStyle , Message, TextInputStyle,TextInputBuilder,ModalBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, PermissionsBitField } = require("discord.js");

const roles = ["1133094416085549056","1133094416085549056" ,"1224829322926227640","1226500959849680896"];
const warn25 = "1229207878322356256";
const warn50 = "1229207955254280204";


client.on('interactionCreate', async interaction => {

if (interaction.isMessageContextMenuCommand()) {

    
    if (interaction.commandName === 'Warn') {
      const message = await interaction.channel.messages.fetch(interaction.targetId);
      const member = await interaction.guild.members.fetch(message.author.id)
      if (!member) return interaction.reply({ content: "**لا يمكنني العثور على هذا العضو**", ephemeral: true });
              const select = new StringSelectMenuBuilder()
            .setCustomId("warn_member2")
            .setPlaceholder("اختر السبب")
            .addOptions(
                new StringSelectMenuOptionBuilder()
                    .setLabel("بيع كريديت")
                    .setDescription("اذ البائع يبيع كريدت باي شكل من الأشكال")
                    .setValue("1"),
                new StringSelectMenuOptionBuilder()
                    .setLabel("بيع عمله حقيقة")
                    .setDescription("اذ البائع يبيع عمله حقيقة")
                    .setValue("2"),
                new StringSelectMenuOptionBuilder()
                    .setLabel("+18")
                    .setDescription("اذ البائع يبيع اشياء+18")
                    .setValue("3"),
                new StringSelectMenuOptionBuilder()
                    .setLabel("طرق نيترو او طرق كريديت ")
                    .setDescription("اذا البائع يبيع طرق نيترو او طرق كريديت")
                    .setValue("4"),
              
              new StringSelectMenuOptionBuilder()
                    .setLabel("منشن ايفري وان")
                    .setDescription("اذا البائع يمنشن ايفري وان")
                    .setValue("5"),
              new StringSelectMenuOptionBuilder()
                    .setLabel("بيع منتج عبر دخول السيرفر")
                    .setDescription("اذا البائع يبيع منتج عبر دخول السيرفر")
                    .setValue("6"),
              new StringSelectMenuOptionBuilder()
                    .setLabel("الاستهبال في رومات البيع")
                    .setDescription("اذا البائع يستهبل في رومات البيع")
                    .setValue("7"),
              new StringSelectMenuOptionBuilder()
                    .setLabel("نسخ منشور شخص اخر")
                    .setDescription("اذا البائع نسخ منشور شخص اخر")
                    .setValue("8"),
              new StringSelectMenuOptionBuilder()
                    .setLabel("بيع ادوات او برامج")
                    .setDescription("اذا البائع يبيع ادوات او برامج")
                    .setValue("9"),
              new StringSelectMenuOptionBuilder()
              .setLabel("بيع فيزات")
              .setDescription("اذا البائع يبيع فيزات")
              .setValue("10"),
              new StringSelectMenuOptionBuilder()
                    .setLabel("نشر بروم غلط")
                    .setDescription("اذا البائع نشر  في روم غلط")
                    .setValue("11"),
              new StringSelectMenuOptionBuilder()
                    .setLabel("عدم تشفير")
                    .setDescription("اذا البائع قام ب عدم تشفير كلمه ممنوعه")
                    .setValue("12"),
            )
        const row = new ActionRowBuilder().addComponents(select);
interaction.reply({ components: [row], ephemeral: true });
     const filter = i => i.customId === 'warn_member2' && i.user.id === interaction.user.id;
const collector = interaction.channel.createMessageComponentCollector({ filter, time: 15000 });
collector.on('collect', async i => {
  if (i.customId === 'warn_member2') {
    const value = i.values[0];
    if (value === "1") {
      const warnchannel = interaction.guild.channels.cache.get("1231190395874971680");
      const embed = new EmbedBuilder()
      .setTitle("تحذير جديد")
      .addFields(
        {
          name: "البائع", 
          value: `${member}`
        },
        {
          name: "الاداري",
          value: `${interaction.user}`
        },
        {
          name: "التحذير",
          value: "بيع كريديت"
        },
        {
          name: "الروم",
          value: `${interaction.channel}`
        },
        {
          name: "وقت نشر المنشور",
          value: `<t:${Math.floor(interaction.createdTimestamp / 1000)}:R>`
        },
        {
          name: "وقت التحذير",
          value: `<t:${Math.floor(interaction.createdTimestamp / 1000)}:R>`
        },
        {
         name: "الدلائل",
         value: `**\`\`\`js\n${message.content}\`\`\`**`
        }
      )
      .setThumbnail(interaction.guild.iconURL())
          .setTimestamp()
    .setFooter({
      text: interaction.guild.name,
        iconURL: interaction.guild.iconURL()
    })
    .setThumbnail(interaction.guild.iconURL())
    .setAuthor({
      name: interaction.guild.name,
        iconURL: interaction.guild.iconURL()
    });
    warnchannel.send({ 
    content: `${member}`,
    embeds: [embed] });
      if (member.roles.cache.has(warn50)) {
      await member.roles.remove(warn50);
      };
      if (member.roles.cache.has(warn25)) {
      await member.roles.remove(warn25);
      };
      if (roles.some(role => member.roles.cache.has(role))) {
      await member.roles.remove(roles);
      }
      await message.delete()
    interaction.editReply({ content: "**تم تحذير العضو بنجاح**",
components: [],              ephemeral: true });
    } else if (value === "2") {
      const warnchannel = interaction.guild.channels.cache.get("1145673375344230480");
      const embed = new EmbedBuilder()
      .setTitle("تحذير جديد")
      .addFields(
        {
          name: "البائع", 
          value: `${member}`
        },
        {
          name: "الاداري",
          value: `${interaction.user}`
        },
        {
          name: "التحذير",
          value: "بيع عمله حقيقة"
        },
        {
          name: "الروم",
          value: `${interaction.channel}`
        },
        {
          name: "وقت نشر المنشور",
          value: `<t:${Math.floor(interaction.createdTimestamp / 1000)}:R>`
        },
        {
          name: "وقت التحذير",
          value: `<t:${Math.floor(interaction.createdTimestamp / 1000)}:R>`
        },
        {
          name: "الدلائل",
          value: `**\`\`\`js\n${message.content}\`\`\`**`
        }
      )
      .setThumbnail(interaction.guild.iconURL())
          .setTimestamp()
    .setFooter({
      text: interaction.guild.name,
        iconURL: interaction.guild.iconURL()
    })
    .setThumbnail(interaction.guild.iconURL())
    .setAuthor({
      name: interaction.guild.name,
        iconURL: interaction.guild.iconURL()
    });
    warnchannel.send({ 
    content: `${member}`,
    embeds: [embed] });
    
      if (member.roles.cache.has(warn50)) {
      await member.roles.remove(warn50);
      };
      if (member.roles.cache.has(warn25)) {
      await member.roles.remove(warn25);
      };
      if (roles.some(role => member.roles.cache.has(role))) {
      await member.roles.remove(roles);
      }
      await message.delete()
      interaction.editReply({ content: "**تم تحذير العضو بنجاح**",
      components: [],              ephemeral: true });
    } else if (value === "3") {
      const warnchannel = interaction.guild.channels.cache.get("1145673375344230480");
      const embed = new EmbedBuilder()
      .setTitle("تحذير جديد")
      .addFields(
        {
          name: "البائع", 
          value: `${member}`
        },
        {
          name: "الاداري",
          value: `${interaction.user}`
        },
        {
          name: "التحذير",
          value: "اشياء اباحيه"
        },
        {
          name: "الروم",
          value: `${interaction.channel}`
        },
        {
          name: "وقت نشر المنشور",
          value: `<t:${Math.floor(interaction.createdTimestamp / 1000)}:R>`
        },
        {
          name: "وقت التحذير",
          value: `<t:${Math.floor(interaction.createdTimestamp / 1000)}:R>`
        },
        {
          name: "الدلائل",
          value: `**\`\`\`js\n${message.content}\`\`\`**`
        }
      )
      .setThumbnail(interaction.guild.iconURL())
          .setTimestamp()
    .setFooter({
      text: interaction.guild.name,
        iconURL: interaction.guild.iconURL()
    })
    .setThumbnail(interaction.guild.iconURL())
    .setAuthor({
      name: interaction.guild.name,
        iconURL: interaction.guild.iconURL()
    });
    warnchannel.send({ 
    content: `${member}`,
    embeds: [embed] });
    
      if (member.roles.cache.has(warn50)) {
      await member.roles.remove(warn50);
      };
      if (member.roles.cache.has(warn25)) {
      await member.roles.remove(warn25);
      };
      if (roles.some(role => member.roles.cache.has(role))) {
      await member.roles.remove(roles);
      }
      await message.delete()
      interaction.editReply({ content: "**تم تحذير العضو بنجاح**",
      components: [],              ephemeral: true });
    } else if (value === "4") {
      const warnchannel = interaction.guild.channels.cache.get("1145673375344230480");
      const embed = new EmbedBuilder()
      .setTitle("تحذير جديد")
      .addFields(
        {
          name: "البائع", 
          value: `${member}`
        },
        {
          name: "الاداري",
          value: `${interaction.user}`
        },
        {
          name: "التحذير",
          value: "طرق نيترو او طرق كريديت"
        },
        {
          name: "الروم",
          value: `${interaction.channel}`
        },
        {
          name: "وقت نشر المنشور",
          value: `<t:${Math.floor(interaction.createdTimestamp / 1000)}:R>`
        },
        {
          name: "وقت التحذير",
          value: `<t:${Math.floor(interaction.createdTimestamp / 1000)}:R>`
        },
        {
          name: "الدلائل",
          value: `**\`\`\`js\n${message.content}\`\`\`**`
        }
      )
      .setThumbnail(interaction.guild.iconURL())
          .setTimestamp()
    .setFooter({
      text: interaction.guild.name,
        iconURL: interaction.guild.iconURL()
    })
    .setThumbnail(interaction.guild.iconURL())
    .setAuthor({
      name: interaction.guild.name,
        iconURL: interaction.guild.iconURL()
    });
    warnchannel.send({ 
    content: `${member}`,
    embeds: [embed] });
    
      if (member.roles.cache.has(warn50)) {
      await member.roles.remove(warn50);
      };
      if (member.roles.cache.has(warn25)) {
      await member.roles.remove(warn25);
      };
      if (roles.some(role => member.roles.cache.has(role))) {
      await member.roles.remove(roles);
      }
      await message.delete()
      interaction.editReply({ content: "**تم تحذير العضو بنجاح**",
      components: [],              ephemeral: true });
    } else if (value === "5") {
      const warnchannel = interaction.guild.channels.cache.get("1145673375344230480");
      const embed = new EmbedBuilder()
      .setTitle("تحذير جديد")
      .addFields(
        {
          name: "البائع", 
          value: `${member}`
        },
        {
          name: "الاداري",
          value: `${interaction.user}`
        },
        {
          name: "التحذير",
          value: "منشن ايفري وان"
        },
        {
          name: "الروم",
          value: `${interaction.channel}`
        },
        {
          name: "وقت نشر المنشور",
          value: `<t:${Math.floor(interaction.createdTimestamp / 1000)}:R>`
        },
        {
          name: "وقت التحذير",
          value: `<t:${Math.floor(interaction.createdTimestamp / 1000)}:R>`
        },
        {
          name: "الدلائل",
          value: `**\`\`\`js\n${message.content}\`\`\`**`
        }
      )
      .setThumbnail(interaction.guild.iconURL())
          .setTimestamp()
    .setFooter({
      text: interaction.guild.name,
        iconURL: interaction.guild.iconURL()
    })
    .setThumbnail(interaction.guild.iconURL())
    .setAuthor({
      name: interaction.guild.name,
        iconURL: interaction.guild.iconURL()
    });
    warnchannel.send({ 
    content: `${member}`,
    embeds: [embed] });
    
      if (member.roles.cache.has(warn50)) {
      await member.roles.remove(warn50);
      };
      if (member.roles.cache.has(warn25)) {
      await member.roles.remove(warn25);
      };
      if (roles.some(role => member.roles.cache.has(role))) {
      await member.roles.remove(roles);
      }
      await message.delete()
      interaction.editReply({ content: "**تم تحذير العضو بنجاح**",
      components: [],              ephemeral: true });
    } else if (value === "6"){
      const warnchannel = interaction.guild.channels.cache.get("1231190395874971680");
      const embed = new EmbedBuilder()
      .setTitle("تحذير جديد")
      .addFields(
        {
          name: "البائع", 
          value: `${member}`
        },
        {
          name: "الاداري",
          value: `${interaction.user}`
        },
        {
          name: "التحذير",
          value: "بيع منتج عبر دخول السيرفر"
        },
        {
          name: "الروم",
          value: `${interaction.channel}`
        },
        {
          name: "وقت نشر المنشور",
          value: `<t:${Math.floor(interaction.createdTimestamp / 1000)}:R>`
        },
        {
          name: "وقت التحذير",
          value: `<t:${Math.floor(interaction.createdTimestamp / 1000)}:R>`
        },
        {
          name: "الدلائل",
          value: `**\`\`\`js\n${message.content}\`\`\`**`
        }
      )
      .setThumbnail(interaction.guild.iconURL())
          .setTimestamp()
    .setFooter({
      text: interaction.guild.name,
        iconURL: interaction.guild.iconURL()
    })
    .setThumbnail(interaction.guild.iconURL())
    .setAuthor({
      name: interaction.guild.name,
        iconURL: interaction.guild.iconURL()
    });
    warnchannel.send({ 
    content: `${member}`,
    embeds: [embed] });
    
      if (member.roles.cache.has(warn50)) {
      await member.roles.remove(warn50);
      };
      if (member.roles.cache.has(warn25)) {
      await member.roles.remove(warn25);
      };
      if (roles.some(role => member.roles.cache.has(role))) {
      await member.roles.remove(roles);
      }
      await message.delete()
      interaction.editReply({ content: "**تم تحذير العضو بنجاح**",
      components: [],              ephemeral: true });
    } else if (value === "7") {
      const warnchannel = interaction.guild.channels.cache.get("1145673375344230480");
      const embed = new EmbedBuilder()
      .setTitle("تحذير جديد")
      .addFields(
        {
          name: "البائع", 
          value: `${member}`
        },
        {
          name: "الاداري",
          value: `${interaction.user}`
        },
        {
          name: "التحذير",
          value: "الاستهبال في رومات البيع"
        },
        {
          name: "الروم",
          value: `${interaction.channel}`
        },
        {
          name: "وقت نشر المنشور",
          value: `<t:${Math.floor(interaction.createdTimestamp / 1000)}:R>`
        },
        {
          name: "وقت التحذير",
          value: `<t:${Math.floor(interaction.createdTimestamp / 1000)}:R>`
        },
        {
          name: "الدلائل",
          value: `**\`\`\`js\n${message.content}\`\`\`**`
        }
      )
      .setThumbnail(interaction.guild.iconURL())
          .setTimestamp()
    .setFooter({
      text: interaction.guild.name,
        iconURL: interaction.guild.iconURL()
    })
    .setThumbnail(interaction.guild.iconURL())
    .setAuthor({
      name: interaction.guild.name,
        iconURL: interaction.guild.iconURL()
    });
    warnchannel.send({ 
    content: `${member}`,
    embeds: [embed] });
    
      if (member.roles.cache.has(warn50)) {
      await member.roles.remove(warn50);
      };
      if (member.roles.cache.has(warn25)) {
      await member.roles.remove(warn25);
      };
      if (roles.some(role => member.roles.cache.has(role))) {
      await member.roles.remove(roles);
      }
      await message.delete()
      interaction.editReply({ content: "**تم تحذير العضو بنجاح**",
      components: [],              ephemeral: true });
    } else if (value === "8") {
      const warnchannel = interaction.guild.channels.cache.get("1231190395874971680");
      const embed = new EmbedBuilder()
      .setTitle("تحذير جديد")
      .addFields(
        {
          name: "البائع", 
          value: `${member}`
        },
        {
          name: "الاداري",
          value: `${interaction.user}`
        },
        {
          name: "التحذير",
          value: "نسخ منشور شخص اخر"
        },
        {
          name: "الروم",
          value: `${interaction.channel}`
        },
        {
          name: "وقت نشر المنشور",
          value: `<t:${Math.floor(interaction.createdTimestamp / 1000)}:R>`
        },
        {
          name: "وقت التحذير",
          value: `<t:${Math.floor(interaction.createdTimestamp / 1000)}:R>`
        },
        {
          name: "الدلائل",
          value: `**\`\`\`js\n${message.content}\`\`\`**`
        }
      )
      .setThumbnail(interaction.guild.iconURL())
          .setTimestamp()
    .setFooter({
      text: interaction.guild.name,
        iconURL: interaction.guild.iconURL()
    })
    .setThumbnail(interaction.guild.iconURL())
    .setAuthor({
      name: interaction.guild.name,
        iconURL: interaction.guild.iconURL()
    });
    warnchannel.send({ 
    content: `${member}`,
    embeds: [embed] });
    
    if (member.roles.cache.has(warn50)) {
await member.roles.remove(warn50);
};
if (member.roles.cache.has(warn25)) {
await member.roles.remove(warn25);
};
if (roles.some(role => member.roles.cache.has(role))) {
await member.roles.remove(roles);
}
      await message.delete()
      interaction.editReply({ content: "**تم تحذير العضو بنجاح**",
      components: [],              ephemeral: true });
    } else if (value === "9") {
      const warnchannel = interaction.guild.channels.cache.get("1145673375344230480");
      const embed = new EmbedBuilder()
      .setTitle("تحذير جديد")
      .addFields(
        {
          name: "البائع", 
          value: `${member}`
        },
        {
          name: "الاداري",
          value: `${interaction.user}`
        },
        {
          name: "التحذير",
          value: "بيع ادوات او برامج"
        },
        {
          name: "الروم",
          value: `${interaction.channel}`
        },
        {
          name: "وقت نشر المنشور",
          value: `<t:${Math.floor(interaction.createdTimestamp / 1000)}:R>`
        },
        {
          name: "وقت التحذير",
          value: `<t:${Math.floor(interaction.createdTimestamp / 1000)}:R>`
        },
        {
          name: "الدلائل",
          value: `**\`\`\`js\n${message.content}\`\`\`**`
        }
      )
      .setThumbnail(interaction.guild.iconURL())
          .setTimestamp()
    .setFooter({
      text: interaction.guild.name,
        iconURL: interaction.guild.iconURL()
    })
    .setThumbnail(interaction.guild.iconURL())
    .setAuthor({
      name: interaction.guild.name,
        iconURL: interaction.guild.iconURL()
    });
    warnchannel.send({ 
    content: `${member}`,
    embeds: [embed] });
    
    if (member.roles.cache.has(warn50)) {
await member.roles.remove(warn50);
};
if (member.roles.cache.has(warn25)) {
await member.roles.remove(warn25);
};
if (roles.some(role => member.roles.cache.has(role))) {
await member.roles.remove(roles);
}
      await message.delete()
      interaction.editReply({ content: "**تم تحذير العضو بنجاح**",
      components: [],              ephemeral: true });
    } else if (value === "10") {
      const warnchannel = interaction.guild.channels.cache.get("1145673375344230480");
      const embed = new EmbedBuilder()
      .setTitle("تحذير جديد")
      .addFields(
        {
          name: "البائع", 
          value: `${member}`
        },
        {
          name: "الاداري",
          value: `${interaction.user}`
        },
        {
          name: "التحذير",
          value: "بيع فيزات"
        },
        {
          name: "الروم",
          value: `${interaction.channel}`
        },
        {
          name: "وقت نشر المنشور",
          value: `<t:${Math.floor(interaction.createdTimestamp / 1000)}:R>`
        },
        {
          name: "وقت التحذير",
          value: `<t:${Math.floor(interaction.createdTimestamp / 1000)}:R>`
        },
        {
          name: "الدلائل",
          value: `**\`\`\`js\n${message.content}\`\`\`**`
        }
      )
      .setThumbnail(interaction.guild.iconURL())
          .setTimestamp()
    .setFooter({
      text: interaction.guild.name,
        iconURL: interaction.guild.iconURL()
    })
    .setThumbnail(interaction.guild.iconURL())
    .setAuthor({
      name: interaction.guild.name,
        iconURL: interaction.guild.iconURL()
    });
    warnchannel.send({ 
    content: `${member}`,
    embeds: [embed] });
    member.roles.add(warn25)
    if (member.roles.cache.has(warn25)) {
await
member.roles.add(warn50);
} else if (member.roles.cache.has(warn50)) {
await member.roles.remove(warn50);
} else if (member.roles.cache.has(warn25)) {
await member.roles.remove(warn25);
} else if (roles.some(role => member.roles.cache.has(role))) {
await member.roles.remove(roles);
}
      await message.delete()
      interaction.editReply({ content: "**تم تحذير العضو بنجاح**",
      components: [],              ephemeral: true });
    } else if (value === "11") {
      const warnchannel = interaction.guild.channels.cache.get("1145673375344230480");
      const embed = new EmbedBuilder()
      .setTitle("تحذير جديد")
      .addFields(
        {
          name: "البائع", 
          value: `${member}`
        },
        {
          name: "الاداري",
          value: `${interaction.user}`
        },
        {
          name: "التحذير",
          value: "نشر بروم غلط"
        },
        {
          name: "الروم",
          value: `${interaction.channel}`
        },
        {
          name: "وقت نشر المنشور",
          value: `<t:${Math.floor(interaction.createdTimestamp / 1000)}:R>`
        },
        {
          name: "وقت التحذير",
          value: `<t:${Math.floor(interaction.createdTimestamp / 1000)}:R>`
        },
        {
          name: "الدلائل",
          value: `**\`\`\`js\n${message.content}\`\`\`**`
        }
      )
      .setThumbnail(interaction.guild.iconURL())
          .setTimestamp()
    .setFooter({
      text: interaction.guild.name,
        iconURL: interaction.guild.iconURL()
    })
    .setThumbnail(interaction.guild.iconURL())
    .setAuthor({
      name: interaction.guild.name,
        iconURL: interaction.guild.iconURL()
    });
    warnchannel.send({ 
    content: `${member}`,
    embeds: [embed] });
    
      member.roles.add(warn25)
      if (member.roles.cache.has(warn25)) {
      await
      member.roles.add(warn50);
      } else if (member.roles.cache.has(warn50)) {
      await member.roles.remove(warn50);
      } else if (member.roles.cache.has(warn25)) {
      await member.roles.remove(warn25);
      } else if (roles.some(role => member.roles.cache.has(role))) {
      await member.roles.remove(roles);
      }
      await message.delete()
      interaction.editReply({ content: "**تم تحذير العضو بنجاح**",
      components: [],              ephemeral: true });
    } else if (value === "12") {
      const warnchannel = interaction.guild.channels.cache.get("1145673375344230480");
      const embed = new EmbedBuilder()
      .setTitle("تحذير جديد")
      .addFields(
        {
          name: "البائع", 
          value: `${member}`
        },
        {
          name: "الاداري",
          value: `${interaction.user}`
        },
        {
          name: "التحذير",
          value: "عدم التشفير"
        },
        {
          name: "الروم",
          value: `${interaction.channel}`
        },
        {
          name: "وقت نشر المنشور",
          value: `<t:${Math.floor(interaction.createdTimestamp / 1000)}:R>`
        },
        {
          name: "وقت التحذير",
          value: `<t:${Math.floor(interaction.createdTimestamp / 1000)}:R>`
        },
        {
          name: "الدلائل",
          value: `**\`\`\`js\n${message.content}\`\`\`**`
        }
      )
      .setThumbnail(interaction.guild.iconURL())
          .setTimestamp()
    .setFooter({
      text: interaction.guild.name,
        iconURL: interaction.guild.iconURL()
    })
    .setThumbnail(interaction.guild.iconURL())
    .setAuthor({
      name: interaction.guild.name,
        iconURL: interaction.guild.iconURL()
    });
    warnchannel.send({ 
    content: `${member}`,
    embeds: [embed] });
      if (member.roles.cache.has(warn25)) {
        await member.roles.add(warn50);
        interaction.channel.send({ content: '**2**' });
      } else if (member.roles.cache.has(warn50)) {
      } else {
        if (roles.some(role => member.roles.cache.has(role))) {
          await member.roles.remove(roles);
          interaction.channel.send({ content: '**3**' });
        } else {
        }
      } 
    await message.delete()
      interaction.editReply({ content: "**تم تحذير العضو بنجاح**",
      components: [],              ephemeral: true });
    }
    }
});
    }
  }
});