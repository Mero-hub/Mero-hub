const client = require("../../index.js");
const { EmbedBuilder } = require("discord.js");

let channels = ["1145673394679975969","1145673393249714227","1145673397456601198","1145673398828154973","1145673396210896896","1145673385012117594","1145673386828243034","1145673388543709204"];
let doneroom = "1145673367966449796";
const schedule = require('node-schedule');
const rule = new schedule.RecurrenceRule();
rule.hour = 20;
rule.minute = 22;
rule.tz = 'Africa/Cairo';
const job = schedule.scheduleJob(rule, function(){
  channels.forEach(channel => {
    let ch = client.channels.cache.get(channel)

  const guild = ch.guild;
        const everyoneRole = guild.roles.everyone;

  if(ch){
  ch.permissionOverwrites.edit(everyoneRole,{
   ViewChannel:false,
   SendMessages:false, 
   }) 
  }

  })
  channels.forEach(channel => {
    let ch = client.channels.cache.get(channel)

  ch.fetch().then(channel => {
    const fetchmessages = channel.messages.fetch({ limit: 100 }).then(messages => {
      channel.bulkDelete(messages)
    })
  }).catch(console.error);

  })

let log = client.channels.cache.get(doneroom)



  
  const embed = new EmbedBuilder()
    .setTitle("تم قفل الرومات")
    .setDescription(`**تم قفل الرومات ,  لا يمكنك الان النشر**`)
    .setColor("#000100")
    .setTimestamp();
  
                               
  log.messages.fetch({limit:1}).then(messages => {
    const fetchedMessage = messages.first();
    if (fetchedMessage) {
      fetchedMessage.delete().then(() => {
        log.send({
      content:`@here`,
      embeds: [embed]});
      })
    }
  
  })
});                                

const rule1 = new schedule.RecurrenceRule();
rule1.hour = 20;
rule1.minute = 23;
rule1.tz = 'Africa/Cairo';
const job1 = schedule.scheduleJob(rule1, function(){
  channels.forEach(channel => {
    let ch = client.channels.cache.get(channel)

const guild = ch.guild;
const everyoneRole = guild.roles.everyone;

  if(ch){
  ch.permissionOverwrites.edit(everyoneRole,{
   ViewChannel:true,
   SendMessages:null,
   }) 
  }

  })
  



let log = client.channels.cache.get(doneroom)

  const embed = new EmbedBuilder()
    .setTitle("تم فتح الرومات")
    .setDescription(`**تم فتح الرومات , يمكنك الان النشر**`)
    .setColor("#000100")
    .setTimestamp();

  log.messages.fetch({limit:1}).then(messages => {
    const fetchedMessage = messages.first();
    if (fetchedMessage) {
      fetchedMessage.delete().then(() => {
        log.send({
        content:`@here`,
        embeds: [embed]});
      })
    }
  
  })

});
