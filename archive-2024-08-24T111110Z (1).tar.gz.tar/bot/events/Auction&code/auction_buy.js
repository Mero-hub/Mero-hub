const client = require("../../index.js");
const { EmbedBuilder, ApplicationCommandOptionType , Events , ActionRowBuilder , ButtonBuilder ,MessageAttachment, ButtonStyle , Message, TextInputStyle,TextInputBuilder,ModalBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, PermissionsBitField } = require("discord.js");
const config = require("../../config.json");
const users = require('../../Datebase/model/buy.js');
client.on('interactionCreate', async interaction => {
  if (!interaction.isButton()) return;
  if (interaction.customId === 'auction_buy') {
    const user = await users.findOne({ userId: interaction.user.id, buy: true });

if (user && user.buy === true) {
    return interaction.reply({ content: `**لديك عملية شراء بالفعل**`, ephemeral: true });
}

if (!user) {
    await users.create({ userId: interaction.user.id, buy: true });
} else {
    user.buy = true;
    await user.save();
} 
    const auction_buy = new StringSelectMenuBuilder()
    .setCustomId("auction_buy1")
    .setPlaceholder("اختار نوع المزاد")
    .addOptions(
      new StringSelectMenuOptionBuilder()
      .setLabel('مزاد عادي')
      .setValue('auction_buy_normal'),
      new StringSelectMenuOptionBuilder()
      .setLabel("مزاد نادر")
      .setValue("auction_buy_rare"),
      new StringSelectMenuOptionBuilder()
      .setLabel("مزاد ملكي")
      .setValue("auction_buy_epic"),
    );
    const row = new ActionRowBuilder()
    .addComponents(auction_buy);
    const embed = new EmbedBuilder()
    .setColor("#000100")
    .setDescription("**- اهلا وسهلا في مزادات **");
    await interaction.reply({
      components: [row],
      embeds: [embed],
    })
  }
});
client.on('interactionCreate', async interaction => {
  if (!interaction.isStringSelectMenu()) return;
  if (interaction.customId === 'auction_buy1') {
    const selectedValue = interaction.values[0];
    if (selectedValue === 'auction_buy_normal') {
      let price = "10000";
        let result = price;
  let tax = Math.floor(price * (20 / 19) + 1);
  let owner = config.owner;
      const embed = new EmbedBuilder()
      .setTitle("مزاد عادي")
      .setDescription(
        `**- قم بتحويل مبلغ \`${result}\` إلى <@${owner}>**`);
      await interaction.update({
        embeds: [embed],
        components: [],
      })
      await interaction.channel.send({
      content: `#credit ${owner} ${tax}`
    })
      const filter = ({ content, author: { id } }) => {
        return (
            content.startsWith(`**:moneybag: | ${interaction.user.username}, has transferred `) &&
            content.includes(`${owner}`) &&
            id === "282859044593598464" &&
            (Number(content.slice(content.lastIndexOf("`") - String(tax).length, content.lastIndexOf("`"))) >= result)
        );
    };

      const collector = interaction.channel.createMessageCollector({ 
        filter,               
        max: 1,
        time: 60000,
        });
        let iscollected = false;
        collector.on('collect', async (collected) => {
        iscollected = true;
        const embed = new EmbedBuilder()
      .setTitle(
        "شراء مزاد عادي")
      .setDescription(
        `**تم شراء مزاد عادي بنجاح**`);
      const a = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('auction_done')
        .setLabel('قم بوضع مزادك هنا')
        .setStyle(ButtonStyle.Success)
    );
  await interaction.editReply({
    embeds: [embed],
    components: [a],
  })
          const user = await users.deleteOne({ userId: interaction.user.id });
  const log = client.channels.cache.get(config.mazad)
  const logembed = new EmbedBuilder()
  .setColor('#000100')
  .setTitle("شراء مزاد عادي")
  .addFields(
   {
     name: "تم شراء بواسطة",
     value: `<@${interaction.member.id}>`,
     inline: true
   },
   {
     name: "نوع المزاد",
     value: `مزاد عادي`,
     inline: true
   },
   {
     name: "المبلغ",
     value: `${result}`,
     inline: true
   }
  )
  .setThumbnail(interaction.guild.iconURL({dynamic:true}))
  .setTimestamp();
  await log.send({embeds:[logembed]})
});
      
      collector.on('end', async (collected) => {
  if (!iscollected) {
    const embed = new EmbedBuilder()
    .setColor('#000100')
    .setDescription(`**انتهى وقت العمليه**`)
    .setTimestamp();
    await interaction.editReply({
    embeds: [embed],
    components: [],
    })
    const user = await users.deleteOne({ userId: interaction.user.id });
    }
    });
    } else if (selectedValue === 'auction_buy_rare') {
      let price = "20000";
      let result = price;
    let tax = Math.floor(price * (20 / 19) + 1);
  let owner = config.owner;
      const embed = new EmbedBuilder()
      .setTitle("مزاد نادر")
      .setDescription(
        `**- قم بتحويل مبلغ \`${result}\` إلى <@${owner}>**`);
      await interaction.update({
        embeds: [embed],
        components: [],
      })
      await interaction.channel.send({
      content: `#credit ${owner} ${tax}`
    })
      const filter = ({ content, author: { id } }) => {
        return (
            content.startsWith(`**:moneybag: | ${interaction.user.username}, has transferred `) &&
            content.includes(`${owner}`) &&
            id === "282859044593598464" &&
            (Number(content.slice(content.lastIndexOf("`") - String(tax).length, content.lastIndexOf("`"))) >= result)
        );
    };

      const collector = interaction.channel.createMessageCollector({ 
        filter,               
        max: 1,
        time: 60000,
        });
        let iscollected = false;
        collector.on('collect', async (collected) => {
        iscollected = true;
        const embed = new EmbedBuilder()
      .setTitle(
        "شراء مزاد نادر")
      .setDescription(
        `**تم شراء نادر عادي بنجاح**`);
      const a = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('auction_done_rare')
        .setLabel('قم بوضع مزادك هنا')
        .setStyle(ButtonStyle.Success)
    );
  await interaction.editReply({
    embeds: [embed],
    components: [a],
  })
          const user = await users.deleteOne({ userId: interaction.user.id });
  const log = client.channels.cache.get(config.mazad)
  const logembed = new EmbedBuilder()
  .setColor('#000100')
  .setTitle("شراء مزاد نادر")
  .addFields(
   {
     name: "تم شراء بواسطة",
     value: `<@${interaction.member.id}>`,
     inline: true
   },
   {
     name: "نوع المزاد",
     value: `مزاد نادر`,
     inline: true
   },
   {
     name: "المبلغ",
     value: `${result}`,
     inline: true
   }
  )
  .setThumbnail(interaction.guild.iconURL({dynamic:true}))
  .setTimestamp();
  await log.send({embeds:[logembed]})
});
      collector.on('end', async (collected) => {
  if (!iscollected) {
    const embed = new EmbedBuilder()
    .setColor('#000100')
    .setDescription(`**انتهى وقت العمليه**`)
    .setTimestamp();
    await interaction.editReply({
    embeds: [embed],
    components: [],
    })
    const user = await users.deleteOne({ userId: interaction.user.id });
    }
    });
      
    } else if (selectedValue === 'auction_buy_epic') {
      let price = "30000";
      let result = price;
    let tax = Math.floor(price * (20 / 19) + 1);
  let owner = config.owner;
      const embed = new EmbedBuilder()
      .setTitle("مزاد ملكي")
      .setDescription(
        `**- قم بتحويل مبلغ \`${result}\` إلى <@${owner}>**`);
      await interaction.update({
        embeds: [embed],
        components: [],
      })
      await interaction.channel.send({
      content: `#credit ${owner} ${tax}`
    })
      const filter = ({ content, author: { id } }) => {
        return (
            content.startsWith(`**:moneybag: | ${interaction.user.username}, has transferred `) &&
            content.includes(`${owner}`) &&
            id === "282859044593598464" &&
            (Number(content.slice(content.lastIndexOf("`") - String(tax).length, content.lastIndexOf("`"))) >= result)
        );
    };
      const collector = interaction.channel.createMessageCollector({
        filter,               
        max: 1,
        time: 60000,
      });
      let iscollected = false;
      collector.on('collect', async (collected) => {
        iscollected = true;
        const embed = new EmbedBuilder()
      .setTitle(
        "شراء مزاد ملكي")
      .setDescription(
        `**تم شراء ملكي عادي بنجاح**`);
      const a = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('auction_done_epic')
        .setLabel('قم بوضع مزادك هنا')
        .setStyle(ButtonStyle.Success)
    );
  await interaction.editReply({
    embeds: [embed],
    components: [a],
  })
        const user = await users.deleteOne({ userId: interaction.user.id });
  const log = client.channels.cache.get(config.mazad)
  const logembed = new EmbedBuilder()
  .setColor('#000100')
  .setTitle("شراء مزاد ملكي")
          .addFields(
           {
             name: "تم شراء بواسطة",
             value: `<@${interaction.member.id}>`,
             inline: true
           },
           {
             name: "نوع المزاد",
             value: `مزاد نادر`,
             inline: true
           },
           {
             name: "المبلغ",
             value: `${result}`,
             inline: true
           }
          )
          .setThumbnail(interaction.guild.iconURL({dynamic:true}))
          .setTimestamp();
          await log.send({embeds:[logembed]})
      });
      collector.on('end', async (collected) => {
  if (!iscollected) {
    const embed = new EmbedBuilder()
    .setColor('#000100')
    .setDescription(`**انتهى وقت العمليه**`)
    .setTimestamp();
    await interaction.editReply({
    embeds: [embed],
    components: [],
    })
    const user = await users.deleteOne({ userId: interaction.user.id });
  }
    });
    }
  }
});
client.on('interactionCreate', async interaction => {
  if (!interaction.isButton()) return;
  if (interaction.customId === 'auction_done') {
    const modal = new ModalBuilder()
    .setCustomId('auction_done1')
    .setTitle('مزاد عادي')
    const a1 = new TextInputBuilder()
    .setCustomId('auction_item1')
    .setLabel("السلعه")
    .setStyle(TextInputStyle.Short)
    .setRequired(true);
    const a2 = new TextInputBuilder()
    .setCustomId('auction_item_descrtion1')
    .setLabel("وصف السلعه")
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(true);
    const firstActionRow = new ActionRowBuilder().addComponents(a1)
    const secondActionRow = new ActionRowBuilder().addComponents(a2)
    modal.addComponents(firstActionRow, secondActionRow)
    await interaction.showModal(modal)
  } else if (interaction.customId === 'auction_done_rare') {
    const modal = new ModalBuilder()
    .setCustomId('auction_done2')
    .setTitle('مزاد نادر')
    const a1 = new TextInputBuilder()
    .setCustomId('auction_item2')
    .setLabel("السلعه")
    .setStyle(TextInputStyle.Short)
    .setRequired(true);
    const a2 = new TextInputBuilder()
    .setCustomId('auction_item_descrtion2')
    .setLabel("وصف السلعه")
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(true);
    const firstActionRow = new ActionRowBuilder().addComponents(a1)
    const secondActionRow = new ActionRowBuilder().addComponents(a2)
    modal.addComponents(firstActionRow, secondActionRow)
    await interaction.showModal(modal)
  } else if (interaction.customId === 'auction_done_epic') {
    const modal = new ModalBuilder()
    .setCustomId('auction_done3')
    .setTitle('مزاد ملكي')
    const a1 = new TextInputBuilder()
    .setCustomId('auction_item3')
    .setLabel("السلعه")
    .setStyle(TextInputStyle.Short)
    .setRequired(true);
    const a2 = new TextInputBuilder()
    .setCustomId('auction_item_descrtion3')
    .setLabel("وصف السلعه")
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(true);
    const firstActionRow = new ActionRowBuilder().addComponents(a1)
    const secondActionRow = new ActionRowBuilder().addComponents(a2)
    modal.addComponents(firstActionRow, secondActionRow)
    await interaction.showModal(modal)
  }
});
client.on('interactionCreate', async interaction => {
  if (!interaction.isModalSubmit()) return;
  if (interaction.customId === 'auction_done1') {
    const a1 = interaction.fields.getTextInputValue('auction_item1')
    const a2 = interaction.fields.getTextInputValue('auction_item_descrtion1')
    
    const Auction_items = interaction.guild.channels.cache.get(config.Auction_items_channel);
    const auction_done = new EmbedBuilder()
    .setColor('#000100')
    .setTitle("سـلـعــة الـيــوم")
    .addFields(
      {
        name: "السـلـعـة",
        value: `${a1}`,
        inline: true
      },
      {
        name: "وصـف الـسـلـعـة",
        value: `${a2}`,
        inline: true
      }
    )
      .setImage("https://media.discordapp.net/attachments/1249856158458708100/1266791370220376145/Picsart_24-07-27_15-20-51-824.png?ex=66ab0c26&is=66a9baa6&hm=ce9b5e167b8f903da7e73dbb79ecd8a8c47aa0f22ae5215631a4a4ea75e58403&")
    .setThumbnail(interaction.guild.iconURL({dynamic:true}))
    .setTimestamp();
    const row = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('post_item')
        .setLabel('نشر السلعة')
      .setEmoji('\<:emoji_45:1266883531666096230>')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('cancle_item')
        .setLabel('حذف السلعه')
      .setEmoji('\<:emoji_46:1266883575903682571>')
        .setStyle(ButtonStyle.Secondary)
    );
    await interaction.reply({
      content: `**تم وصول السلعه انتظر حتا يتم نشرها من قبل الإدارة**`,
      ephemeral: true,
    })
    
    const a = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('auction_done_epic')
        .setLabel('تم شراء مزاد بنجاح')
      
      .setDisabled(true)
        .setStyle(ButtonStyle.Success)
    );
    interaction.message.edit({
      components: [a]
    })
    await Auction_items.send({
      components: [row],
      embeds: [auction_done],
    });
  } else if (interaction.customId === 'auction_done2') {
    const a1 = interaction.fields.getTextInputValue('auction_item2')
    const a2 = interaction.fields.getTextInputValue('auction_item_descrtion2')
    const Auction_items = interaction.guild.channels.cache.get(config.Auction_items_channel);
    const auction_done = new EmbedBuilder()
    .setColor('#000100')
    .setTitle("سـلـعــة الـيــوم")
    .addFields(
      {
        name: "السـلـعـة",
        value: `${a1}`,
        inline: true
      },
      {
        name: "وصـف الـسـلـعـة",
        value: `${a2}`,
        inline: true
      }
    )
      .setImage("https://media.discordapp.net/attachments/1249856158458708100/1266791370220376145/Picsart_24-07-27_15-20-51-824.png?ex=66ab0c26&is=66a9baa6&hm=ce9b5e167b8f903da7e73dbb79ecd8a8c47aa0f22ae5215631a4a4ea75e58403&")
    .setThumbnail(interaction.guild.iconURL({dynamic:true}))
    .setTimestamp();
    const row = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('post_item')
        .setLabel('نشر السلعة')
      .setEmoji('\<:emoji_45:1266883531666096230>')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('cancle_item')
        .setLabel('حذف السلعه')
      .setEmoji('\<:emoji_46:1266883575903682571>')
        .setStyle(ButtonStyle.Secondary)
    );
    const a = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('auction_done_epic')
        .setLabel('تم شراء مزاد بنجاح')

      .setDisabled(true)
        .setStyle(ButtonStyle.Success)
    );
    interaction.message.edit({
      components: [a]
    });
    await interaction.reply({
      content: `**تم وصول السلعه انتظر حتا يتم نشرها من قبل الإدارة**`,
      ephemeral: true,
    })
    await Auction_items.send({
      components: [row],
      embeds: [auction_done],
    });
  } else if (interaction.customId === 'auction_done3') {
    const a1 = interaction.fields.getTextInputValue('auction_item3')
    const a2 = interaction.fields.getTextInputValue('auction_item_descrtion3')
    const Auction_items = interaction.guild.channels.cache.get(config.Auction_items_channel);
    const auction_done = new EmbedBuilder()
    .setColor('#000100')
    .setTitle("سـلـعــة الـيــوم")
    .addFields(
      {
        name: "السـلـعـة",
        value: `${a1}`,
        inline: true
      },
      {
        name: "وصـف الـسـلـعـة",
        value: `${a2}`,
        inline: true
      }
    )
      .setImage("https://media.discordapp.net/attachments/1249856158458708100/1266791370220376145/Picsart_24-07-27_15-20-51-824.png?ex=66ab0c26&is=66a9baa6&hm=ce9b5e167b8f903da7e73dbb79ecd8a8c47aa0f22ae5215631a4a4ea75e58403&")
    .setThumbnail(interaction.guild.iconURL({dynamic:true}))
    .setTimestamp();
    const row = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('post_item')
        .setLabel('نشر السلعة')
      .setEmoji('\<:emoji_45:1266883531666096230>')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('cancle_item')
        .setLabel('حذف السلعه')
      .setEmoji('\<:emoji_46:1266883575903682571>')
        .setStyle(ButtonStyle.Secondary)
    );
    const a = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('auction_done_epic')
        .setLabel('تم شراء مزاد بنجاح')

      .setDisabled(true)
        .setStyle(ButtonStyle.Success)
    );
    interaction.message.edit({
      components: [a]
    });
    await interaction.reply({
      content: `**تم وصول السلعه انتظر حتا يتم نشرها من قبل الإدارة**`,
      ephemeral: true,
    })
    await Auction_items.send({
      components: [row],
      embeds: [auction_done],
    });
  }
});
